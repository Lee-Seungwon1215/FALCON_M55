/* SPDX-License-Identifier: MIT
 * Four independent deterministic signatures, with shared Keccak work only.
 * The ordinary fndsa_sign* API remains available and does not use batching.
 */
#ifndef FNDSA_BATCH4_H
#define FNDSA_BATCH4_H
#include "fndsa.h"

typedef struct {
    const void *sign_key;
    size_t sign_key_len;
    const void *ctx;
    size_t ctx_len;
    const char *id;
    const void *hv;
    size_t hv_len;
    const void *seed;          /* Required: caller-provided entropy, as in seeded API. */
    size_t seed_len;
    void *sig;
    size_t max_sig_len;
    size_t sig_len;            /* Output: zero on failure. */
} fndsa_sign_batch4_job;

/* blocks is a public memory/performance policy, 0..160, not a secret.
 * Each block reserves 136 bytes per job. No jobs may overlap outputs/work.
 * One common signing scratch space is reused sequentially. The four keys,
 * messages, contexts, seeds, and even degrees may all be different.
 */
size_t fndsa_sign_batch4_temp_size(unsigned blocks);
/* Returns 1 iff all four signatures succeeded; inspect sig_len individually.
 * Validation/preparation failure produces no signatures. A rare failure in
 * a signing core may leave other jobs successful. No global mutable state.
 * Work contains secrets on return, just like fndsa_sign_seeded_temp().
 */
int fndsa_sign_seeded_batch4_temp(fndsa_sign_batch4_job jobs[4],
    unsigned blocks, void *work, size_t work_len);
/* Call when results no longer need the workspace; time separately if comparing
 * with original APIs that also leave caller-owned scratch unwiped. */
void fndsa_sign_batch4_clear(void *work, size_t work_len);
#endif
