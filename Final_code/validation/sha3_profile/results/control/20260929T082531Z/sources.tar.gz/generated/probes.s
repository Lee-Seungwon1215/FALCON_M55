.syntax unified
.cpu cortex-m4
.thumb
.text
/* Save all live GPRs, NZCVQ and GE. 64 bytes preserve 8-byte SP alignment.
 * Neither this code nor profile_enter/profile_leave uses an FP register.
 * bit_split/merge have private ABIs and require the GE flags to survive. */
.macro PROBE action, id
    push.w {r0-r12, lr}
    mrs r0, APSR
    push {r0, r1}
    movs r0, #\id
    bl profile_\action
    pop {r0, r1}
    msr APSR_nzcvqg, r0
    pop.w {r0-r12, lr}
.endm
.macro WRAPPER name, body, id
    .section .text.\name, "ax", %progbits
    .balign 4
    .global \name
    .type \name, %function
    .thumb_func
\name:
    push {lr}
    sub sp, #4
    PROBE enter, \id
    bl \body
    PROBE leave, \id
    ldr lr, [sp, #4]
    add sp, #8
    bx lr
    .size \name, .-\name
.endm
.section .text.profile_raw_empty, "ax", %progbits
.global profile_raw_empty
.type profile_raw_empty, %function
.thumb_func
profile_raw_empty:
    bx lr
.size profile_raw_empty, .-profile_raw_empty
WRAPPER profile_empty, profile_raw_empty, 1
