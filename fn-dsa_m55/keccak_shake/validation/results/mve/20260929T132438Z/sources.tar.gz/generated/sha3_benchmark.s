	.syntax	unified
	.file	"sha3_cm55.s"
	.text

@ =======================================================================
@ void fndsa_sha3_inject_chunk(void *dst, const void *src, size_t len)
@ =======================================================================

	.align	2
	.global	fndsa_sha3_inject_chunk
	.thumb
	.thumb_func
	.type	fndsa_sha3_inject_chunk, %function
fndsa_sha3_inject_chunk:
	push	{ r4, r5 }

	@ If less than 8 bytes to inject, do it byte-by-byte.
	cmp	r2, #8
	blo	fndsa_sha3_inject_chunk__L4

	@ Process some bytes until the destination is aligned.
	rsbs	r5, r0, #0
	ands	r5, r5, #3
	beq	fndsa_sha3_inject_chunk__L2
	subs	r2, r5
fndsa_sha3_inject_chunk__L1:
	ldrb.w	r3, [r0]
	ldrb	r4, [r1], #1
	eor	r3, r3, r4
	strb	r3, [r0], #1
	subs	r5, #1
	bne	fndsa_sha3_inject_chunk__L1

fndsa_sha3_inject_chunk__L2:
	@ Destination is aligned. Source might be unaligned, but the
	@ Cortex-M4 tolerates unaligns accesses with a penalty which is
	@ lower than doing word reassembly in software.
	lsr	r5, r2, #2
fndsa_sha3_inject_chunk__L3:
	ldr.w	r3, [r0]
	ldr	r4, [r1], #4
	eor	r3, r3, r4
	str	r3, [r0], #4
	subs	r5, #1
	bne	fndsa_sha3_inject_chunk__L3

	@ We may have a remaining tail of up to 3 bytes.
	ands	r2, r2, #3
	beq.w	fndsa_sha3_inject_chunk__L5

fndsa_sha3_inject_chunk__L4:
	@ Byte-by-byte processing for the data tail.
	ldrb.w	r3, [r0]
	ldrb	r4, [r1], #1
	eor	r3, r3, r4
	strb	r3, [r0], #1
	subs	r2, #1
	bne	fndsa_sha3_inject_chunk__L4

fndsa_sha3_inject_chunk__L5:
	pop	{ r4, r5 }
	bx	lr
	.size	fndsa_sha3_inject_chunk,.-fndsa_sha3_inject_chunk

@ =======================================================================
@ bit_split_5(uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4)
@ Split inputs x0 to x4 into even-indexed and odd-indexed bits.
@ Internal function only; non-standard ABI:
@ input:
@    r0:r1    x0
@    r2:r3    x1
@    r4:r5    x2
@    r6:r7    x3
@    r10:r11  x4
@ ASPR.GE flags must have pattern 0110.
@
@ output:
@    r0     even-indexed bits of x0
@    r1     odd-indexed bits of x0
@    r2     even-indexed bits of x1
@    r3     odd-indexed bits of x1
@    r4     even-indexed bits of x2
@    r5     odd-indexed bits of x2
@    r6     even-indexed bits of x3
@    r7     odd-indexed bits of x3
@    r10    even-indexed bits of x4
@    r11    odd-indexed bits of x4
@ clobbers:
@    r8, r14
@
@ bit_split_1, bit_split_2, bit_split_3 and bit_split_4 are alternate
@ entry points that process only the first 1, 2, 3 or 4 words.
@ =======================================================================

	@ This macro splits a word (input register xx) into its
	@ even-indexed bits (into the low half of output register dd)
	@ and odd-indexed bits (high half of dd).
	@ This macro assumes that the ASPR.GE flags have the 0110 pattern.
	@ dd and xx cannot be the same register. xx is consumed.
.macro	BIT_SPLIT_32  xx, dd
	eor	\dd, \xx, \xx, lsr #1
	and	\dd, \dd, #0x22222222
	eor	\xx, \xx, \dd
	eor	\xx, \xx, \dd, lsl #1
	eor	\dd, \xx, \xx, lsr #2
	and	\dd, \dd, #0x0C0C0C0C
	eor	\xx, \xx, \dd
	eor	\xx, \xx, \dd, lsl #2
	eor	\dd, \xx, \xx, lsr #4
	and	\dd, \dd, #0x00F000F0
	eor	\xx, \xx, \dd
	eor	\xx, \xx, \dd, lsl #4
	rev	\dd, \xx
	sel	\dd, \dd, \xx
.endm

	@ Split a 64-bit value x0:x1 into its even-indexed bits (into x0)
	@ and high-indexed bits (into x1). xt is a scratch register.
	@ This macro assumes that the ASPR.GE flags have the 0110 pattern.
.macro	BIT_SPLIT_64  x0, x1, xt
	BIT_SPLIT_32  \x0, \xt
	BIT_SPLIT_32  \x1, \x0
	pkhtb	\x1, \x0, \xt, asr #16
	pkhbt	\x0, \xt, \x0, lsl #16
.endm

	.align	2
	.thumb
	.thumb_func
	.type	bit_split_5, %function
bit_split_5:
	BIT_SPLIT_64	r10, r11, r8
bit_split_4:
	BIT_SPLIT_64	r6,  r7,  r8
bit_split_3:
	BIT_SPLIT_64	r4,  r5,  r8
bit_split_2:
	BIT_SPLIT_64	r2,  r3,  r8
bit_split_1:
	BIT_SPLIT_64	r0,  r1,  r8
	bx	lr
	.size	bit_split_5, .-bit_split_5

@ =======================================================================
@ bit_merge_5(uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4)
@ Merge inputs x0 to x4 with bit interleaving. For i = 0 to 4, the
@ low word of x_i contains the even-indexed bits, and the high word
@ contains the odd-indexed bits.
@ Internal function only; non-standard ABI:
@ input:
@    r0:r1    x0
@    r2:r3    x1
@    r4:r5    x2
@    r6:r7    x3
@    r10:r11  x4
@ ASPR.GE flags must have pattern 0110.
@
@ output:
@    r0:r1    merged x0
@    r2:r3    merged x1
@    r4:r5    merged x2
@    r6:r7    merged x3
@    r10:r11  merged x4
@ clobbers:
@    r8, r14
@
@ bit_merge_1, bit_merge_2, bit_merge_3 and bit_merge_4 are alternate
@ entry points that process only the first 1, 2, 3 or 4 words.
@ =======================================================================

	@ This macro merges a word (input register xx): low half yields
	@ the even-indexed bits, and hight half provides the odd-indexed
	@ bits. Output is written into register dd.
	@ This macro assumes that the ASPR.GE flags have the 0110 pattern.
	@ dd and xx cannot be the same register. xx is consumed.
.macro	BIT_MERGE_32  xx, dd
	rev	\dd, \xx
	sel	\xx, \dd, \xx
	eor	\dd, \xx, \xx, lsr #4
	and	\dd, \dd, #0x00F000F0
	eor	\xx, \xx, \dd
	eor	\xx, \xx, \dd, lsl #4
	eor	\dd, \xx, \xx, lsr #2
	and	\dd, \dd, #0x0C0C0C0C
	eor	\xx, \xx, \dd
	eor	\xx, \xx, \dd, lsl #2
	eor	\dd, \xx, \xx, lsr #1
	and	\dd, \dd, #0x22222222
	eor	\xx, \xx, \dd
	eor	\dd, \xx, \dd, lsl #1
.endm

	@ BIT_MERGE_64 interleaves the bits from x0 and from x1, result
	@ is written back to x0:x1. xt is a scratch register.
	@ This macro assumes that the ASPR.GE flags have the 0110 pattern.
.macro	BIT_MERGE_64  x0, x1, xt
	pkhtb	\xt, \x1, \x0, asr #16
	pkhbt	\x1, \x0, \x1, lsl #16
	BIT_MERGE_32	\x1, \x0
	BIT_MERGE_32	\xt, \x1
.endm

	.align	2
	.thumb
	.thumb_func
	.type	bit_merge_5, %function
bit_merge_5:
	BIT_MERGE_64	r10, r11, r8
bit_merge_4:
	BIT_MERGE_64	r6,  r7,  r8
bit_merge_3:
	BIT_MERGE_64	r4,  r5,  r8
bit_merge_2:
	BIT_MERGE_64	r2,  r3,  r8
bit_merge_1:
	BIT_MERGE_64	r0,  r1,  r8
	bx	lr
	.size	bit_merge_5, .-bit_merge_5

@ Fused single-state comparison: in-place four-round lazy rotations.
@ Derived from local keccak_ref, Keccak team and Alexandre Adomnicai CC0 code.
@ State stays in DTCM; fused loads use the scalar memory pipeline.
@ Original FN-DSA 21-lane split/merge boundary and helper code are unchanged.
@
@ Implementation by the Keccak, Keyak and Ketje Teams, namely, Guido Bertoni,
@ Joan Daemen, Michaël Peeters, Gilles Van Assche and Ronny Van Keer, hereby
@ denoted as "the implementer".
@ Additional optimizations by Alexandre Adomnicai.
@
@ For more information, feedback or questions, please refer to our websites:
@ http:
@ http:
@ http:
@
@ To the extent possible under law, the implementer has waived all copyright
@ and related or neighboring rights to the source code in this file.
@ http:
@
@ --- offsets in state
.equ Aba0, 0*4
.equ Aba1, 1*4
.equ Abe0, 2*4
.equ Abe1, 3*4
.equ Abi0, 4*4
.equ Abi1, 5*4
.equ Abo0, 6*4
.equ Abo1, 7*4
.equ Abu0, 8*4
.equ Abu1, 9*4
.equ Aga0, 10*4
.equ Aga1, 11*4
.equ Age0, 12*4
.equ Age1, 13*4
.equ Agi0, 14*4
.equ Agi1, 15*4
.equ Ago0, 16*4
.equ Ago1, 17*4
.equ Agu0, 18*4
.equ Agu1, 19*4
.equ Aka0, 20*4
.equ Aka1, 21*4
.equ Ake0, 22*4
.equ Ake1, 23*4
.equ Aki0, 24*4
.equ Aki1, 25*4
.equ Ako0, 26*4
.equ Ako1, 27*4
.equ Aku0, 28*4
.equ Aku1, 29*4
.equ Ama0, 30*4
.equ Ama1, 31*4
.equ Ame0, 32*4
.equ Ame1, 33*4
.equ Ami0, 34*4
.equ Ami1, 35*4
.equ Amo0, 36*4
.equ Amo1, 37*4
.equ Amu0, 38*4
.equ Amu1, 39*4
.equ Asa0, 40*4
.equ Asa1, 41*4
.equ Ase0, 42*4
.equ Ase1, 43*4
.equ Asi0, 44*4
.equ Asi1, 45*4
.equ Aso0, 46*4
.equ Aso1, 47*4
.equ Asu0, 48*4
.equ Asu1, 49*4
@ --- offsets on stack
.equ mDa0, 0*4
.equ mDa1, 1*4
.equ mDo0, 2*4
.equ mDo1, 3*4
.equ mDi0, 4*4
.equ mRC , 5*4
.equ mSize, 6*4
@ Phase 4-K2 state access abstraction. With FP scratch enabled, a fixed public
@ prefix of the bit-interleaved state lives in s0-s23 or s0-s31 for the entire
@ 24-round call. GPR/FP moves replace state-memory traffic. The mapping and
@ iteration count are compile-time constants and contain no secret-dependent
@ branch, address, predicate, or loop count.
.macro state_load dst, ofs
  ldr.w \dst, [r0, #\ofs]
.endm
.macro state_store src, ofs
  str.w \src, [r0, #\ofs]
.endm
@ Optional current-group round-constant cache. s24-s31 hold eight public
@ constants loaded once per fixed four-round group.
.macro rc_load dst, ofs
  ldr r1, [sp, #mRC]
  ldr \dst, [r1, #\ofs]
.endm
@
@ Implementation by the Keccak, Keyak and Ketje Teams, namely, Guido Bertoni,
@ Joan Daemen, Michaël Peeters, Gilles Van Assche and Ronny Van Keer, hereby
@ denoted as "the implementer".
@ Additional optimizations by Alexandre Adomnicai.
@
@ For more information, feedback or questions, please refer to our websites:
@ http:
@ http:
@ http:
@
@ To the extent possible under law, the implementer has waived all copyright
@ and related or neighboring rights to the source code in this file.
@ http:
@
.macro eorror dst, src1, src2, rot1, rot2
.if \rot1 >= \rot2
    eor \dst, \src1, \src2, ror #\rot1-\rot2
.else
    eor \dst, \src1, \src2, ror #32+\rot1-\rot2
.endif
.endm
.macro bicror dst, src1, src2, rot1, rot2
.if \rot1 >= \rot2
    bic \dst, \src1, \src2, ror #\rot1-\rot2
.else
    bic \dst, \src1, \src2, ror #32+\rot1-\rot2
.endif
.endm
.macro xor5 dst, src1, src2, src3, src4, src5, rot1, rot2, rot3, rot4, rot5
    state_load \dst, \src1
    state_load r1, \src2
    state_load r5, \src3
    state_load r11, \src4
    state_load r12, \src5
    eorror \dst, \dst, r1, \rot1, \rot2
    eorror \dst, \dst, r5, \rot1, \rot3
    eorror \dst, \dst, r11, \rot1, \rot4
    eorror \dst, \dst, r12, \rot1, \rot5
.endm
.macro xor5_pair dst_a, a1, a2, a3, a4, a5, ar1, ar2, ar3, ar4, ar5, dst_b, b1, b2, b3, b4, b5, br1, br2, br3, br4, br5
    state_load \dst_a, \a1
    state_load r1, \a2
    state_load r5, \a3
    state_load r11, \a4
    state_load r12, \a5
    eorror \dst_a, \dst_a, r1, \ar1, \ar2
    state_load \dst_b, \b1
    eorror \dst_a, \dst_a, r5, \ar1, \ar3
    state_load r1, \b2
    eorror \dst_a, \dst_a, r11, \ar1, \ar4
    state_load r5, \b3
    eorror \dst_a, \dst_a, r12, \ar1, \ar5
    state_load r11, \b4
    state_load r12, \b5
    eorror \dst_b, \dst_b, r1, \br1, \br2
    eorror \dst_b, \dst_b, r5, \br1, \br3
    eorror \dst_b, \dst_b, r11, \br1, \br4
    eorror \dst_b, \dst_b, r12, \br1, \br5
.endm
.macro xor5str_pair dst_a, a1, a2, a3, a4, a5, ar1, ar2, ar3, ar4, ar5, strreg, stradr, strofs, dst_b, b1, b2, b3, b4, b5, br1, br2, br3, br4, br5
    state_load \dst_a, \a1
    state_load r1, \a2
    state_load r5, \a3
    state_load r11, \a4
    state_load r12, \a5
  .ifc \stradr,r0
    state_store \strreg, \strofs
  .else
    str.w \strreg, [\stradr, #\strofs]
  .endif
    eorror \dst_a, \dst_a, r1, \ar1, \ar2
    state_load \dst_b, \b1
    eorror \dst_a, \dst_a, r5, \ar1, \ar3
    state_load r1, \b2
    eorror \dst_a, \dst_a, r11, \ar1, \ar4
    state_load r5, \b3
    eorror \dst_a, \dst_a, r12, \ar1, \ar5
    state_load r11, \b4
    state_load r12, \b5
    eorror \dst_b, \dst_b, r1, \br1, \br2
    eorror \dst_b, \dst_b, r5, \br1, \br3
    eorror \dst_b, \dst_b, r11, \br1, \br4
    eorror \dst_b, \dst_b, r12, \br1, \br5
.endm
.macro xor5str dst, src1, src2, src3, src4, src5, rot1, rot2, rot3, rot4, rot5, strreg, stradr, strofs
    state_load \dst, \src1
    state_load r1, \src2
    state_load r5, \src3
    state_load r11, \src4
    state_load r12, \src5
  .ifc \stradr,r0
    state_store \strreg, \strofs
  .else
    str.w \strreg, [\stradr, #\strofs]
  .endif
    eorror \dst, \dst, r1, \rot1, \rot2
    eorror \dst, \dst, r5, \rot1, \rot3
    eorror \dst, \dst, r11, \rot1, \rot4
    eorror \dst, \dst, r12, \rot1, \rot5
.endm
.macro xorrol dst, src1, src2, rot
    eor \dst, \src1, \src2, ror #\rot-1
.endm
.macro xandnotlazystr resofs, src1, src2, src3, rot1, rot2, rot3
    bicror r1, \src3, \src2, \rot3, \rot2
    eorror r1, r1, \src1, \rot3, \rot1
    state_store r1, \resofs
.endm
.macro xandnotlazy src1, src2, src3, rot1, rot2, rot3
    bicror r1, \src3, \src2, \rot3, \rot2
    eorror r1, r1, \src1, \rot3, \rot1
.endm
.macro xandnotstr resofs, src1, src2, src3, rot1, rot2, rot3
    bicror r1, \src3, \src2, \rot3, \rot2
    eorror r1, r1, \src1, \rot3, \rot1
.if \rot3 > 0
    ror r1, r1, #32-\rot3
.endif
    state_store r1, \resofs
.endm
.macro xandnot src1, src2, src3, rot1, rot2, rot3
    bicror r1, \src3, \src2, \rot3, \rot2
    eorror r1, r1, \src1, \rot3, \rot1
.if \rot3 > 0
    ror r1, r1, #32-\rot3
.endif
.endm
.macro xandnotiota out, rot3, rot2, rcofs, last
    bicror r5, r5, r4, \rot3, \rot2
    rc_load r4, \rcofs
.if \last == 1
    ldr r7, [r1, #32]!
    str r1, [sp, #mRC]
    cmp r7, #0xFF
.endif
.if \rot3 > 0
    eor r3, r3, r5, ror #32-\rot3
.else
    eor.w r3, r3, r5
.endif
    eor.w \out, r4, r3
.endm
.macro addparity par1, dly1, par2, dly2, par3, dly3, par4, dly4, par5, dly5
.if \dly1 > 0
    eor r3, \par1, r3, ror #32-\dly1
.else
    eor.w r3, \par1, r3
.endif
.if \dly2 > 0
    eor r4, \par2, r4, ror #32-\dly2
.else
    eor.w r4, \par2, r4
.endif
.if \dly3 > 0
    eor r5, \par3, r5, ror #32-\dly3
.else
    eor.w r5, \par3, r5
.endif
.if \dly4 > 0
    eor r6, \par4, r6, ror #32-\dly4
.else
    eor.w r6, \par4, r6
.endif
.if \dly5 > 0
    eor r7, \par5, r7, ror #32-\dly5
.else
    eor.w r7, \par5, r7
.endif
.endm
.macro KeccakThetaRhoPiChiIota src1, par1, dly1, src2, par2, rot2, dly2, src3, par3, rot3, dly3, src4, par4, rot4, dly4, src5, par5, rot5, dly5, ofs, last, lazy, strofs, reg
    state_load r3, \src1
    state_load r4, \src2
    state_load r5, \src3
    state_load r6, \src4
    state_load r7, \src5
    state_store r1, \strofs
    addparity \par1, \dly1, \par2, \dly2, \par3, \dly3, \par4, \dly4, \par5, \dly5
.if \lazy == 1
    xandnotlazystr \src2, r4, r5, r6, \rot2, \rot3, \rot4
    xandnotlazystr \src3, r5, r6, r7, \rot3, \rot4, \rot5
    xandnotlazystr \src4, r6, r7, r3, \rot4, \rot5, 0
    xandnotlazystr \src5, r7, r3, r4, \rot5, 0, \rot2
.else
    xandnotstr \src2, r4, r5, r6, \rot2, \rot3, \rot4
    xandnotstr \src3, r5, r6, r7, \rot3, \rot4, \rot5
    xandnotstr \src4, r6, r7, r3, \rot4, \rot5, 0
    xandnotstr \src5, r7, r3, r4, \rot5, 0, \rot2
.endif
    xandnotiota \reg, \rot3, \rot2, \ofs, \last
.endm
.macro KeccakThetaRhoPiChi src1, dst1, par1, rot1, dly1, src2, dst2, par2, rot2, dly2, src3, dst3, par3, rot3, dly3, src4, dst4, par4, rot4, dly4, src5, dst5, par5, rot5, dly5, lazy, strofs
    state_load r3, \src1
    state_load r4, \src2
    state_load r5, \src3
    state_load r6, \src4
    state_load r7, \src5
    state_store r1, \strofs
    addparity \par1, \dly1, \par2, \dly2, \par3, \dly3, \par4, \dly4, \par5, \dly5
.if \lazy == 1
    xandnotlazystr \dst1, r3, r4, r5, \rot1, \rot2, \rot3
    xandnotlazystr \dst2, r4, r5, r6, \rot2, \rot3, \rot4
    xandnotlazystr \dst3, r5, r6, r7, \rot3, \rot4, \rot5
    xandnotlazystr \dst4, r6, r7, r3, \rot4, \rot5, \rot1
    xandnotlazy r7, r3, r4, \rot5, \rot1, \rot2
.else
    xandnotstr \dst1, r3, r4, r5, \rot1, \rot2, \rot3
    xandnotstr \dst2, r4, r5, r6, \rot2, \rot3, \rot4
    xandnotstr \dst3, r5, r6, r7, \rot3, \rot4, \rot5
    xandnotstr \dst4, r6, r7, r3, \rot4, \rot5, \rot1
    xandnot r7, r3, r4, \rot5, \rot1, \rot2
.endif
.endm
.macro KeccakThetaRhoPiChiSkipStore src1, dst1, par1, rot1, dly1, src2, dst2, par2, rot2, dly2, src3, dst3, par3, rot3, dly3, src4, dst4, par4, rot4, dly4, src5, dst5, par5, rot5, dly5, lazy, strofs
    state_load r3, \src1
    state_load r4, \src2
    state_load r5, \src3
    state_load r6, \src4
    state_load r7, \src5
    addparity \par1, \dly1, \par2, \dly2, \par3, \dly3, \par4, \dly4, \par5, \dly5
.if \lazy == 1
    xandnotlazystr \dst1, r3, r4, r5, \rot1, \rot2, \rot3
    xandnotlazystr \dst2, r4, r5, r6, \rot2, \rot3, \rot4
    xandnotlazystr \dst3, r5, r6, r7, \rot3, \rot4, \rot5
    xandnotlazystr \dst4, r6, r7, r3, \rot4, \rot5, \rot1
    xandnotlazy r7, r3, r4, \rot5, \rot1, \rot2
.else
    xandnotstr \dst1, r3, r4, r5, \rot1, \rot2, \rot3
    xandnotstr \dst2, r4, r5, r6, \rot2, \rot3, \rot4
    xandnotstr \dst3, r5, r6, r7, \rot3, \rot4, \rot5
    xandnotstr \dst4, r6, r7, r3, \rot4, \rot5, \rot1
    xandnot r7, r3, r4, \rot5, \rot1, \rot2
.endif
.endm
.macro KeccakRound0
    xor5 r3, Abu0, Agu0, Aku0, Amu0, Asu0, 0, 0, 0, 0, 0
    xor5 r7, Abe1, Age1, Ake1, Ame1, Ase1, 0, 0, 0, 0, 0
    xorrol r6, r3, r7, 32
    xor5str r4, Abi1, Agi1, Aki1, Ami1, Asi1, 0, 0, 0, 0, 0, r6, sp, mDa0
    eor.w r6, r3, r4
    xor5str r3, Abo0, Ago0, Ako0, Amo0, Aso0, 0, 0, 0, 0, 0, r6, sp, mDo1
    eor.w r2, r7, r3
    xor5 r7, Aba0, Aga0, Aka0, Ama0, Asa0, 0, 0, 0, 0, 0
    xorrol r10, r7, r4, 32
    xor5 r4, Abo1, Ago1, Ako1, Amo1, Aso1, 0, 0, 0, 0, 0
    eor r14, r4, r7
    xor5 r7, Abe0, Age0, Ake0, Ame0, Ase0, 0, 0, 0, 0, 0
    xorrol r6, r7, r4, 32
    xor5str r4, Abu1, Agu1, Aku1, Amu1, Asu1, 0, 0, 0, 0, 0, r6, sp, mDi0
    eor.w r8, r4, r7
    xor5str r7, Abi0, Agi0, Aki0, Ami0, Asi0, 0, 0, 0, 0, 0, r8, sp, mDa1
    xorrol r9, r7, r4, 32
    xor5str r4, Aba1, Aga1, Aka1, Ama1, Asa1, 0, 0, 0, 0, 0, r9, sp, mDo0
    eor r11, r4, r7
    xorrol r12, r3, r4, 32
    KeccakThetaRhoPiChiSkipStore Abo0, Aka1, r9, 14, 0, Agu0, Ame1, r12, 10, 0, Aka1, Asi1, r8, 2, 0, Ame1, Abo0, r11, 23, 0, Asi1, Agu0, r2, 31, 0, 1, Aka1
    KeccakThetaRhoPiChi Abe0, Asa1, r10, 0, 0, Agi1, Abe0, r2, 3, 0, Ako0, Agi1, r9, 12, 0, Amu1, Ako0, r14, 4, 0, Asa1, Amu1, r8, 9, 0, 1, Agu0
    ldr r8, [sp, #mDa0]
    KeccakThetaRhoPiChi Abu1, Aga0, r14, 14, 0, Aga0, Ake0, r8, 18, 0, Ake0, Ami1, r10, 5, 0, Ami1, Aso0, r2, 8, 0, Aso0, Abu1, r9, 28, 0, 1, Amu1
    KeccakThetaRhoPiChi Abi1, Ama0, r2, 31, 0, Ago0, Ase1, r9, 27, 0, Aku0, Abi1, r12, 19, 0, Ama0, Ago0, r8, 20, 0, Ase1, Aku0, r11, 1, 0, 1, Abu1
    ldr r9, [sp, #mDo1]
    KeccakThetaRhoPiChiIota Aba0, r8, 0, Age0, r10, 22, 0, Aki1, r2, 22, 0, Amo1, r9, 11, 0, Asu0, r12, 7, 0, 0, 0, 1, Aku0, r1
    ldr.w r2, [sp, #mDi0]
    KeccakThetaRhoPiChi Abo1, Aka0, r9, 14, 0, Agu1, Ame0, r14, 10, 0, Aka0, Asi0, r8, 1, 0, Ame0, Abo1, r10, 22, 0, Asi0, Agu1, r2, 30, 0, 1, Aba0
    KeccakThetaRhoPiChi Abe1, Asa0, r11, 1, 0, Agi0, Abe1, r2, 3, 0, Ako1, Agi0, r9, 13, 0, Amu0, Ako1, r12, 4, 0, Asa0, Amu0, r8, 9, 0, 1, Agu1
    ldr r8, [sp, #mDa1]
    KeccakThetaRhoPiChi Abu0, Aga1, r12, 13, 0, Aga1, Ake1, r8, 18, 0, Ake1, Ami0, r11, 5, 0, Ami0, Aso1, r2, 7, 0, Aso1, Abu0, r9, 28, 0, 1, Amu0
    KeccakThetaRhoPiChi Abi0, Ama1, r2, 31, 0, Ago1, Ase0, r9, 28, 0, Aku1, Abi0, r14, 20, 0, Ama1, Ago1, r8, 21, 0, Ase0, Aku1, r10, 1, 0, 1, Abu0
    ldr r9, [sp, #mDo0]
    KeccakThetaRhoPiChiIota Aba1, r8, 0, Age1, r11, 22, 0, Aki0, r2, 21, 0, Amo0, r9, 10, 0, Asu1, r14, 7, 0, 4, 0, 1, Aku1, r14
.endm
.macro KeccakRound1
    xor5str r3, Asu0, Agu0, Amu0, Abu1, Aku1, 22, 10, 3, 18, 28, r14, r0, Aba1
    xor5 r7, Age1, Ame0, Abe0, Ake1, Ase1, 10, 22, 4, 7, 20
    ror r3, #32-22
    xorrol r6, r3, r7, 32-10
    xor5str r4, Aki0, Asi0, Agi1, Ami0, Abi1, 7, 30, 9, 28, 1, r6, sp, mDa0
    eor r6, r3, r4, ror #32-7
    xor5str r3, Amo1, Abo0, Ako1, Aso0, Ago1, 0, 14, 1, 14, 31, r6, sp, mDo1
    eor r2, r3, r7, ror #32-10
    xor5 r7, Aba0, Aka1, Asa0, Aga0, Ama1, 0, 2, 13, 5, 20
    xorrol r10, r7, r4, 32-7
    xor5 r4, Amo0, Abo1, Ako0, Aso1, Ago0, 0, 14, 0, 13, 31
    eor r14, r4, r7
    xor5 r7, Age0, Ame1, Abe1, Ake0, Ase0, 11, 23, 4, 8, 21
    ror r7, #32-11
    xorrol r6, r7, r4, 32
    xor5str r4, Asu1, Agu1, Amu1, Abu0, Aku0, 22, 10, 3, 18, 27, r6, sp, mDi0
    eor r8, r7, r4, ror #32-22
    xor5str r7, Aki1, Asi1, Agi0, Ami1, Abi0, 7, 31, 9, 28, 1, r8, sp, mDa1
    ror r7, #32-7
    xorrol r9, r7, r4, 32-22
    xor5str r4, Aba1, Aka0, Asa1, Aga1, Ama0, 0, 1, 12, 5, 19, r9, sp, mDo0
    eor r11, r4, r7
    xorrol r12, r3, r4, 32
    KeccakThetaRhoPiChiSkipStore Amo1, Asa1, r9, 14, 0, Agu0, Ake1, r12, 10, 10, Asa1, Abi1, r8, 2, 12, Ake1, Amo1, r11, 23, 7, Abi1, Agu0, r2, 31, 1, 1, Asa1
    KeccakThetaRhoPiChi Age0, Ama0, r10, 0, 11, Asi0, Age0, r2, 3, 30, Ako1, Asi0, r9, 12, 1, Abu0, Ako1, r14, 4, 18, Ama0, Abu0, r8, 9, 19, 1, Agu0
    ldr r8, [sp, #mDa0]
    KeccakThetaRhoPiChi Asu1, Aka1, r14, 14, 22, Aka1, Abe1, r8, 18, 2, Abe1, Ami0, r10, 5, 4, Ami0, Ago1, r2, 8, 28, Ago1, Asu1, r9, 28, 31, 1, Abu0
    KeccakThetaRhoPiChi Aki0, Aga0, r2, 31, 7, Abo0, Ase1, r9, 27, 14, Amu0, Aki0, r12, 19, 3, Aga0, Abo0, r8, 20, 5, Ase1, Amu0, r11, 1, 20, 1, Asu1
    ldr r9, [sp, #mDo1]
    KeccakThetaRhoPiChiIota Aba0, r8, 0, Ame1, r10, 22, 23, Agi1, r2, 22, 9, Aso1, r9, 11, 13, Aku1, r12, 7, 28, 8, 0, 1, Amu0, r1
    ldr.w r2, [sp, #mDi0]
    KeccakThetaRhoPiChi Amo0, Asa0, r9, 14, 0, Agu1, Ake0, r14, 10, 10, Asa0, Abi0, r8, 1, 13, Ake0, Amo0, r10, 22, 8, Abi0, Agu1, r2, 30, 1, 1, Aba0
    KeccakThetaRhoPiChi Age1, Ama1, r11, 1, 10, Asi1, Age1, r2, 3, 31, Ako0, Asi1, r9, 13, 0, Abu1, Ako0, r12, 4, 18, Ama1, Abu1, r8, 9, 20, 1, Agu1
    ldr r8, [sp, #mDa1]
    KeccakThetaRhoPiChi Asu0, Aka0, r12, 13, 22, Aka0, Abe0, r8, 18, 1, Abe0, Ami1, r11, 5, 4, Ami1, Ago0, r2, 7, 28, Ago0, Asu0, r9, 28, 31, 1, Abu1
    KeccakThetaRhoPiChi Aki1, Aga1, r2, 31, 7, Abo1, Ase0, r9, 28, 14, Amu1, Aki1, r14, 20, 3, Aga1, Abo1, r8, 21, 5, Ase0, Amu1, r10, 1, 21, 1, Asu0
    ldr r9, [sp, #mDo0]
    KeccakThetaRhoPiChiIota Aba1, r8, 0, Ame0, r11, 22, 22, Agi0, r2, 21, 9, Aso0, r9, 10, 14, Aku0, r14, 7, 27, 12, 0, 1, Amu1, r14
.endm
.macro KeccakRound2
    xor5str r3, Aku1, Agu0, Abu1, Asu1, Amu1, 22, 10, 3, 18, 28, r14, r0, Aba1
    xor5 r7, Ame0, Ake0, Age0, Abe0, Ase1, 10, 22, 4, 7, 20
    ror r3, #32-22
    xorrol r6, r3, r7, 32-10
    xor5str r4, Agi0, Abi0, Asi0, Ami1, Aki0, 7, 30, 9, 28, 1, r6, sp, mDa0
    eor r6, r3, r4, ror #32-7
    xor5str r3, Aso1, Amo1, Ako0, Ago1, Abo1, 0, 14, 1, 14, 31, r6, sp, mDo1
    eor r2, r3, r7, ror #32-10
    xor5 r7, Aba0, Asa1, Ama1, Aka1, Aga1, 0, 2, 13, 5, 20
    xorrol r10, r7, r4, 32-7
    xor5 r4, Aso0, Amo0, Ako1, Ago0, Abo0, 0, 14, 0, 13, 31
    eor r14, r4, r7
    xor5 r7, Ame1, Ake1, Age1, Abe1, Ase0, 11, 23, 4, 8, 21
    ror r7, #32-11
    xorrol r6, r7, r4, 32
    xor5str r4, Aku0, Agu1, Abu0, Asu0, Amu0, 22, 10, 3, 18, 27, r6, sp, mDi0
    eor r8, r7, r4, ror #32-22
    xor5str r7, Agi1, Abi1, Asi1, Ami0, Aki1, 7, 31, 9, 28, 1, r8, sp, mDa1
    ror r7, #32-7
    xorrol r9, r7, r4, 32-22
    xor5str r4, Aba1, Asa0, Ama0, Aka0, Aga0, 0, 1, 12, 5, 19, r9, sp, mDo0
    eor r11, r4, r7
    xorrol r12, r3, r4, 32
    KeccakThetaRhoPiChiSkipStore Aso1, Ama0, r9, 14, 0, Agu0, Abe0, r12, 10, 10, Ama0, Aki0, r8, 2, 12, Abe0, Aso1, r11, 23, 7, Aki0, Agu0, r2, 31, 1, 1, Ama0
    KeccakThetaRhoPiChi Ame1, Aga0, r10, 0, 11, Abi0, Ame1, r2, 3, 30, Ako0, Abi0, r9, 12, 1, Asu0, Ako0, r14, 4, 18, Aga0, Asu0, r8, 9, 19, 1, Agu0
    ldr r8, [sp, #mDa0]
    KeccakThetaRhoPiChi Aku0, Asa1, r14, 14, 22, Asa1, Age1, r8, 18, 2, Age1, Ami1, r10, 5, 4, Ami1, Abo1, r2, 8, 28, Abo1, Aku0, r9, 28, 31, 1, Asu0
    KeccakThetaRhoPiChi Agi0, Aka1, r2, 31, 7, Amo1, Ase1, r9, 27, 14, Abu1, Agi0, r12, 19, 3, Aka1, Amo1, r8, 20, 5, Ase1, Abu1, r11, 1, 20, 1, Aku0
    ldr r9, [sp, #mDo1]
    KeccakThetaRhoPiChiIota Aba0, r8, 0, Ake1, r10,22, 23, Asi0, r2, 22, 9, Ago0, r9, 11, 13, Amu1, r12, 7, 28, 16, 0, 1, Abu1, r1
    ldr.w r2, [sp, #mDi0]
    KeccakThetaRhoPiChi Aso0, Ama1, r9, 14, 0, Agu1, Abe1, r14, 10, 10, Ama1, Aki1, r8, 1, 13, Abe1, Aso0, r10, 22, 8, Aki1, Agu1, r2, 30, 1, 1, Aba0
    KeccakThetaRhoPiChi Ame0, Aga1, r11, 1, 10, Abi1, Ame0, r2, 3, 31, Ako1, Abi1, r9, 13, 0, Asu1, Ako1, r12, 4, 18, Aga1, Asu1, r8, 9, 20, 1, Agu1
    ldr r8, [sp, #mDa1]
    KeccakThetaRhoPiChi Aku1, Asa0, r12, 13, 22, Asa0, Age0, r8, 18, 1, Age0, Ami0, r11, 5, 4, Ami0, Abo0, r2, 7, 28, Abo0, Aku1, r9, 28, 31, 1, Asu1
    KeccakThetaRhoPiChi Agi1, Aka0, r2, 31, 7, Amo0, Ase0, r9, 28, 14, Abu0, Agi1, r14, 20, 3, Aka0, Amo0, r8, 21, 5, Ase0, Abu0, r10, 1, 21, 1, Aku1
    ldr r9, [sp, #mDo0]
    KeccakThetaRhoPiChiIota Aba1, r8, 0, Ake0, r11, 22, 22, Asi1, r2, 21, 9, Ago1, r9, 10, 14, Amu0, r14, 7, 27, 20, 0, 1, Abu0, r14
.endm
.macro KeccakRound3
    xor5str r3, Amu1, Agu0, Asu1, Aku0, Abu0, 22, 10, 3, 18, 28, r14, r0, Aba1
    xor5 r7, Ake0, Abe1, Ame1, Age0, Ase1, 10, 22, 4, 7, 20
    ror r3, #32-22
    xorrol r6, r3, r7, 32-10
    xor5str r4, Asi1, Aki1, Abi0, Ami0, Agi0, 7, 30, 9, 28, 1, r6, sp, mDa0
    eor r6, r3, r4, ror #32-7
    xor5str r3, Ago0, Aso1, Ako1, Abo1, Amo0, 0, 14, 1, 14, 31, r6, sp, mDo1
    eor r2, r3, r7, ror #32-10
    xor5 r7, Aba0, Ama0, Aga1, Asa1, Aka0, 0, 2, 13, 5, 20
    xorrol r10, r7, r4, 32-7
    xor5 r4, Ago1, Aso0, Ako0, Abo0, Amo1, 0, 14, 0, 13, 31
    eor r14, r4, r7
    xor5 r7, Ake1, Abe0, Ame0, Age1, Ase0, 11, 23, 4, 8, 21
    ror r7, #32-11
    xorrol r6, r7, r4, 32
    xor5str r4, Amu0, Agu1, Asu0, Aku1, Abu1, 22, 10, 3, 18, 27, r6, sp, mDi0
    eor r8, r7, r4, ror #32-22
    xor5str r7, Asi0, Aki0, Abi1, Ami1, Agi1, 7, 31, 9, 28, 1, r8, sp, mDa1
    ror r7, #32-7
    xorrol r9, r7, r4, 32-22
    xor5str r4, Aba1, Ama1, Aga0, Asa0, Aka1, 0, 1, 12, 5, 19, r9, sp, mDo0
    eor r11, r4, r7
    xorrol r12, r3, r4, 32
    KeccakThetaRhoPiChiSkipStore Ago0, Aga0, r9, 14, 0, Agu0, Age0, r12, 10, 10, Aga0, Agi0, r8, 2, 12, Age0, Ago0, r11, 23, 7, Agi0, Agu0, r2, 31, 1, 0, Aga0
    KeccakThetaRhoPiChi Ake1, Aka1, r10, 0, 11, Aki1, Ake1, r2, 3, 30, Ako1, Aki1, r9, 12, 1, Aku1, Ako1, r14, 4, 18, Aka1, Aku1, r8, 9, 19, 0, Agu0
    ldr r8, [sp, #mDa0]
    KeccakThetaRhoPiChi Amu0, Ama0, r14, 14, 22, Ama0, Ame0, r8, 18, 2, Ame0, Ami0, r10, 5, 4, Ami0, Amo0, r2, 8, 28, Amo0, Amu0, r9, 28, 31, 0, Aku1
    KeccakThetaRhoPiChi Asi1, Asa1, r2, 31, 7, Aso1, Ase1, r9, 27, 14, Asu1, Asi1, r12, 19, 3, Asa1, Aso1, r8, 20, 5, Ase1, Asu1, r11, 1, 20, 0, Amu0
    ldr r9, [sp, #mDo1]
    KeccakThetaRhoPiChiIota Aba0, r8, 0, Abe0, r10, 22, 23, Abi0, r2, 22, 9, Abo0, r9, 11, 13, Abu0, r12, 7, 28, 24, 0, 0, Asu1, r1
    ldr.w r2, [sp, #mDi0]
    KeccakThetaRhoPiChi Ago1, Aga1, r9, 14, 0, Agu1, Age1, r14, 10, 10, Aga1, Agi1, r8, 1, 13, Age1, Ago1, r10, 22, 8, Agi1, Agu1, r2, 30, 1, 0, Aba0
    KeccakThetaRhoPiChi Ake0, Aka0, r11, 1, 10, Aki0, Ake0, r2, 3, 31, Ako0, Aki0, r9, 13, 0, Aku0, Ako0, r12, 4, 18, Aka0, Aku0, r8, 9, 20, 0, Agu1
    ldr r8, [sp, #mDa1]
    KeccakThetaRhoPiChi Amu1, Ama1, r12, 13, 22, Ama1, Ame1, r8, 18, 1, Ame1, Ami1, r11, 5, 4, Ami1, Amo1, r2, 7, 28, Amo1, Amu1, r9, 28, 31, 0, Aku0
    KeccakThetaRhoPiChi Asi0, Asa0, r2, 31, 7, Aso0, Ase0, r9, 28, 14, Asu0, Asi0, r14, 20, 3, Asa0, Aso0, r8, 21, 5, Ase0, Asu0, r10, 1, 21, 0, Amu1
    ldr r9, [sp, #mDo0]
    KeccakThetaRhoPiChiIota Aba1, r8, 0, Abe1, r11, 22, 22, Abi1, r2, 21, 9, Abo1, r9, 10, 14, Abu1, r14, 7, 27, 28, 1, 0, Asu0, r1
    state_store r1, Aba1
.endm

.align 2
.global fndsa_sha3_process_block
.thumb_func
.type fndsa_sha3_process_block,%function
fndsa_sha3_process_block:
    push.w {r4-r12,lr}
    mov r12,r0
    movw r7,#0xff00
    movt r7,#0x00ff
    uadd8 r7,r7,r7
    ldm r12,{r0-r7,r10,r11}
    bl bit_split_5
    stm r12!,{r0-r7,r10,r11}
    ldm r12,{r0-r7,r10,r11}
    bl bit_split_5
    stm r12!,{r0-r7,r10,r11}
    ldm r12,{r0-r7,r10,r11}
    bl bit_split_5
    stm r12!,{r0-r7,r10,r11}
    ldm r12,{r0-r7,r10,r11}
    bl bit_split_5
    stm r12!,{r0-r7,r10,r11}
    ldm r12,{r0-r7,r10,r11}
    bl bit_split_1
    stm r12!,{r0-r7,r10,r11}
    sub.w r0,r12,#200
    sub sp,sp,#mSize
    movw r1,#:lower16:.Lkeccak_mve_rc
    movt r1,#:upper16:.Lkeccak_mve_rc
    str r1,[sp,#mRC]
.Lkeccak_fused_round:
    KeccakRound0
    KeccakRound1
    KeccakRound2
    KeccakRound3
    bne.w .Lkeccak_fused_round
    add sp,sp,#mSize
    mov r12,r0
    ldm r12,{r0-r7,r10,r11}
    bl bit_merge_5
    stm r12!,{r0-r7,r10,r11}
    ldm r12,{r0-r7,r10,r11}
    bl bit_merge_5
    stm r12!,{r0-r7,r10,r11}
    ldm r12,{r0-r7,r10,r11}
    bl bit_merge_5
    stm r12!,{r0-r7,r10,r11}
    ldm r12,{r0-r7,r10,r11}
    bl bit_merge_5
    stm r12!,{r0-r7,r10,r11}
    ldm r12,{r0-r7,r10,r11}
    bl bit_merge_1
    stm r12!,{r0-r7,r10,r11}
    pop.w {r4-r12,pc}
.align 2
.Lkeccak_mve_rc:
    .word 0x00000001,0x00000000
    .word 0x00000000,0x00000089
    .word 0x00000000,0x8000008B
    .word 0x00000000,0x80008080
    .word 0x00000001,0x0000008B
    .word 0x00000001,0x00008000
    .word 0x00000001,0x80008088
    .word 0x00000001,0x80000082
    .word 0x00000000,0x0000000B
    .word 0x00000000,0x0000000A
    .word 0x00000001,0x00008082
    .word 0x00000000,0x00008003
    .word 0x00000001,0x0000808B
    .word 0x00000001,0x8000000B
    .word 0x00000001,0x8000008A
    .word 0x00000001,0x80000081
    .word 0x00000000,0x80000081
    .word 0x00000000,0x80000008
    .word 0x00000000,0x00000083
    .word 0x00000000,0x80008003
    .word 0x00000001,0x80008088
    .word 0x00000000,0x80000088
    .word 0x00000001,0x00008000
    .word 0x00000000,0x80008082
    .word 255
.size fndsa_sha3_process_block,.-fndsa_sha3_process_block

@ Test-only adapters appended after the complete, unmodified sha3_cm4.s.
@ Separate section: original .text must remain byte-for-byte identical.
@ Helpers have private register ABI. Every adapter restores the C ABI.
.section .text.keccak_bench,"ax",%progbits
.thumb

.macro HELPER_BENCH name, target, group=0
.balign 32
.global \name
.type \name,%function
.thumb_func
\name:
    push.w {r4-r11,lr}
    sub sp,sp,#20
    str r0,[sp,#0]
    mov r9,r1
    movw r7,#0xff00
    movt r7,#0x00ff
    uadd8 r7,r7,r7             @ APSR.GE = 0110
    mov r12,r0
    ldm r12,{r0-r7,r10,r11}
    movw r12,#0x1004
    movt r12,#0xe000           @ DWT_CYCCNT, helpers preserve r12
    dsb
    isb
    ldr r8,[r12]
    str r8,[sp,#8]
1:
.ifnc \target,none
    bl \target
.if \group
    bl \target
    bl \target
    bl \target
.ifc \target,bit_split_5
    bl bit_split_1
.else
    bl bit_merge_1
.endif
.endif
.endif
    subs r9,r9,#1
    bne 1b
    ldr r8,[r12]
    ldr r9,[sp,#8]
    sub r8,r8,r9
    str r8,[sp,#12]
    ldr r12,[sp,#0]
    stm r12,{r0-r7,r10,r11}
    ldr r0,[sp,#12]
    add sp,sp,#20
    pop.w {r4-r11,pc}
.size \name,.-\name
.endm

HELPER_BENCH bench_split1,bit_split_1
HELPER_BENCH bench_split2,bit_split_2
HELPER_BENCH bench_split3,bit_split_3
HELPER_BENCH bench_split4,bit_split_4
HELPER_BENCH bench_split5,bit_split_5
HELPER_BENCH bench_merge1,bit_merge_1
HELPER_BENCH bench_merge2,bit_merge_2
HELPER_BENCH bench_merge3,bit_merge_3
HELPER_BENCH bench_merge4,bit_merge_4
HELPER_BENCH bench_merge5,bit_merge_5
HELPER_BENCH bench_split_group,bit_split_5,1
HELPER_BENCH bench_merge_group,bit_merge_5,1
HELPER_BENCH bench_helper_empty,none

.macro PROCESS_BENCH name, do_call
.balign 32
.global \name
.type \name,%function
.thumb_func
\name:
    push {r4-r8,lr}
    mov r4,r0
    mov r5,r1
    movw r6,#0x1004
    movt r6,#0xe000
    dsb
    isb
    ldr r7,[r6]
1:
    mov r0,r4
    movs r1,#17                @ SHAKE256 rate, in 64-bit words
.if \do_call
    bl fndsa_sha3_process_block
.endif
    subs r5,r5,#1
    bne 1b
    ldr r0,[r6]
    subs r0,r0,r7
    pop {r4-r8,pc}
.size \name,.-\name
.endm
PROCESS_BENCH bench_process,1
PROCESS_BENCH bench_process_empty,0

@ Test callee-saved GPRs and the overlapping D8-D15/Q4-Q7 register bank.
.balign 32
.global bench_abi
.type bench_abi,%function
.thumb_func
bench_abi:
    push.w {r4-r11,lr}
    sub sp,sp,#4
    vpush {d8-d15}
    sub sp,sp,#72
    str r0,[sp,#64]
    movs r4,#4
    movs r5,#5
    movs r6,#6
    movs r7,#7
    movs r8,#8
    movs r9,#9
    movs r10,#10
    movs r11,#11
    vmov d8,r4,r4
    vmov d9,r4,r4
    vmov d10,r5,r5
    vmov d11,r5,r5
    vmov d12,r6,r6
    vmov d13,r6,r6
    vmov d14,r7,r7
    vmov d15,r7,r7
    ldr r0,[sp,#64]
    movs r1,#17
    bl fndsa_sha3_process_block
    movs r0,#0
.irp reg,4,5,6,7,8,9,10,11
    cmp r\reg,#\reg
    it ne
    movne r0,#1
.endr
    mov r1,sp
    vstmia r1,{d8-d15}
    movs r2,#0
1:
    ldr r3,[r1,r2,lsl #2]
    lsr r12,r2,#2
    add r12,r12,#4
    cmp r3,r12
    it ne
    movne r0,#1
    adds r2,r2,#1
    cmp r2,#16
    bne 1b
    add sp,sp,#72
    vpop {d8-d15}
    add sp,sp,#4
    pop.w {r4-r11,pc}
.size bench_abi,.-bench_abi
