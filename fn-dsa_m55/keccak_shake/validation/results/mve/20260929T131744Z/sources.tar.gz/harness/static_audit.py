"""Bounded static checks for the final hand-written single-state permutation.

This is not a general taint analyzer or a formal constant-time proof.
The accompanying README explains the manual address/data-flow audit.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
tool=ROOT/'fn-dsa_m55/measurement_mlkem_native/env/arm-gnu-toolchain-15.2.rel1-darwin-arm64-arm-none-eabi/bin'
elf=HERE/'build/mve/zephyr/zephyr.elf'
nm=subprocess.check_output([str(tool/'arm-none-eabi-nm'),'-S',str(elf)],text=True)
entry=next(l.split() for l in nm.splitlines() if l.endswith(' fndsa_sha3_process_block'))
start,size=int(entry[0],16),int(entry[1],16)
dump=subprocess.check_output([str(tool/'arm-none-eabi-objdump'),'-d',
    f'--start-address={start}',f'--stop-address={start+size}',str(elf)],text=True)
insns=[]
for line in dump.splitlines():
    m=re.match(r'\s*([0-9a-f]+):\s+[0-9a-f ]+\s+([a-z][a-z0-9.]+)\s+(.*)',line)
    if m: insns.append((m[1],m[2],m[3]))
branches=[i for i in insns if i[1].split('.')[0] in
    ('beq','bne','bhi','bls','bgt','blt','bge','ble','bcs','bcc','bmi','bpl','bvs','bvc','cbz','cbnz')]
calls=[i for i in insns if i[1]=='bl']
assert len(branches)==1 and branches[0][1]=='bne.w',branches
assert len(calls)==10,calls
assert sum('<bit_split_5>' in i[2] for i in calls)==4
assert sum('<bit_split_1>' in i[2] for i in calls)==1
assert sum('<bit_merge_5>' in i[2] for i in calls)==4
assert sum('<bit_merge_1>' in i[2] for i in calls)==1
assert not any(i[1].split('.')[0] in ('udiv','sdiv','blx','tbb','tbh') for i in insns)
assert any(i[1]=='veor' for i in insns) and any(i[1]=='vbic' for i in insns)
assert not any(i[1].startswith(('vadd.f','vsub.f','vmul.f','vdiv.f')) for i in insns)
src=HERE.parent/'sha3_cm55.s'
obj=json.loads((HERE/'build/mve/audit.json').read_text())
out=dict(source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),
    elf_sha256=hashlib.sha256(elf.read_bytes()).hexdigest(),
    function_address=hex(start),function_size_including_round_constants=size,
    original_function_size=2900,conditional_branches=branches,calls=calls,
    mve_integer_instructions_present=True,floating_point_arithmetic=False,
    helper_bytes_unchanged=obj['helpers_byte_identical'],maximum_stack_bytes=832,
    scope='Fixed public 24-round loop; manual address-flow review plus bounded opcode checks, not a formal proof')
(HERE/'static_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
