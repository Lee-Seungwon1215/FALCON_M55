	.syntax	unified
	.file	"sha3_cm55.s"
	.text

@ =======================================================================
@ void fndsa_sha3_inject_chunk(void *dst, const void *src, size_t len)
@ =======================================================================

	.align	2
	.global	fndsa_sha3_inject_chunk
	.thumb
	.thumb_func
	.type	fndsa_sha3_inject_chunk, %function
fndsa_sha3_inject_chunk:
	push	{ r4, r5 }

	@ If less than 8 bytes to inject, do it byte-by-byte.
	cmp	r2, #8
	blo	fndsa_sha3_inject_chunk__L4

	@ Process some bytes until the destination is aligned.
	rsbs	r5, r0, #0
	ands	r5, r5, #3
	beq	fndsa_sha3_inject_chunk__L2
	subs	r2, r5
fndsa_sha3_inject_chunk__L1:
	ldrb.w	r3, [r0]
	ldrb	r4, [r1], #1
	eor	r3, r3, r4
	strb	r3, [r0], #1
	subs	r5, #1
	bne	fndsa_sha3_inject_chunk__L1

fndsa_sha3_inject_chunk__L2:
	@ Destination is aligned. Source might be unaligned, but the
	@ Cortex-M4 tolerates unaligns accesses with a penalty which is
	@ lower than doing word reassembly in software.
	lsr	r5, r2, #2
fndsa_sha3_inject_chunk__L3:
	ldr.w	r3, [r0]
	ldr	r4, [r1], #4
	eor	r3, r3, r4
	str	r3, [r0], #4
	subs	r5, #1
	bne	fndsa_sha3_inject_chunk__L3

	@ We may have a remaining tail of up to 3 bytes.
	ands	r2, r2, #3
	beq.w	fndsa_sha3_inject_chunk__L5

fndsa_sha3_inject_chunk__L4:
	@ Byte-by-byte processing for the data tail.
	ldrb.w	r3, [r0]
	ldrb	r4, [r1], #1
	eor	r3, r3, r4
	strb	r3, [r0], #1
	subs	r2, #1
	bne	fndsa_sha3_inject_chunk__L4

fndsa_sha3_inject_chunk__L5:
	pop	{ r4, r5 }
	bx	lr
	.size	fndsa_sha3_inject_chunk,.-fndsa_sha3_inject_chunk

@ =======================================================================
@ bit_split_5(uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4)
@ Split inputs x0 to x4 into even-indexed and odd-indexed bits.
@ Internal function only; non-standard ABI:
@ input:
@    r0:r1    x0
@    r2:r3    x1
@    r4:r5    x2
@    r6:r7    x3
@    r10:r11  x4
@ ASPR.GE flags must have pattern 0110.
@
@ output:
@    r0     even-indexed bits of x0
@    r1     odd-indexed bits of x0
@    r2     even-indexed bits of x1
@    r3     odd-indexed bits of x1
@    r4     even-indexed bits of x2
@    r5     odd-indexed bits of x2
@    r6     even-indexed bits of x3
@    r7     odd-indexed bits of x3
@    r10    even-indexed bits of x4
@    r11    odd-indexed bits of x4
@ clobbers:
@    r8, r14
@
@ bit_split_1, bit_split_2, bit_split_3 and bit_split_4 are alternate
@ entry points that process only the first 1, 2, 3 or 4 words.
@ =======================================================================

	@ This macro splits a word (input register xx) into its
	@ even-indexed bits (into the low half of output register dd)
	@ and odd-indexed bits (high half of dd).
	@ This macro assumes that the ASPR.GE flags have the 0110 pattern.
	@ dd and xx cannot be the same register. xx is consumed.
.macro	BIT_SPLIT_32  xx, dd
	eor	\dd, \xx, \xx, lsr #1
	and	\dd, \dd, #0x22222222
	eor	\xx, \xx, \dd
	eor	\xx, \xx, \dd, lsl #1
	eor	\dd, \xx, \xx, lsr #2
	and	\dd, \dd, #0x0C0C0C0C
	eor	\xx, \xx, \dd
	eor	\xx, \xx, \dd, lsl #2
	eor	\dd, \xx, \xx, lsr #4
	and	\dd, \dd, #0x00F000F0
	eor	\xx, \xx, \dd
	eor	\xx, \xx, \dd, lsl #4
	rev	\dd, \xx
	sel	\dd, \dd, \xx
.endm

	@ Split a 64-bit value x0:x1 into its even-indexed bits (into x0)
	@ and high-indexed bits (into x1). xt is a scratch register.
	@ This macro assumes that the ASPR.GE flags have the 0110 pattern.
.macro	BIT_SPLIT_64  x0, x1, xt
	BIT_SPLIT_32  \x0, \xt
	BIT_SPLIT_32  \x1, \x0
	pkhtb	\x1, \x0, \xt, asr #16
	pkhbt	\x0, \xt, \x0, lsl #16
.endm

	.align	2
	.thumb
	.thumb_func
	.type	bit_split_5, %function
bit_split_5:
	BIT_SPLIT_64	r10, r11, r8
bit_split_4:
	BIT_SPLIT_64	r6,  r7,  r8
bit_split_3:
	BIT_SPLIT_64	r4,  r5,  r8
bit_split_2:
	BIT_SPLIT_64	r2,  r3,  r8
bit_split_1:
	BIT_SPLIT_64	r0,  r1,  r8
	bx	lr
	.size	bit_split_5, .-bit_split_5

@ =======================================================================
@ bit_merge_5(uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4)
@ Merge inputs x0 to x4 with bit interleaving. For i = 0 to 4, the
@ low word of x_i contains the even-indexed bits, and the high word
@ contains the odd-indexed bits.
@ Internal function only; non-standard ABI:
@ input:
@    r0:r1    x0
@    r2:r3    x1
@    r4:r5    x2
@    r6:r7    x3
@    r10:r11  x4
@ ASPR.GE flags must have pattern 0110.
@
@ output:
@    r0:r1    merged x0
@    r2:r3    merged x1
@    r4:r5    merged x2
@    r6:r7    merged x3
@    r10:r11  merged x4
@ clobbers:
@    r8, r14
@
@ bit_merge_1, bit_merge_2, bit_merge_3 and bit_merge_4 are alternate
@ entry points that process only the first 1, 2, 3 or 4 words.
@ =======================================================================

	@ This macro merges a word (input register xx): low half yields
	@ the even-indexed bits, and hight half provides the odd-indexed
	@ bits. Output is written into register dd.
	@ This macro assumes that the ASPR.GE flags have the 0110 pattern.
	@ dd and xx cannot be the same register. xx is consumed.
.macro	BIT_MERGE_32  xx, dd
	rev	\dd, \xx
	sel	\xx, \dd, \xx
	eor	\dd, \xx, \xx, lsr #4
	and	\dd, \dd, #0x00F000F0
	eor	\xx, \xx, \dd
	eor	\xx, \xx, \dd, lsl #4
	eor	\dd, \xx, \xx, lsr #2
	and	\dd, \dd, #0x0C0C0C0C
	eor	\xx, \xx, \dd
	eor	\xx, \xx, \dd, lsl #2
	eor	\dd, \xx, \xx, lsr #1
	and	\dd, \dd, #0x22222222
	eor	\xx, \xx, \dd
	eor	\dd, \xx, \dd, lsl #1
.endm

	@ BIT_MERGE_64 interleaves the bits from x0 and from x1, result
	@ is written back to x0:x1. xt is a scratch register.
	@ This macro assumes that the ASPR.GE flags have the 0110 pattern.
.macro	BIT_MERGE_64  x0, x1, xt
	pkhtb	\xt, \x1, \x0, asr #16
	pkhbt	\x1, \x0, \x1, lsl #16
	BIT_MERGE_32	\x1, \x0
	BIT_MERGE_32	\xt, \x1
.endm

	.align	2
	.thumb
	.thumb_func
	.type	bit_merge_5, %function
bit_merge_5:
	BIT_MERGE_64	r10, r11, r8
bit_merge_4:
	BIT_MERGE_64	r6,  r7,  r8
bit_merge_3:
	BIT_MERGE_64	r4,  r5,  r8
bit_merge_2:
	BIT_MERGE_64	r2,  r3,  r8
bit_merge_1:
	BIT_MERGE_64	r0,  r1,  r8
	bx	lr
	.size	bit_merge_5, .-bit_merge_5

@ =======================================================================
@ void fndsa_sha3_process_block(uint64_t *A, unsigned r)
@
@ Single-state MVE Keccak-f[1600]. No floating-point arithmetic.
@ The bit_split/bit_merge and inject routines above are unchanged.
@
@ Compatibility with this repository's original sha3_cm4.s boundary:
@ lanes 0..20 are canonical uint64_t, lanes 21..24 are even/odd interleaved.
@ Its BL-overwritten LR makes all supported rates use this same boundary.
@ Preserve that representation; r remains the caller's SHAKE/SHA3 rate.
@
@ Inside this function, a lane is (even32, odd32). The 5 rows have an
@ eight-word stride, with separate even/odd planes. Four columns use MVE;
@ the fifth uses scalar instructions. rho/pi uses exact scalar rotations.
@
@ Stack (16-byte aligned): A[320], B[320], C[64], metadata[16].
@ A/B even plane: +0; odd plane: +164; row stride 32 bytes.
@ Q0-Q7 alias D0-D15: no live state is kept in D registers across MVE ops.
@ Public loop count: 24 rounds. All addresses/rotations are input-independent.
@ theta injection is fused into rho/pi, chi accumulates the next column
@ parity, and iota is deferred in r7:r12 until the next reads (or final exit).
@ Scalar fifth-column work is interleaved with independent MVE operations.
@ The odd plane starts at +164, an empirically selected 4-byte skew.
@ =======================================================================

.equ K_A,       0
.equ K_B,       320
.equ K_C,       640
.equ K_STATE,   768
.equ K_OLDSP,   772
.equ K_FRAME,   784
.equ K_REV,     1

@ Marshal one row between private helper register ABI and internal SoA.
.macro K_STORE_ROW row
    str r0,  [sp,#(32*(\row)+12)]
    str r2,  [sp,#(32*(\row)+8)]
    str r4,  [sp,#(32*(\row)+4)]
    str r6,  [sp,#(32*(\row)+0)]
    str r10, [sp,#(32*(\row)+16)]
    str r1,  [sp,#(164+32*(\row)+12)]
    str r3,  [sp,#(164+32*(\row)+8)]
    str r5,  [sp,#(164+32*(\row)+4)]
    str r7,  [sp,#(164+32*(\row)+0)]
    str r11, [sp,#(164+32*(\row)+16)]
.endm
.macro K_LOAD_ROW row
    ldr r0,  [sp,#(32*(\row)+12)]
    ldr r2,  [sp,#(32*(\row)+8)]
    ldr r4,  [sp,#(32*(\row)+4)]
    ldr r6,  [sp,#(32*(\row)+0)]
    ldr r10, [sp,#(32*(\row)+16)]
    ldr r1,  [sp,#(164+32*(\row)+12)]
    ldr r3,  [sp,#(164+32*(\row)+8)]
    ldr r5,  [sp,#(164+32*(\row)+4)]
    ldr r7,  [sp,#(164+32*(\row)+0)]
    ldr r11, [sp,#(164+32*(\row)+16)]
.endm

@ theta: C[x] = XOR of column x.
.macro K_PARITY_ROW row
    vldrw.u32 q2,[r4,#(32*(\row))]
    vldrw.u32 q3,[r4,#(164+32*(\row))]
    veor q0,q0,q2
    veor q1,q1,q3
    ldr r2,[r4,#(32*(\row)+16)]
    ldr r3,[r4,#(164+32*(\row)+16)]
    eor r0,r0,r2
    eor r1,r1,r3
.endm
@ Fuse theta injection with rho/pi. One D column stays in r8:r9
@ while all five input lanes in that column are rotated and scattered.
.macro K_COLUMN prev, next
    .if (\prev)==4
        ldr r0,[r6,#16]
        ldr r1,[r6,#48]
    .else
        ldr r0,[r6,#(12-4*(\prev))]
        ldr r1,[r6,#(44-4*(\prev))]
    .endif
    .if (\next)==4
        ldr r2,[r6,#16]
        ldr r3,[r6,#48]
    .else
        ldr r2,[r6,#(12-4*(\next))]
        ldr r3,[r6,#(44-4*(\next))]
    .endif
    .if (\prev)==0
        eor r0,r0,r7
        eor r1,r1,r12
    .endif
    .if (\next)==0
        eor r2,r2,r7
        eor r3,r3,r12
    .endif
    eor r8,r0,r3,ror #31
    eor r9,r1,r2
.endm

@ rho/pi: B[y,2*x+3*y] = ROL64(A[x,y], rot).
@ Odd rotations exchange the even/odd planes; no carry or FP conversion.
.macro K_RHOPI x, y, rot
    .if (\x)==4
        ldr r0,[r4,#(32*(\y)+16)]
        ldr r1,[r4,#(164+32*(\y)+16)]
    .else
        ldr r0,[r4,#(32*(\y)+12-4*(\x))]
        ldr r1,[r4,#(164+32*(\y)+12-4*(\x))]
    .endif
    .if ((\x)==0)&&((\y)==0)
        eor r0,r0,r7
        eor r1,r1,r12
    .endif
    eor r0,r0,r8
    eor r1,r1,r9
    .if ((\rot)&1)
        .if (((\rot)+1)/2) != 32
            ror r1,r1,#(32-(((\rot)+1)/2))
        .endif
        .if ((\rot)/2) != 0
            ror r0,r0,#(32-((\rot)/2))
        .endif
        .if (\y)==4
            str r1,[r5,#(32*((2*(\x)+3*(\y))%5)+16)]
            str r0,[r5,#(164+32*((2*(\x)+3*(\y))%5)+16)]
        .else
            str r1,[r5,#(32*((2*(\x)+3*(\y))%5)+12-4*(\y))]
            str r0,[r5,#(164+32*((2*(\x)+3*(\y))%5)+12-4*(\y))]
        .endif
    .else
        .if (\rot)!=0
            ror r0,r0,#(32-((\rot)/2))
            ror r1,r1,#(32-((\rot)/2))
        .endif
        .if (\y)==4
            str r0,[r5,#(32*((2*(\x)+3*(\y))%5)+16)]
            str r1,[r5,#(164+32*((2*(\x)+3*(\y))%5)+16)]
        .else
            str r0,[r5,#(32*((2*(\x)+3*(\y))%5)+12-4*(\y))]
            str r1,[r5,#(164+32*((2*(\x)+3*(\y))%5)+12-4*(\y))]
        .endif
    .endif
.endm

@ chi: four columns in parallel; the fifth scalar. B has a copy of
@ column zero at column five, so the unaligned vector window stays in-row.
@ Schedule the scalar tail through MVE loads/ALU operations rather than
@ after the entire vector sequence. Q6/Q7 and r8/r9 accumulate column XORs.
.macro K_CHI_ROW row
    vldrw.u32 q0,[r5,#(32*(\row))]
    ldr r0,[r5,#(32*(\row)+16)]
    mov r1,r0
    vorr q1,q0,q0
    vshlc q1,r0,#32
    mov r2,r0
    vorr q2,q1,q1
    vshlc q2,r0,#32
    vbic q2,q2,q1
    veor q0,q0,q2
    bic r0,r0,r2
    eor r1,r1,r0
    veor q6,q6,q0
    eor r8,r8,r1
    vstrw.32 q0,[r4,#(32*(\row))]
    str r1,[r4,#(32*(\row)+16)]
    vldrw.u32 q0,[r5,#(164+32*(\row))]
    ldr r0,[r5,#(164+32*(\row)+16)]
    mov r1,r0
    vorr q1,q0,q0
    vshlc q1,r0,#32
    mov r2,r0
    vorr q2,q1,q1
    vshlc q2,r0,#32
    vbic q2,q2,q1
    veor q0,q0,q2
    bic r0,r0,r2
    eor r1,r1,r0
    veor q7,q7,q0
    eor r9,r9,r1
    vstrw.32 q0,[r4,#(164+32*(\row))]
    str r1,[r4,#(164+32*(\row)+16)]
.endm

.macro K_VECTOR_ROW row, col, rot
    vldrw.u32 q2,[r3]
    vldrw.u32 q3,[r3,#16]
    vldrw.u32 q0,[r4,q2]
    vldrw.u32 q1,[r4,q3]
    vldrw.u32 q2,[r3,#32]
    vldrw.u32 q3,[r3,#48]
    vldrw.u32 q4,[r6,q2]
    vldrw.u32 q5,[r6,q3]
    veor q0,q0,q4
    veor q1,q1,q5
    vmov.i32 q4,#32
    vldrw.u32 q6,[r3,#64]
    vshl.u32 q2,q0,q6
    vsub.i32 q6,q6,q4
    vshl.u32 q0,q0,q6
    vorr q0,q0,q2
    vldrw.u32 q6,[r3,#80]
    vshl.u32 q2,q1,q6
    vsub.i32 q6,q6,q4
    vshl.u32 q1,q1,q6
    vorr q1,q1,q2
    .if (\col)==4
        ldr r0,[r4,#144]
        ldr r1,[r4,#308]
    .else
        ldr r0,[r4,#(140-4*(\col))]
        ldr r1,[r4,#(304-4*(\col))]
    .endif
    ldr r8,[r6,#(4*(\col))]
    ldr r9,[r6,#(32+4*(\col))]
    eor r0,r0,r8
    eor r1,r1,r9
    .if ((\rot)&1)
        ror r1,r1,#(32-(((\rot)+1)/2))
        ror r0,r0,#(32-((\rot)/2))
        mov r2,r0
        mov r0,r1
        mov r1,r2
    .else
        ror r0,r0,#(32-((\rot)/2))
        ror r1,r1,#(32-((\rot)/2))
    .endif
    mov r8,r0
    mov r9,r1
    vorr q2,q0,q0
    vshlc q2,r0,#32
    mov r2,r0
    vorr q3,q2,q2
    vshlc q3,r0,#32
    vbic q3,q3,q2
    veor q0,q0,q3
    bic r0,r0,r2
    eor r8,r8,r0
    vorr q2,q1,q1
    vshlc q2,r1,#32
    mov r2,r1
    vorr q3,q2,q2
    vshlc q3,r1,#32
    vbic q3,q3,q2
    veor q1,q1,q3
    bic r1,r1,r2
    eor r9,r9,r1
    vstrw.32 q0,[r5,#(32*(\row))]
    vstrw.32 q1,[r5,#(164+32*(\row))]
    str r8,[r5,#(32*(\row)+16)]
    str r9,[r5,#(164+32*(\row)+16)]
    .if (\row)!=0
        vldrw.u32 q4,[r7]
        vldrw.u32 q5,[r7,#32]
        ldr r0,[r7,#16]
        ldr r1,[r7,#48]
        veor q0,q0,q4
        veor q1,q1,q5
        eor r8,r8,r0
        eor r9,r9,r1
    .endif
    vstrw.32 q0,[r7]
    vstrw.32 q1,[r7,#32]
    str r8,[r7,#16]
    str r9,[r7,#48]
    add r3,r3,#96
.endm

.align 2
.global fndsa_sha3_process_block
.thumb
.thumb_func
.type fndsa_sha3_process_block,%function
fndsa_sha3_process_block:
    push.w {r4-r11,lr}
    sub sp,sp,#4
    vpush {d8-d15}
    mov r2,sp
    sub.w r3,r2,#K_FRAME
    bic r3,r3,#15
    mov sp,r3
    str r2,[sp,#K_OLDSP]
    str r0,[sp,#K_STATE]
    mov r12,r0

    movw r7,#0xff00
    movt r7,#0x00ff
    uadd8 r7,r7,r7
    ldm r12!,{r0-r7,r10,r11}
    bl bit_split_5
    K_STORE_ROW 0
    ldm r12!,{r0-r7,r10,r11}
    bl bit_split_5
    K_STORE_ROW 1
    ldm r12!,{r0-r7,r10,r11}
    bl bit_split_5
    K_STORE_ROW 2
    ldm r12!,{r0-r7,r10,r11}
    bl bit_split_5
    K_STORE_ROW 3
    ldm r12!,{r0-r7,r10,r11}
    bl bit_split_1
    K_STORE_ROW 4

    mov r4,sp
    add.w r5,r4,#K_B
    add.w r6,r4,#K_C
    adr.w r10,.Lkeccak_mve_rc
    vldrw.u32 q0,[r4]
    vldrw.u32 q1,[r4,#164]
    ldr r0,[r4,#16]
    ldr r1,[r4,#180]
    K_PARITY_ROW 1
    K_PARITY_ROW 2
    K_PARITY_ROW 3
    K_PARITY_ROW 4
    vstrw.32 q0,[r6]
    vstrw.32 q1,[r6,#32]
    str r0,[r6,#16]
    str r1,[r6,#48]

    @ Carry iota lazily into the next theta and rho/pi reads of lane 0.
    @ A/C in memory omit only the pending constant r7:r12.
    movs r7,#0
    movs r12,#0
    movs r11,#24
.Lkeccak_mve_round:
    ldr r0,[r4,#12]
    ldr r1,[r4,#176]
    eor r0,r0,r7
    eor r1,r1,r12
    str r0,[r4,#12]
    str r1,[r4,#176]
    K_COLUMN 4,1
    str r8,[sp,#704]
    str r9,[sp,#736]
    K_COLUMN 0,2
    str r8,[sp,#708]
    str r9,[sp,#740]
    K_COLUMN 1,3
    str r8,[sp,#712]
    str r9,[sp,#744]
    K_COLUMN 2,4
    str r8,[sp,#716]
    str r9,[sp,#748]
    K_COLUMN 3,0
    str r8,[sp,#720]
    str r9,[sp,#752]
    add.w r6,sp,#704
    movw r3,#:lower16:.Lkeccak_gather_table
    movt r3,#:upper16:.Lkeccak_gather_table
    add.w r7,sp,#K_C
    K_VECTOR_ROW 0,4,14
    K_VECTOR_ROW 1,2,61
    K_VECTOR_ROW 2,0,18
    K_VECTOR_ROW 3,3,56
    K_VECTOR_ROW 4,1,2
    add.w r6,sp,#K_C

    mov r0,r4
    mov r4,r5
    mov r5,r0
    ldm r10!,{r7,r12}
    subs r11,r11,#1
    bne.w .Lkeccak_mve_round

    @ Materialize the final round constant before returning the state.
    ldr r0,[r4,#12]
    ldr r1,[r4,#176]
    eor r0,r0,r7
    eor r1,r1,r12
    str r0,[r4,#12]
    str r1,[r4,#176]
    ldr r12,[sp,#K_STATE]
    K_LOAD_ROW 0
    bl bit_merge_5
    stm r12!,{r0-r7,r10,r11}
    K_LOAD_ROW 1
    bl bit_merge_5
    stm r12!,{r0-r7,r10,r11}
    K_LOAD_ROW 2
    bl bit_merge_5
    stm r12!,{r0-r7,r10,r11}
    K_LOAD_ROW 3
    bl bit_merge_5
    stm r12!,{r0-r7,r10,r11}
    K_LOAD_ROW 4
    bl bit_merge_1
    stm r12!,{r0-r7,r10,r11}

    ldr r2,[sp,#K_OLDSP]
    mov sp,r2
    vpop {d8-d15}
    add sp,sp,#4
    pop.w {r4-r11,pc}

.align 2
.Lkeccak_mve_rc:
    .word 0x00000001,0x00000000
    .word 0x00000000,0x00000089
    .word 0x00000000,0x8000008B
    .word 0x00000000,0x80008080
    .word 0x00000001,0x0000008B
    .word 0x00000001,0x00008000
    .word 0x00000001,0x80008088
    .word 0x00000001,0x80000082
    .word 0x00000000,0x0000000B
    .word 0x00000000,0x0000000A
    .word 0x00000001,0x00008082
    .word 0x00000000,0x00008003
    .word 0x00000001,0x0000808B
    .word 0x00000001,0x8000000B
    .word 0x00000001,0x8000008A
    .word 0x00000001,0x80000081
    .word 0x00000000,0x80000081
    .word 0x00000000,0x80000008
    .word 0x00000000,0x00000083
    .word 0x00000000,0x80008003
    .word 0x00000001,0x80008088
    .word 0x00000000,0x80000088
    .word 0x00000001,0x00008000
    .word 0x00000000,0x80008082
.size fndsa_sha3_process_block,.-fndsa_sha3_process_block

.section .rodata.keccak_gather,"a",%progbits
.align 4
.Lkeccak_gather_table:
    .word 260,232,40,12
    .word 96,68,204,176
    .word 44,40,4,0
    .word 12,8,36,32
    .word 11,22,22,0
    .word 10,21,22,0
    .word 268,240,48,0
    .word 104,76,212,164
    .word 36,32,16,12
    .word 4,0,48,44
    .word 23,2,10,14
    .word 22,1,10,14
    .word 112,228,36,172
    .word 276,64,200,8
    .word 16,44,8,36
    .word 48,12,40,4
    .word 4,13,3,1
    .word 4,12,3,0
    .word 264,72,44,180
    .word 100,236,208,16
    .word 40,4,0,48
    .word 8,36,32,16
    .word 8,5,18,14
    .word 7,5,18,13
    .word 272,244,196,4
    .word 108,80,32,168
    .word 32,48,44,8
    .word 0,16,12,40
    .word 21,20,28,31
    .word 20,19,27,31

@ Test-only adapters appended after the complete, unmodified sha3_cm4.s.
@ Separate section: original .text must remain byte-for-byte identical.
@ Helpers have private register ABI. Every adapter restores the C ABI.
.section .text.keccak_bench,"ax",%progbits
.thumb

.macro HELPER_BENCH name, target, group=0
.balign 32
.global \name
.type \name,%function
.thumb_func
\name:
    push.w {r4-r11,lr}
    sub sp,sp,#20
    str r0,[sp,#0]
    mov r9,r1
    movw r7,#0xff00
    movt r7,#0x00ff
    uadd8 r7,r7,r7             @ APSR.GE = 0110
    mov r12,r0
    ldm r12,{r0-r7,r10,r11}
    movw r12,#0x1004
    movt r12,#0xe000           @ DWT_CYCCNT, helpers preserve r12
    dsb
    isb
    ldr r8,[r12]
    str r8,[sp,#8]
1:
.ifnc \target,none
    bl \target
.if \group
    bl \target
    bl \target
    bl \target
.ifc \target,bit_split_5
    bl bit_split_1
.else
    bl bit_merge_1
.endif
.endif
.endif
    subs r9,r9,#1
    bne 1b
    ldr r8,[r12]
    ldr r9,[sp,#8]
    sub r8,r8,r9
    str r8,[sp,#12]
    ldr r12,[sp,#0]
    stm r12,{r0-r7,r10,r11}
    ldr r0,[sp,#12]
    add sp,sp,#20
    pop.w {r4-r11,pc}
.size \name,.-\name
.endm

HELPER_BENCH bench_split1,bit_split_1
HELPER_BENCH bench_split2,bit_split_2
HELPER_BENCH bench_split3,bit_split_3
HELPER_BENCH bench_split4,bit_split_4
HELPER_BENCH bench_split5,bit_split_5
HELPER_BENCH bench_merge1,bit_merge_1
HELPER_BENCH bench_merge2,bit_merge_2
HELPER_BENCH bench_merge3,bit_merge_3
HELPER_BENCH bench_merge4,bit_merge_4
HELPER_BENCH bench_merge5,bit_merge_5
HELPER_BENCH bench_split_group,bit_split_5,1
HELPER_BENCH bench_merge_group,bit_merge_5,1
HELPER_BENCH bench_helper_empty,none

.macro PROCESS_BENCH name, do_call
.balign 32
.global \name
.type \name,%function
.thumb_func
\name:
    push {r4-r8,lr}
    mov r4,r0
    mov r5,r1
    movw r6,#0x1004
    movt r6,#0xe000
    dsb
    isb
    ldr r7,[r6]
1:
    mov r0,r4
    movs r1,#17                @ SHAKE256 rate, in 64-bit words
.if \do_call
    bl fndsa_sha3_process_block
.endif
    subs r5,r5,#1
    bne 1b
    ldr r0,[r6]
    subs r0,r0,r7
    pop {r4-r8,pc}
.size \name,.-\name
.endm
PROCESS_BENCH bench_process,1
PROCESS_BENCH bench_process_empty,0

@ Test callee-saved GPRs and the overlapping D8-D15/Q4-Q7 register bank.
.balign 32
.global bench_abi
.type bench_abi,%function
.thumb_func
bench_abi:
    push.w {r4-r11,lr}
    sub sp,sp,#4
    vpush {d8-d15}
    sub sp,sp,#72
    str r0,[sp,#64]
    movs r4,#4
    movs r5,#5
    movs r6,#6
    movs r7,#7
    movs r8,#8
    movs r9,#9
    movs r10,#10
    movs r11,#11
    vmov d8,r4,r4
    vmov d9,r4,r4
    vmov d10,r5,r5
    vmov d11,r5,r5
    vmov d12,r6,r6
    vmov d13,r6,r6
    vmov d14,r7,r7
    vmov d15,r7,r7
    ldr r0,[sp,#64]
    movs r1,#17
    bl fndsa_sha3_process_block
    movs r0,#0
.irp reg,4,5,6,7,8,9,10,11
    cmp r\reg,#\reg
    it ne
    movne r0,#1
.endr
    mov r1,sp
    vstmia r1,{d8-d15}
    movs r2,#0
1:
    ldr r3,[r1,r2,lsl #2]
    lsr r12,r2,#2
    add r12,r12,#4
    cmp r3,r12
    it ne
    movne r0,#1
    adds r2,r2,#1
    cmp r2,#16
    bne 1b
    add sp,sp,#72
    vpop {d8-d15}
    add sp,sp,#4
    pop.w {r4-r11,pc}
.size bench_abi,.-bench_abi
