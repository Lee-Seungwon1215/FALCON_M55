# Stage-4 combination validation

검사일: 2026-09-13

12개 조합은 각 디렉터리의 `mq_cm55.s`를 직접 컴파일했다. 조합을 위해
다른 후보 파일을 include하거나 Makefile/CMake에서 어셈블리 조각을 선택하지
않는다. 공통 NUCLEO 시험 harness는 완성된 조합 디렉터리 전체를
`FNDSA_SOURCE_DIR`로 지정하고 `mq_cm55.s` 하나를 컴파일했다.

## 조건과 결과

- 보드: NUCLEO-N657X0-Q, Cortex-M55 r1p1
- clock: CPU 800 MHz, SYSCLK 400 MHz, HCLK 200 MHz
- 코드 ITCM, 데이터·스택 DTCM, I/D cache off
- GNU Arm 15.2.1, Zephyr 4.4.1, `-O3`
- 12/12 M55/MVE 조립 PASS
- 12/12 전체 firmware link PASS
- 12/12 board pilot 완료
- 각 pilot의 512/1024 forward NTT, inverse round-trip 및 oracle
  round-trip mismatch 0, 최대 modular error 0
- 모든 조합의 고정-seed digest 동일
  - 512: `9fd7c627fa100863e8f684339f3eb3835fc55a24066f4dd34aea05d555d8eadd`
  - 1024: `c543754d19ef263221b2316acac8ad5c34502886750fdd5bfffd4f5487c018bb`
- 12/12 키생성·서명·검증 및 1-bit 변조 서명 거부 PASS
- main stack 사용 상한 9,624 B
- 정적 상수시간 구조 감사 PASS: 새 결합 매크로에 입력값 의존 branch나
  주소 선택 없음. 전력/EM TVLA는 수행하지 않음.

## 직접 구현된 소스 식별값

| 조합 | `mq_cm55.s` SHA-256 | ELF text bytes |
|---|---|---:|
| S1A_S2A_S3A | `553bf43211745132143809bf0f327e6b971635e86f2648da83bbdd901a5d449e` | 167,708 |
| S1A_S2A_S3B | `f1eff086ebd221a924b762f731256a71e1d91d24ba93024e1023114fe4248148` | 167,708 |
| S1A_S2A_S3C | `1c51f32686f307a74c380daa7fe90d5deed447b894101a979b613d8841fb1515` | 169,948 |
| S1A_S2B_S3A | `7dd199b6e2820544f511f70d701647278a3c61d631d0d8ca791d3a9b3c7a5acc` | 167,708 |
| S1A_S2B_S3B | `d13fe9cffe9eac0c2afbfcc33ac769d20ea322bbffcb8d8e22e098d67abb111f` | 167,708 |
| S1A_S2B_S3C | `d4b5a64bd8534f58b96c966eaeedffd78c142ab78b3dd8c413e647a6a3ec5251` | 169,964 |
| S1B_S2A_S3A | `f3aba71a0dad66e7faaedfa921651822cf91d55fc33ba06355bc7e5732e6f0ce` | 167,708 |
| S1B_S2A_S3B | `133e8834985aacd7d0eff7f61083a3bb098a3ca5b239ac9ddfb95a4a1d1cee18` | 167,708 |
| S1B_S2A_S3C | `e15e8ea21ce0574ba089efd428ada23bcc8112be3e075ca9ea977786e05b8eae` | 169,948 |
| S1B_S2B_S3A | `ef24c608d398ad09bd057694f3997ca9cea23b2e4a516362a1b2904699a008b7` | 167,708 |
| S1B_S2B_S3B | `3fb96e36617998c4886b03df3b3c47348c54c272679fc2cc4ed68f46cb1c0d58` | 167,708 |
| S1B_S2B_S3C | `cc72a466e1d18bad2e56bc2d142ab56a0475df3f7890758401c700feea0ef774` | 169,964 |

Pilot은 correctness gate이며 성능 순위용 표본이 아니다. 후보 선택에는
각 조합의 10 batches × 10 measured calls full 측정이 추가로 필요하다.
