# A: double surrounding arithmetic, local MVE FFT bridge

Initial implementation; not yet a performance winner or final adopted code.

- Baseline integer/NTT/signature sources were copied from `ntt_opt`.
- TW integration candidate supplied the NTRU double approximation arithmetic
  (`kgen_ntru.c`, `kgen_poly.c`, `kgen_inner.h`, `kgen_fxp.c`).
- Public fixed-point FFT/invnorm interfaces and the original candidate norm
  check were restored. Only NTRU uses the experimental FP path.
- FFT/iFFT call this tree's `kgen_fft_bridge.c`, `kgen_fft_mve.c` and
  `kgen_fft_cm55.s`, derived from 4.3. No other candidate is linked.
- The bridge uses a reentrant 8 KiB stack workspace. Double/DS conversions are
  included in its call cost. The original TW static 3-plane workspace is absent.
- M55 original keygen KAT 300/300 passed on 2026-09-27:
  `../validation/results/A_tw_bridge/kat/20260927T140736Z`.
- Whole performance, extra-seed KAT, signatures, numerical edge cases and timing
  audits remain pending. KAT is not an all-input equivalence proof.

`origin.json` records the INITIAL ntt_opt snapshot, not the modified source hash.
Every board run archives current source hashes and the exact ELF in its manifest.
