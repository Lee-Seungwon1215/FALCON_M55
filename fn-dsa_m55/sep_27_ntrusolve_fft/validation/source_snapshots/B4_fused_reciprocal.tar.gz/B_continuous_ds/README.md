# B: continuous two-FP32 NTRU approximation

Initial implementation; no new optimization result yet.

- Integer/NTT/signature sources and fixed-point candidate norm checking come
  from the local ntt_opt snapshot.
- `kgen_ntru.c`, `kgen_fft_mve.c`, `kgen_fft_cm55.s`, `kgen_ds.h` and
  `kgen_ds_q32.h` originate from 4.3's Q32-compatible continuous DS path.
- The out-of-scope invnorm optimization in 4.3's `kgen_fxp.c` was NOT copied.
- Every production dependency is inside this folder. No cross-candidate link
  and no compile-time FFT backend selection are used.
- Repeated scalar Q32 grid/normalize operations are a known performance
  hypothesis to investigate. No shortcut is accepted without correctness tests.

`origin.json` records the INITIAL ntt_opt snapshot; board manifests record the
actual built source hashes. This new path still requires its own validations.
