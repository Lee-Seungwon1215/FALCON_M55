# A4 — measured hybrid from the A branch

This folder name records the original TW + DS-bridge experiment. The CURRENT
NTRU intermediate function has been restored byte-for-byte from the frozen
ntt_opt source, because every measured intermediate size lost after including
its surrounding work. Only solve_NTRU_depth0 uses double preparation, the local
DS MVE FFT bridge, native FP64 division and checked integer rounding.

No new optimization of candidate orthonorm/invnorm, NTT, CRT, Bezout, signing
or verification. No secret-dependent precision fallback, no SLOTHY. Everything
is implemented in this source tree, not selected from another tree by linker
or build backend flags. The generated instrumentation lives under validation.

A0 original bridge, A1 small fixed, A2 fused point multiply, and A3 direct
native FP64 control are archived under ../validation/source_snapshots. Public
support routines from those experiments remain here for reproducibility;
unused functions are NOT credited as executed optimizations. This is still
an experimental candidate, not a newly deployed production reference.

See ../result.md for actual measurements and validation limitations.
