/*
 * Computations modulo 31-bit primes.
 */

#include "kgen_inner.h"

#ifndef FNDSA_MVE_MP31
#define FNDSA_MVE_MP31   0
#endif

/* see kgen_inner.h */
uint32_t
mp_div(uint32_t x, uint32_t y, uint32_t p)
{
	uint32_t a = y;
	uint32_t b = p;
	uint32_t u = x;
	uint32_t v = 0;
	for (int i = 0; i < 62; i ++) {
		uint32_t a_odd = -(a & 1);
		uint32_t swap = tbmask(a - b) & a_odd;
		uint32_t t1 = swap & (a ^ b);
		a ^= t1;
		b ^= t1;
		uint32_t t2 = swap & (u ^ v);
		u ^= t2;
		v ^= t2;
		a -= a_odd & b;
		u = mp_sub(u, a_odd & v, p);
		a >>= 1;
		u = mp_half(u, p);
	}

	/* GCD is in b; it is 1 if and only if y was invertible.
	   Otherwise, the GCD is greater than 1. */
	return v & tbmask(b - 2);
}

#if FNDSA_AVX2
/* see ng_inner.h */
TARGET_AVX2
__m256i
mp_div_x8(__m256i ynum, __m256i yden, __m256i yp)
{
	__m256i ya = yden;
	__m256i yb = yp;
	__m256i yu = ynum;
	__m256i yv = _mm256_setzero_si256();
	__m256i y1 = _mm256_set1_epi32(1);
	for (int i = 0; i < 62; i ++) {
		__m256i ya_odd = _mm256_sub_epi32(_mm256_setzero_si256(),
			_mm256_and_si256(ya, y1));
		__m256i yswap = _mm256_and_si256(ya_odd,
			_mm256_srai_epi32(_mm256_sub_epi32(ya, yb), 31));
		__m256i yt1 = _mm256_and_si256(yswap, _mm256_xor_si256(ya, yb));
		ya = _mm256_xor_si256(ya, yt1);
		yb = _mm256_xor_si256(yb, yt1);
		__m256i yt2 = _mm256_and_si256(yswap, _mm256_xor_si256(yu, yv));
		yu = _mm256_xor_si256(yu, yt2);
		yv = _mm256_xor_si256(yv, yt2);
		ya = _mm256_sub_epi32(ya, _mm256_and_si256(ya_odd, yb));
		yu = mp_sub_x8(yu, _mm256_and_si256(ya_odd, yv), yp);
		ya = _mm256_srli_epi32(ya, 1);
		yu = mp_half_x8(yu, yp);
	}

	/* GCD is in yb; it is 1 if and only if yden was invertible.
	   Otherwise, the GCD is greater than 1. */
	return _mm256_and_si256(yv, _mm256_srai_epi32(
		_mm256_sub_epi32(yb, _mm256_set1_epi32(2)), 31));
}

#endif

/*
 * Bit-reversal index table (over 10 bits).
 */
static const uint16_t REV10[] = {
	   0,  512,  256,  768,  128,  640,  384,  896,   64,  576,  320,  832,
	 192,  704,  448,  960,   32,  544,  288,  800,  160,  672,  416,  928,
	  96,  608,  352,  864,  224,  736,  480,  992,   16,  528,  272,  784,
	 144,  656,  400,  912,   80,  592,  336,  848,  208,  720,  464,  976,
	  48,  560,  304,  816,  176,  688,  432,  944,  112,  624,  368,  880,
	 240,  752,  496, 1008,    8,  520,  264,  776,  136,  648,  392,  904,
	  72,  584,  328,  840,  200,  712,  456,  968,   40,  552,  296,  808,
	 168,  680,  424,  936,  104,  616,  360,  872,  232,  744,  488, 1000,
	  24,  536,  280,  792,  152,  664,  408,  920,   88,  600,  344,  856,
	 216,  728,  472,  984,   56,  568,  312,  824,  184,  696,  440,  952,
	 120,  632,  376,  888,  248,  760,  504, 1016,    4,  516,  260,  772,
	 132,  644,  388,  900,   68,  580,  324,  836,  196,  708,  452,  964,
	  36,  548,  292,  804,  164,  676,  420,  932,  100,  612,  356,  868,
	 228,  740,  484,  996,   20,  532,  276,  788,  148,  660,  404,  916,
	  84,  596,  340,  852,  212,  724,  468,  980,   52,  564,  308,  820,
	 180,  692,  436,  948,  116,  628,  372,  884,  244,  756,  500, 1012,
	  12,  524,  268,  780,  140,  652,  396,  908,   76,  588,  332,  844,
	 204,  716,  460,  972,   44,  556,  300,  812,  172,  684,  428,  940,
	 108,  620,  364,  876,  236,  748,  492, 1004,   28,  540,  284,  796,
	 156,  668,  412,  924,   92,  604,  348,  860,  220,  732,  476,  988,
	  60,  572,  316,  828,  188,  700,  444,  956,  124,  636,  380,  892,
	 252,  764,  508, 1020,    2,  514,  258,  770,  130,  642,  386,  898,
	  66,  578,  322,  834,  194,  706,  450,  962,   34,  546,  290,  802,
	 162,  674,  418,  930,   98,  610,  354,  866,  226,  738,  482,  994,
	  18,  530,  274,  786,  146,  658,  402,  914,   82,  594,  338,  850,
	 210,  722,  466,  978,   50,  562,  306,  818,  178,  690,  434,  946,
	 114,  626,  370,  882,  242,  754,  498, 1010,   10,  522,  266,  778,
	 138,  650,  394,  906,   74,  586,  330,  842,  202,  714,  458,  970,
	  42,  554,  298,  810,  170,  682,  426,  938,  106,  618,  362,  874,
	 234,  746,  490, 1002,   26,  538,  282,  794,  154,  666,  410,  922,
	  90,  602,  346,  858,  218,  730,  474,  986,   58,  570,  314,  826,
	 186,  698,  442,  954,  122,  634,  378,  890,  250,  762,  506, 1018,
	   6,  518,  262,  774,  134,  646,  390,  902,   70,  582,  326,  838,
	 198,  710,  454,  966,   38,  550,  294,  806,  166,  678,  422,  934,
	 102,  614,  358,  870,  230,  742,  486,  998,   22,  534,  278,  790,
	 150,  662,  406,  918,   86,  598,  342,  854,  214,  726,  470,  982,
	  54,  566,  310,  822,  182,  694,  438,  950,  118,  630,  374,  886,
	 246,  758,  502, 1014,   14,  526,  270,  782,  142,  654,  398,  910,
	  78,  590,  334,  846,  206,  718,  462,  974,   46,  558,  302,  814,
	 174,  686,  430,  942,  110,  622,  366,  878,  238,  750,  494, 1006,
	  30,  542,  286,  798,  158,  670,  414,  926,   94,  606,  350,  862,
	 222,  734,  478,  990,   62,  574,  318,  830,  190,  702,  446,  958,
	 126,  638,  382,  894,  254,  766,  510, 1022,    1,  513,  257,  769,
	 129,  641,  385,  897,   65,  577,  321,  833,  193,  705,  449,  961,
	  33,  545,  289,  801,  161,  673,  417,  929,   97,  609,  353,  865,
	 225,  737,  481,  993,   17,  529,  273,  785,  145,  657,  401,  913,
	  81,  593,  337,  849,  209,  721,  465,  977,   49,  561,  305,  817,
	 177,  689,  433,  945,  113,  625,  369,  881,  241,  753,  497, 1009,
	   9,  521,  265,  777,  137,  649,  393,  905,   73,  585,  329,  841,
	 201,  713,  457,  969,   41,  553,  297,  809,  169,  681,  425,  937,
	 105,  617,  361,  873,  233,  745,  489, 1001,   25,  537,  281,  793,
	 153,  665,  409,  921,   89,  601,  345,  857,  217,  729,  473,  985,
	  57,  569,  313,  825,  185,  697,  441,  953,  121,  633,  377,  889,
	 249,  761,  505, 1017,    5,  517,  261,  773,  133,  645,  389,  901,
	  69,  581,  325,  837,  197,  709,  453,  965,   37,  549,  293,  805,
	 165,  677,  421,  933,  101,  613,  357,  869,  229,  741,  485,  997,
	  21,  533,  277,  789,  149,  661,  405,  917,   85,  597,  341,  853,
	 213,  725,  469,  981,   53,  565,  309,  821,  181,  693,  437,  949,
	 117,  629,  373,  885,  245,  757,  501, 1013,   13,  525,  269,  781,
	 141,  653,  397,  909,   77,  589,  333,  845,  205,  717,  461,  973,
	  45,  557,  301,  813,  173,  685,  429,  941,  109,  621,  365,  877,
	 237,  749,  493, 1005,   29,  541,  285,  797,  157,  669,  413,  925,
	  93,  605,  349,  861,  221,  733,  477,  989,   61,  573,  317,  829,
	 189,  701,  445,  957,  125,  637,  381,  893,  253,  765,  509, 1021,
	   3,  515,  259,  771,  131,  643,  387,  899,   67,  579,  323,  835,
	 195,  707,  451,  963,   35,  547,  291,  803,  163,  675,  419,  931,
	  99,  611,  355,  867,  227,  739,  483,  995,   19,  531,  275,  787,
	 147,  659,  403,  915,   83,  595,  339,  851,  211,  723,  467,  979,
	  51,  563,  307,  819,  179,  691,  435,  947,  115,  627,  371,  883,
	 243,  755,  499, 1011,   11,  523,  267,  779,  139,  651,  395,  907,
	  75,  587,  331,  843,  203,  715,  459,  971,   43,  555,  299,  811,
	 171,  683,  427,  939,  107,  619,  363,  875,  235,  747,  491, 1003,
	  27,  539,  283,  795,  155,  667,  411,  923,   91,  603,  347,  859,
	 219,  731,  475,  987,   59,  571,  315,  827,  187,  699,  443,  955,
	 123,  635,  379,  891,  251,  763,  507, 1019,    7,  519,  263,  775,
	 135,  647,  391,  903,   71,  583,  327,  839,  199,  711,  455,  967,
	  39,  551,  295,  807,  167,  679,  423,  935,  103,  615,  359,  871,
	 231,  743,  487,  999,   23,  535,  279,  791,  151,  663,  407,  919,
	  87,  599,  343,  855,  215,  727,  471,  983,   55,  567,  311,  823,
	 183,  695,  439,  951,  119,  631,  375,  887,  247,  759,  503, 1015,
	  15,  527,  271,  783,  143,  655,  399,  911,   79,  591,  335,  847,
	 207,  719,  463,  975,   47,  559,  303,  815,  175,  687,  431,  943,
	 111,  623,  367,  879,  239,  751,  495, 1007,   31,  543,  287,  799,
	 159,  671,  415,  927,   95,  607,  351,  863,  223,  735,  479,  991,
	  63,  575,  319,  831,  191,  703,  447,  959,  127,  639,  383,  895,
	 255,  767,  511, 1023
};

/* see kgen_inner.h */
void
mp_mkgmigm(unsigned logn, uint32_t *restrict gm, uint32_t *restrict igm,
	uint32_t g, uint32_t ig, uint32_t p, uint32_t p0i)
{
	size_t n = (size_t)1 << logn;

	/*
	 * We want g^n = -1 mod p, so we may need to square the provided
	 * g and ig a few times if logn < 10.
	 */
	for (unsigned j = logn; j < 10; j ++) {
		g = mp_mmul(g, g, p, p0i);
		ig = mp_mmul(ig, ig, p, p0i);
	}
	unsigned k = 10 - logn;
	uint32_t x1 = mp_R(p);
	/*
	 * The MVE inverse kernel consumes full Montgomery inverse roots and
	 * performs the 1/n scaling once, in its final layer.  Other backends
	 * retain the upstream half-root contract.
	 */
#if FNDSA_MVE_MP31
	uint32_t x2 = mp_R(p);
#else
	uint32_t x2 = mp_hR(p);
#endif
	size_t i = 0;
	for (;;) {
		size_t j = REV10[i << k];
		gm[j] = x1;
		igm[j] = x2;
		i ++;
		if (i >= n) {
			break;
		}
		x1 = mp_mmul(x1, g, p, p0i);
		x2 = mp_mmul(x2, ig, p, p0i);
	}
}

#if FNDSA_AVX2
TARGET_AVX2
void
avx2_mp_mkgmigm(unsigned logn, uint32_t *restrict gm, uint32_t *restrict igm,
	uint32_t g, uint32_t ig, uint32_t p, uint32_t p0i)
{
	size_t n = (size_t)1 << logn;

	/*
	 * We want g^n = -1 mod p, so we may need to square the provided
	 * g and ig a few times if logn < 10.
	 */
	for (unsigned j = logn; j < 10; j ++) {
		g = mp_mmul(g, g, p, p0i);
		ig = mp_mmul(ig, ig, p, p0i);
	}

	if (logn >= 3) {
		/*
		 * If u % 8 == 0, then gm[u + v] = gm[u]*(gx^v) for v = 1..7,
		 * with gx = g^(1024/8) mod p.
		 * (idem for igm[] and igx = ig^(1024/8) mod p)
		 */
		uint32_t gx = g;
		for (unsigned j = 3; j < logn; j ++) {
			gx = mp_mmul(gx, gx, p, p0i);
		}
		uint32_t ya0 = mp_R(p);
		uint32_t ya4 = gx;
		uint32_t ya2 = mp_mmul(ya4, gx, p, p0i);;
		uint32_t ya6 = mp_mmul(ya2, gx, p, p0i);;
		uint32_t ya1 = mp_mmul(ya6, gx, p, p0i);;
		uint32_t ya5 = mp_mmul(ya1, gx, p, p0i);;
		uint32_t ya3 = mp_mmul(ya5, gx, p, p0i);;
		uint32_t ya7 = mp_mmul(ya3, gx, p, p0i);;
		__m256i ya = _mm256_setr_epi32(
			ya0, ya1, ya2, ya3, ya4, ya5, ya6, ya7);
		__m256i yg = _mm256_set1_epi32(g);

		uint32_t igx = ig;
		for (unsigned j = 3; j < logn; j ++) {
			igx = mp_mmul(igx, igx, p, p0i);
		}
		uint32_t yb0 = mp_hR(p);
		uint32_t yb4 = mp_half(igx, p);
		uint32_t yb2 = mp_mmul(yb4, igx, p, p0i);;
		uint32_t yb6 = mp_mmul(yb2, igx, p, p0i);;
		uint32_t yb1 = mp_mmul(yb6, igx, p, p0i);;
		uint32_t yb5 = mp_mmul(yb1, igx, p, p0i);;
		uint32_t yb3 = mp_mmul(yb5, igx, p, p0i);;
		uint32_t yb7 = mp_mmul(yb3, igx, p, p0i);;
		__m256i yb = _mm256_setr_epi32(
			yb0, yb1, yb2, yb3, yb4, yb5, yb6, yb7);
		__m256i yig = _mm256_set1_epi32(ig);

		unsigned k = 10 - logn;
		__m256i yp = _mm256_set1_epi32(p);
		__m256i yp0i = _mm256_set1_epi32(p0i);
		size_t i = 0;
		for (;;) {
			size_t j = REV10[i << k];
			_mm256_storeu_si256(
				(__m256i *)(gm + j), ya);
			_mm256_storeu_si256(
				(__m256i *)(igm + j), yb);
			i ++;
			if (i >= (n >> 3)) {
				break;
			}
			ya = mp_mmul_x8(ya, yg, yp, yp0i);
			yb = mp_mmul_x8(yb, yig, yp, yp0i);
		}
	} else {
		unsigned k = 10 - logn;
		uint32_t x1 = mp_R(p);
		uint32_t x2 = mp_hR(p);
		size_t i = 0;
		for (;;) {
			size_t j = REV10[i << k];
			gm[j] = x1;
			igm[j] = x2;
			i ++;
			if (i >= n) {
				break;
			}
			x1 = mp_mmul(x1, g, p, p0i);
			x2 = mp_mmul(x2, ig, p, p0i);
		}
	}
}
#endif

/* see kgen_inner.h */
void
mp_mkgm(unsigned logn, uint32_t *restrict gm,
	uint32_t g, uint32_t p, uint32_t p0i)
{
	size_t n = (size_t)1 << logn;

	for (unsigned j = logn; j < 10; j ++) {
		g = mp_mmul(g, g, p, p0i);
	}
	unsigned k = 10 - logn;
	uint32_t x1 = mp_R(p);
	size_t i = 0;
	for (;;) {
		size_t j = REV10[i << k];
		gm[j] = x1;
		i ++;
		if (i >= n) {
			break;
		}
		x1 = mp_mmul(x1, g, p, p0i);
	}
}

#if FNDSA_AVX2
TARGET_AVX2
void
avx2_mp_mkgm(unsigned logn, uint32_t *restrict gm,
	uint32_t g, uint32_t p, uint32_t p0i)
{
	size_t n = (size_t)1 << logn;

	for (unsigned j = logn; j < 10; j ++) {
		g = mp_mmul(g, g, p, p0i);
	}

	if (logn >= 3) {
		uint32_t gx = g;
		for (unsigned j = 3; j < logn; j ++) {
			gx = mp_mmul(gx, gx, p, p0i);
		}
		uint32_t ya0 = mp_R(p);
		uint32_t ya4 = gx;
		uint32_t ya2 = mp_mmul(ya4, gx, p, p0i);;
		uint32_t ya6 = mp_mmul(ya2, gx, p, p0i);;
		uint32_t ya1 = mp_mmul(ya6, gx, p, p0i);;
		uint32_t ya5 = mp_mmul(ya1, gx, p, p0i);;
		uint32_t ya3 = mp_mmul(ya5, gx, p, p0i);;
		uint32_t ya7 = mp_mmul(ya3, gx, p, p0i);;
		__m256i ya = _mm256_setr_epi32(
			ya0, ya1, ya2, ya3, ya4, ya5, ya6, ya7);
		__m256i yg = _mm256_set1_epi32(g);

		unsigned k = 10 - logn;
		__m256i yp = _mm256_set1_epi32(p);
		__m256i yp0i = _mm256_set1_epi32(p0i);
		size_t i = 0;
		for (;;) {
			size_t j = REV10[i << k];
			_mm256_storeu_si256(
				(__m256i *)(gm + j), ya);
			i ++;
			if (i >= (n >> 3)) {
				break;
			}
			ya = mp_mmul_x8(ya, yg, yp, yp0i);
		}
	} else {
		unsigned k = 10 - logn;
		uint32_t x1 = mp_R(p);
		size_t i = 0;
		for (;;) {
			size_t j = REV10[i << k];
			gm[j] = x1;
			i ++;
			if (i >= n) {
				break;
			}
			x1 = mp_mmul(x1, g, p, p0i);
		}
	}
}
#endif

/* see kgen_inner.h */
void
mp_mkigm(unsigned logn, uint32_t *restrict igm,
	uint32_t ig, uint32_t p, uint32_t p0i)
{
	size_t n = (size_t)1 << logn;

	for (unsigned j = logn; j < 10; j ++) {
		ig = mp_mmul(ig, ig, p, p0i);
	}
	unsigned k = 10 - logn;
#if FNDSA_MVE_MP31
	uint32_t x2 = mp_R(p);
#else
	uint32_t x2 = mp_hR(p);
#endif
	size_t i = 0;
	for (;;) {
		size_t j = REV10[i << k];
		igm[j] = x2;
		i ++;
		if (i >= n) {
			break;
		}
		x2 = mp_mmul(x2, ig, p, p0i);
	}
}

#if FNDSA_AVX2
TARGET_AVX2
void
avx2_mp_mkigm(unsigned logn, uint32_t *restrict igm,
	uint32_t ig, uint32_t p, uint32_t p0i)
{
	size_t n = (size_t)1 << logn;

	for (unsigned j = logn; j < 10; j ++) {
		ig = mp_mmul(ig, ig, p, p0i);
	}
	if (logn >= 3) {
		uint32_t igx = ig;
		for (unsigned j = 3; j < logn; j ++) {
			igx = mp_mmul(igx, igx, p, p0i);
		}
		uint32_t yb0 = mp_hR(p);
		uint32_t yb4 = mp_half(igx, p);
		uint32_t yb2 = mp_mmul(yb4, igx, p, p0i);;
		uint32_t yb6 = mp_mmul(yb2, igx, p, p0i);;
		uint32_t yb1 = mp_mmul(yb6, igx, p, p0i);;
		uint32_t yb5 = mp_mmul(yb1, igx, p, p0i);;
		uint32_t yb3 = mp_mmul(yb5, igx, p, p0i);;
		uint32_t yb7 = mp_mmul(yb3, igx, p, p0i);;
		__m256i yb = _mm256_setr_epi32(
			yb0, yb1, yb2, yb3, yb4, yb5, yb6, yb7);
		__m256i yig = _mm256_set1_epi32(ig);

		unsigned k = 10 - logn;
		__m256i yp = _mm256_set1_epi32(p);
		__m256i yp0i = _mm256_set1_epi32(p0i);
		size_t i = 0;
		for (;;) {
			size_t j = REV10[i << k];
			_mm256_storeu_si256(
				(__m256i *)(igm + j), yb);
			i ++;
			if (i >= (n >> 3)) {
				break;
			}
			yb = mp_mmul_x8(yb, yig, yp, yp0i);
		}
	} else {
		unsigned k = 10 - logn;
		uint32_t x2 = mp_hR(p);
		size_t i = 0;
		for (;;) {
			size_t j = REV10[i << k];
			igm[j] = x2;
			i ++;
			if (i >= n) {
				break;
			}
			x2 = mp_mmul(x2, ig, p, p0i);
		}
	}
}
#endif

#if FNDSA_AVX2
TARGET_AVX2
static inline __m256i
mp_NTT8(__m256i ya, const uint32_t *restrict gm, size_t k,
	__m256i yp, __m256i yp0i)
{
	__m256i yt1, yt2, ya0, ya1;

	/* 0/4, 1/5, 2/6, 3/7 with gm[1] */
	/* ya <- a0:a1:a4:a5:a2:a3:a6:a7 */
	ya = _mm256_permute4x64_epi64(ya, 0xD8);
	/* yt1 <- a0:a4:a1:a5:a2:a6:a3:a7 */
	yt1 = _mm256_shuffle_epi32(ya, 0xD8);
	/* yt2 <- a4:a0:a5:a1:a6:a2:a7:a3 */
	yt2 = _mm256_shuffle_epi32(ya, 0x72);
	/* yg0 <- g1:g1:g1:g1:g1:g1:g1:g1 */
	__m256i yg0 = _mm256_set1_epi32(gm[k]);
	yt2 = mp_mmul_x4(yt2, yg0, yp, yp0i);
	ya0 = mp_add_x8(yt1, yt2, yp);
	ya1 = mp_sub_x8(yt1, yt2, yp);

	/* ya0 = a0:--:a1:--:a2:--:a3:--
	   ya1 = a4:--:a5:--:a6:--:a7:-- */

	/* 0/2, 1/3 with gm[2]; 4/6, 5/7 with gm[3] */
	/* yt1 <- a0:--:a1:--:a4:--:a5:--
	   yt2 <- a2:--:a3:--:a6:--:a7:-- */
	yt1 = _mm256_permute2x128_si256(ya0, ya1, 0x20);
	yt2 = _mm256_permute2x128_si256(ya0, ya1, 0x31);
	__m256i yg1 = _mm256_setr_epi32(
		gm[(k << 1) + 0], gm[(k << 1) + 0],
		gm[(k << 1) + 0], gm[(k << 1) + 0],
		gm[(k << 1) + 1], gm[(k << 1) + 1],
		gm[(k << 1) + 1], gm[(k << 1) + 1]);
	yt2 = mp_mmul_x4(yt2, yg1, yp, yp0i);
	ya0 = mp_add_x8(yt1, yt2, yp);
	ya1 = mp_sub_x8(yt1, yt2, yp);

	/* ya0 = a0:--:a1:--:a4:--:a5:--
	   ya1 = a2:--:a3:--:a6:--:a7:-- */

	/* 0/1 with gm[4], 2/3 with gm[5], 4/5 with gm[6], 6/7 with gm[7] */
	/* yt1 <- a0:--:a2:--:a4:--:a6:--
	   yt2 <- a1:--:a3:--:a5:--:a7:-- */
	yt1 = _mm256_unpacklo_epi64(ya0, ya1);
	yt2 = _mm256_unpackhi_epi64(ya0, ya1);
	__m256i yg2 = _mm256_setr_epi32(
		gm[(k << 2) + 0], gm[(k << 2) + 0],
		gm[(k << 2) + 1], gm[(k << 2) + 1],
		gm[(k << 2) + 2], gm[(k << 2) + 2],
		gm[(k << 2) + 3], gm[(k << 2) + 3]);
	yt2 = mp_mmul_x4(yt2, yg2, yp, yp0i);
	ya0 = mp_add_x8(yt1, yt2, yp);
	ya1 = mp_sub_x8(yt1, yt2, yp);

	/* ya0 = a0:--:a2:--:a4:--:a6:--
	   ya1 = a1:--:a3:--:a5:--:a7:-- */
	ya = _mm256_blend_epi32(ya0, _mm256_slli_epi64(ya1, 32), 0xAA);
	return ya;
}

TARGET_AVX2
static inline __m256i
mp_iNTT8(__m256i ya, const uint32_t *restrict igm, size_t k,
	__m256i yp, __m256i yp0i)
{
	__m256i yt1, yt2, ya0, ya1;

	/* yt1 <- a0:--:a2:--:a4:--:a6:--
	   yt2 <- a1:--:a3:--:a5:--:a7:-- */
	yt1 = ya;
	yt2 = _mm256_srli_epi64(ya, 32);
	__m256i yg2 = _mm256_setr_epi32(
		igm[(k << 2) + 0], igm[(k << 2) + 0],
		igm[(k << 2) + 1], igm[(k << 2) + 1],
		igm[(k << 2) + 2], igm[(k << 2) + 2],
		igm[(k << 2) + 3], igm[(k << 2) + 3]);
	ya0 = mp_half_x8(mp_add_x8(yt1, yt2, yp), yp);
	ya1 = mp_mmul_x4(mp_sub_x8(yt1, yt2, yp), yg2, yp, yp0i);

	/* yt1 <- a0:--:a1:--:a4:--:a5:--
	   yt2 <- a2:--:a3:--:a6:--:a7:-- */
	yt1 = _mm256_unpacklo_epi64(ya0, ya1);
	yt2 = _mm256_unpackhi_epi64(ya0, ya1);
	__m256i yg1 = _mm256_setr_epi32(
		igm[(k << 1) + 0], igm[(k << 1) + 0],
		igm[(k << 1) + 0], igm[(k << 1) + 0],
		igm[(k << 1) + 1], igm[(k << 1) + 1],
		igm[(k << 1) + 1], igm[(k << 1) + 1]);
	ya0 = mp_half_x8(mp_add_x8(yt1, yt2, yp), yp);
	ya1 = mp_mmul_x4(mp_sub_x8(yt1, yt2, yp), yg1, yp, yp0i);

	/* yt1 <- a0:--:a1:--:a2:--:a3:--
	   yt2 <- a4:--:a5:--:a6:--:a7:-- */
	yt1 = _mm256_permute2x128_si256(ya0, ya1, 0x20);
	yt2 = _mm256_permute2x128_si256(ya0, ya1, 0x31);
	__m256i yg0 = _mm256_set1_epi32(igm[k]);
	ya0 = mp_half_x8(mp_add_x8(yt1, yt2, yp), yp);
	ya1 = mp_mmul_x4(mp_sub_x8(yt1, yt2, yp), yg0, yp, yp0i);

	/* yt1 <- a0:--:a1:--:a4:--:a5:--
	   yt2 <- a2:--:a3:--:a6:--:a7:-- */
	yt1 = _mm256_permute2x128_si256(ya0, ya1, 0x20);
	yt2 = _mm256_permute2x128_si256(ya0, ya1, 0x31);
	/* yt1 <- a0:a2:a1:a3:a4:a6:a5:a7 */
	yt1 = _mm256_blend_epi32(yt1, _mm256_slli_epi64(yt2, 32), 0xAA);
	ya = _mm256_shuffle_epi32(yt1, 0xD8);
	return ya;
}
#endif

/*
 * The Cortex-M55 build keeps this exact C implementation as the small-logn
 * fallback and as a coefficient-exact oracle for the assembly validation.
 * Other builds retain the original public symbol.
 */
#if FNDSA_MVE_MP31
void
fndsa_mp_NTT_c(unsigned logn, uint32_t *restrict a,
	const uint32_t *restrict gm, uint32_t p, uint32_t p0i)
#else
/* see kgen_inner.h */
void
mp_NTT(unsigned logn, uint32_t *restrict a, const uint32_t *restrict gm,
	uint32_t p, uint32_t p0i)
#endif
{
	/*
	 * On small, non-superscalar platforms where memory accesses do
	 * not occur in parallel with computations, it is beneficial to
	 * perform two NTT layers at the same time, to reduce the number
	 * of memory accesses.
	 */

	if (logn == 0) {
		return;
	}
	if (logn == 1) {
		uint32_t s = gm[1];
		uint32_t x0 = a[0];
		uint32_t x1 = mp_mmul(a[1], s, p, p0i);
		a[0] = mp_add(x0, x1, p);
		a[1] = mp_sub(x0, x1, p);
		return;
	}
	size_t t;
	unsigned lm;

	if ((logn & 1) != 0) {
		t = (size_t)1 << (logn - 1);
		uint32_t s = gm[1];
		for (size_t i = 0; i < t; i ++) {
			uint32_t x0 = a[i];
			uint32_t x1 = mp_mmul(a[i + t], s, p, p0i);
			a[i] = mp_add(x0, x1, p);
			a[i + t] = mp_sub(x0, x1, p);
		}
		lm = 1;
	} else {
		t = (size_t)1 << logn;
		lm = 0;
	}

	for (; (lm + 3) < logn; lm += 2) {
		size_t m = (size_t)1 << lm;
		size_t ht = t >> 1;
		size_t qt = ht >> 1;
		size_t j0 = 0;
		for (size_t i = 0; i < m; i ++) {
			uint32_t s = gm[i + m];
			uint32_t s0 = gm[((i + m) << 1) + 0];
			uint32_t s1 = gm[((i + m) << 1) + 1];
			for (size_t j = 0; j < qt; j ++) {
				size_t k0 = j0 + j;
				size_t k1 = k0 + qt;
				size_t k2 = k0 + ht;
				size_t k3 = k0 + ht + qt;
				uint32_t x0 = a[k0];
				uint32_t x1 = a[k1];
				uint32_t x2 = a[k2];
				uint32_t x3 = a[k3];
				uint32_t tt;

				tt = mp_mmul(x2, s, p, p0i);
				x2 = mp_sub(x0, tt, p);
				x0 = mp_add(x0, tt, p);

				tt = mp_mmul(x3, s, p, p0i);
				x3 = mp_sub(x1, tt, p);
				x1 = mp_add(x1, tt, p);

				tt = mp_mmul(x1, s0, p, p0i);
				x1 = mp_sub(x0, tt, p);
				x0 = mp_add(x0, tt, p);

				tt = mp_mmul(x3, s1, p, p0i);
				x3 = mp_sub(x2, tt, p);
				x2 = mp_add(x2, tt, p);

				a[k0] = x0;
				a[k1] = x1;
				a[k2] = x2;
				a[k3] = x3;
			}
			j0 += t;
		}
		t = qt;
	}

	size_t m = (size_t)1 << (logn - 2);
	for (size_t i = 0; i < m; i ++) {
		uint32_t s = gm[i + m];
		uint32_t s0 = gm[((i + m) << 1) + 0];
		uint32_t s1 = gm[((i + m) << 1) + 1];
		uint32_t x0 = a[(i << 2) + 0];
		uint32_t x1 = a[(i << 2) + 1];
		uint32_t x2 = a[(i << 2) + 2];
		uint32_t x3 = a[(i << 2) + 3];
		uint32_t tt;

		tt = mp_mmul(x2, s, p, p0i);
		x2 = mp_sub(x0, tt, p);
		x0 = mp_add(x0, tt, p);

		tt = mp_mmul(x3, s, p, p0i);
		x3 = mp_sub(x1, tt, p);
		x1 = mp_add(x1, tt, p);

		tt = mp_mmul(x1, s0, p, p0i);
		x1 = mp_sub(x0, tt, p);
		x0 = mp_add(x0, tt, p);

		tt = mp_mmul(x3, s1, p, p0i);
		x3 = mp_sub(x2, tt, p);
		x2 = mp_add(x2, tt, p);

		a[(i << 2) + 0] = x0;
		a[(i << 2) + 1] = x1;
		a[(i << 2) + 2] = x2;
		a[(i << 2) + 3] = x3;
	}
}

#if FNDSA_AVX2
TARGET_AVX2
void
avx2_mp_NTT(unsigned logn, uint32_t *restrict a, const uint32_t *restrict gm,
	uint32_t p, uint32_t p0i)
{
	if (logn == 0) {
		return;
	}
	switch (logn) {
		uint32_t x1, x2, s;
		size_t t, n;
		__m256i yp, yp0i;

	case 1:
		x1 = a[0];
		x2 = mp_mmul(a[1], gm[1], p, p0i);
		a[0] = mp_add(x1, x2, p);
		a[1] = mp_sub(x1, x2, p);
		return;
	case 2:
		s = gm[1];
		x1 = a[0];
		x2 = mp_mmul(a[2], s, p, p0i);
		a[0] = mp_add(x1, x2, p);
		a[2] = mp_sub(x1, x2, p);
		x1 = a[1];
		x2 = mp_mmul(a[3], s, p, p0i);
		a[1] = mp_add(x1, x2, p);
		a[3] = mp_sub(x1, x2, p);
		x1 = a[0];
		x2 = mp_mmul(a[1], gm[2], p, p0i);
		a[0] = mp_add(x1, x2, p);
		a[1] = mp_sub(x1, x2, p);
		x1 = a[2];
		x2 = mp_mmul(a[3], gm[3], p, p0i);
		a[2] = mp_add(x1, x2, p);
		a[3] = mp_sub(x1, x2, p);
		return;
	default:
		yp = _mm256_set1_epi32(p);
		yp0i = _mm256_set1_epi32(p0i);
		n = (size_t)1 << logn;
		t = n;
		for (unsigned lm = 0; lm < (logn - 3); lm ++) {
			size_t m = (size_t)1 << lm;
			size_t ht = t >> 1;
			size_t j0 = 0;
			for (size_t i = 0; i < m; i ++) {
				__m256i ys = _mm256_set1_epi32(gm[i + m]);
				for (size_t j = 0; j < ht; j += 8) {
					size_t k1 = j0 + j;
					size_t k2 = k1 + ht;
					__m256i *a1 = (__m256i *)(a + k1);
					__m256i *a2 = (__m256i *)(a + k2);
					__m256i y1 = _mm256_loadu_si256(a1);
					__m256i y2 = _mm256_loadu_si256(a2);
					y2 = mp_mmul_x8(y2, ys, yp, yp0i);
					_mm256_storeu_si256(a1,
						mp_add_x8(y1, y2, yp));
					_mm256_storeu_si256(a2,
						mp_sub_x8(y1, y2, yp));
				}
				j0 += t;
			}
			t = ht;
		}
		size_t m = n >> 3;
		for (size_t i = 0; i < m; i ++) {
			uint32_t *za = a + (i << 3);
			__m256i ya = _mm256_loadu_si256((__m256i *)za);
			ya = mp_NTT8(ya, gm, i + m, yp, yp0i);
			_mm256_storeu_si256((__m256i *)za, ya);
		}
		return;
	}
}
#endif

/* See the comment above fndsa_mp_NTT_c(). */
#if FNDSA_MVE_MP31
void
fndsa_mp_iNTT_c(unsigned logn, uint32_t *restrict a,
	const uint32_t *restrict igm, uint32_t p, uint32_t p0i)
#else
/* see kgen_inner.h */
void
mp_iNTT(unsigned logn, uint32_t *restrict a, const uint32_t *restrict igm,
	uint32_t p, uint32_t p0i)
#endif
{
	if (logn == 0) {
		return;
	}
#if FNDSA_MVE_MP31
	/*
	 * Coefficient-exact C oracle and small-logn fallback for the full-root
	 * MVE contract.  Unlike the upstream half-root implementation below,
	 * the layers are unscaled; the common 1/n factor is applied once after
	 * the last layer.  Loop bounds and all addresses depend only on the
	 * public logn.
	 */
	{
		size_t n = (size_t)1 << logn;
		size_t t = 1;
		for (unsigned lm = 0; lm < logn; lm ++) {
			size_t hm = (size_t)1 << (logn - 1 - lm);
			size_t dt = t << 1;
			size_t j0 = 0;
			for (size_t i = 0; i < hm; i ++) {
				uint32_t s = igm[i + hm];
				for (size_t j = 0; j < t; j ++) {
					size_t k0 = j0 + j;
					size_t k1 = k0 + t;
					uint32_t x0 = a[k0];
					uint32_t x1 = a[k1];
					a[k0] = mp_add(x0, x1, p);
					a[k1] = mp_mmul(
						mp_sub(x0, x1, p), s, p, p0i);
				}
				j0 += dt;
			}
			t = dt;
		}
		uint32_t ni = (uint32_t)1 << (32 - logn);
		for (size_t i = 0; i < n; i ++) {
			a[i] = mp_mmul(a[i], ni, p, p0i);
		}
		return;
	}
#endif
	if (logn == 1) {
		uint32_t s = igm[1];
		uint32_t x0 = a[0];
		uint32_t x1 = a[1];
		a[0] = mp_half(mp_add(x0, x1, p), p);
		a[1] = mp_mmul(mp_sub(x0, x1, p), s, p, p0i);
		return;
	}

	size_t qn = (size_t)1 << (logn - 2);
	for (size_t i = 0; i < qn; i ++) {
		uint32_t s0 = igm[((i + qn) << 1) + 0];
		uint32_t s1 = igm[((i + qn) << 1) + 1];
		uint32_t s = igm[i + qn];

		uint32_t x0 = a[(i << 2) + 0];
		uint32_t x1 = a[(i << 2) + 1];
		uint32_t x2 = a[(i << 2) + 2];
		uint32_t x3 = a[(i << 2) + 3];
		uint32_t tt;

		tt = mp_sub(x0, x1, p);
		x0 = mp_half(mp_add(x0, x1, p), p);
		x1 = mp_mmul(tt, s0, p, p0i);

		tt = mp_sub(x2, x3, p);
		x2 = mp_half(mp_add(x2, x3, p), p);
		x3 = mp_mmul(tt, s1, p, p0i);

		tt = mp_sub(x0, x2, p);
		x0 = mp_half(mp_add(x0, x2, p), p);
		x2 = mp_mmul(tt, s, p, p0i);

		tt = mp_sub(x1, x3, p);
		x1 = mp_half(mp_add(x1, x3, p), p);
		x3 = mp_mmul(tt, s, p, p0i);

		a[(i << 2) + 0] = x0;
		a[(i << 2) + 1] = x1;
		a[(i << 2) + 2] = x2;
		a[(i << 2) + 3] = x3;
	}

	size_t t = 4;
	for (unsigned lm = 2; (lm + 1) < logn; lm += 2) {
		size_t hm = (size_t)1 << (logn - 1 - lm);
		size_t qm = hm >> 1;
		size_t dt = t << 1;
		size_t ft = t << 2;
		size_t j0 = 0;
		for (size_t i = 0; i < qm; i ++) {
			uint32_t s0 = igm[((i + qm) << 1) + 0];
			uint32_t s1 = igm[((i + qm) << 1) + 1];
			uint32_t s = igm[i + qm];
			for (size_t j = 0; j < t; j ++) {
				size_t k0 = j0 + j;
				size_t k1 = k0 + t;
				size_t k2 = k0 + dt;
				size_t k3 = k0 + t + dt;
				uint32_t x0 = a[k0];
				uint32_t x1 = a[k1];
				uint32_t x2 = a[k2];
				uint32_t x3 = a[k3];
				uint32_t tt;

				tt = mp_sub(x0, x1, p);
				x0 = mp_half(mp_add(x0, x1, p), p);
				x1 = mp_mmul(tt, s0, p, p0i);

				tt = mp_sub(x2, x3, p);
				x2 = mp_half(mp_add(x2, x3, p), p);
				x3 = mp_mmul(tt, s1, p, p0i);

				tt = mp_sub(x0, x2, p);
				x0 = mp_half(mp_add(x0, x2, p), p);
				x2 = mp_mmul(tt, s, p, p0i);

				tt = mp_sub(x1, x3, p);
				x1 = mp_half(mp_add(x1, x3, p), p);
				x3 = mp_mmul(tt, s, p, p0i);

				a[k0] = x0;
				a[k1] = x1;
				a[k2] = x2;
				a[k3] = x3;
			}
			j0 += ft;
		}
		t = ft;
	}

	if ((logn & 1) != 0) {
		size_t hn = (size_t)1 << (logn - 1);
		uint32_t s = igm[1];
		for (size_t i = 0; i < hn; i ++) {
			uint32_t x0 = a[i];
			uint32_t x1 = a[i + hn];
			a[i] = mp_half(mp_add(x0, x1, p), p);
			a[i + hn] = mp_mmul(mp_sub(x0, x1, p), s, p, p0i);
		}
	}
}

#if FNDSA_AVX2
TARGET_AVX2
void
avx2_mp_iNTT(unsigned logn, uint32_t *restrict a, const uint32_t *restrict igm,
	uint32_t p, uint32_t p0i)
{
	if (logn == 0) {
		return;
	}
	switch (logn) {
		uint32_t x1, x2, s;
		size_t t, n;
		__m256i yp, yp0i;

	case 1:
		x1 = a[0];
		x2 = a[1];
		a[0] = mp_half(mp_add(x1, x2, p), p);
		a[1] = mp_mmul(mp_sub(x1, x2, p), igm[1], p, p0i);
		return;
	case 2:
		x1 = a[0];
		x2 = a[1];
		a[0] = mp_half(mp_add(x1, x2, p), p);
		a[1] = mp_mmul(mp_sub(x1, x2, p), igm[2], p, p0i);
		x1 = a[2];
		x2 = a[3];
		a[2] = mp_half(mp_add(x1, x2, p), p);
		a[3] = mp_mmul(mp_sub(x1, x2, p), igm[3], p, p0i);
		s = igm[1];
		x1 = a[0];
		x2 = a[2];
		a[0] = mp_half(mp_add(x1, x2, p), p);
		a[2] = mp_mmul(mp_sub(x1, x2, p), s, p, p0i);
		x1 = a[1];
		x2 = a[3];
		a[1] = mp_half(mp_add(x1, x2, p), p);
		a[3] = mp_mmul(mp_sub(x1, x2, p), s, p, p0i);
		return;
	default:
		yp = _mm256_set1_epi32(p);
		yp0i = _mm256_set1_epi32(p0i);
		n = (size_t)1 << logn;
		size_t m = n >> 3;
		for (size_t i = 0; i < m; i ++) {
			uint32_t *za = a + (i << 3);
			__m256i ya = _mm256_loadu_si256((__m256i *)za);
			ya = mp_iNTT8(ya, igm, i + m, yp, yp0i);
			_mm256_storeu_si256((__m256i *)za, ya);
		}
		t = 8;
		for (unsigned lm = 3; lm < logn; lm ++) {
			size_t hm = (size_t)1 << (logn - 1 - lm);
			size_t dt = t << 1;
			size_t j0 = 0;
			for (size_t i = 0; i < hm; i ++) {
				__m256i ys = _mm256_set1_epi32(igm[i + hm]);
				for (size_t j = 0; j < t; j += 8) {
					size_t k1 = j0 + j;
					size_t k2 = k1 + t;
					__m256i *a1 = (__m256i *)(a + k1);
					__m256i *a2 = (__m256i *)(a + k2);
					__m256i y1 = _mm256_loadu_si256(a1);
					__m256i y2 = _mm256_loadu_si256(a2);
					_mm256_storeu_si256(a1, mp_half_x8(
						mp_add_x8(y1, y2, yp), yp));
					_mm256_storeu_si256(a2, mp_mmul_x8(
						mp_sub_x8(y1, y2, yp),
						ys, yp, yp0i));
				}
				j0 += dt;
			}
			t = dt;
		}
		return;
	}
}
#endif

/* see kgen_inner.h */
ALIGN32
const small_prime PRIMES[] = {
    { 2147473409, 2042615807,  419348484, 1790111537,  786166065,      20478 },
    { 2147389441, 1862176767, 1141604340,  677655126, 2024968256,  942807490 },
    { 2147387393, 1472104447,  554514419,  563781659, 1438853699,  511282737 },
    { 2147377153, 3690881023,  269819887,  978644358, 1971237828, 1936446844 },
    { 2147358721, 3720222719,  153618407, 1882929796,  289507384,  264920030 },
    { 2147352577, 2147352575,    3145700,  875644459, 1993867586, 1197387618 },
    { 2147346433,  498984959,  154699745, 1268990641, 1559885885, 2112514368 },
    { 2147338241, 2478688255,  826591197,  304701980,  207126964,  842573420 },
    { 2147309569, 1908234239,  964657100, 1953449942,  309167499,   75092579 },
    { 2147297281, 1774004223, 1503608772,  353848817, 1726802198, 2084007226 },
    { 2147295233, 1006444543,  279363522,  632955619,  419515149,   38880066 },
    { 2147239937, 2881243135, 1383813014,  710717957,  756383674,  706593520 },
    { 2147235841,  867973119,  848351122, 1627458017, 1867341538, 1260600213 },
    { 2147217409, 4277923839,  100122496, 1700895952, 1076153660,  370621817 },
    { 2147205121, 1878769663, 1111621492,   44667394, 1556218865,   32248737 },
    { 2147196929, 1543217151,  310009707, 1302747296, 1775932980, 1745280407 },
    { 2147178497, 3518715903, 1006651223,  995615578, 1904695444,  546877831 },
    { 2147100673, 1505372159,  520918771,   32821017,  801131396, 1402329446 },
    { 2147082241, 4227457023,  385646296,  671813454,  349022278, 1235641740 },
    { 2147074049, 1878638591, 1198259916,   22548867,  381743482,  316764378 },
    { 2147051521,   96036863, 1908098729, 1744576193,  129309952, 1045517086 },
    { 2147043329, 1538869247,  440645275,  848789527,  259769898,   74455690 },
    { 2147039233, 2209953791, 2055370389, 1117428534, 1471147502,  119673623 },
    { 2146988033, 1324904447, 1363381819, 2041738204,  478044407,  147722658 },
    { 2146963457, 2130186239,  325123596, 2068278376,  875801492, 1306038870 },
    { 2146959361, 2146959359,  264240644,  872271011,  507971579, 1990286186 },
    { 2146938881, 1727508479, 1974074844,  198886428,  561977686, 1269843026 },
    { 2146908161, 1672951807,   98813339, 1770745661, 1393783074, 1823212183 },
    { 2146885633, 1006034943,  661929322, 1068953529,  641063610,  596476372 },
    { 2146871297,  834054143, 1378823498, 1788896577,  959521530,  583621658 },
    { 2146846721,  196495359, 1834738961,  827307343, 2002269931, 1831804644 },
    { 2146834433, 1572214783,  655434995, 1825957452, 2005158872,   95719048 },
    { 2146818049, 1505089535,  963224779, 1698458806, 1152339536, 1292562110 },
    { 2146775041, 2532651007, 1260858461, 1897922218, 1980311657, 1048890741 },
    { 2146756609, 1840572415, 1934326828, 1319016594,  303348307,  309425167 },
    { 2146744321, 1001699327, 1031932938,  166920536,  125412453,  206010953 },
    { 2146738177,  469016575, 1034034169, 2049530115,  240883589, 2109942428 },
    { 2146736129, 1706334207,  386311155, 1983901927,  399193796, 1866844306 },
    { 2146713601, 1878278143, 1917713332,  795783646, 2145730902,  666529419 },
    { 2146695169, 3216242687,  923528062,  410549424,  826761640,  881662233 },
    { 2146656257,  468934655, 1316739849,  819155176, 1775281069,  769010182 },
    { 2146650113, 3149088767, 1357138678, 1776223808, 1272363648, 1075150578 },
    { 2146646017,  598947839,  836424425,  861255062,  862632924, 1452282057 },
    { 2146643969, 1458778111, 1699760867, 1128852454, 1250440960,  551264863 },
    { 2146603009, 4008873983,  258845279, 1693343820, 1370713748,  896492399 },
    { 2146572289,  498210815, 1553576441, 1357574155, 2042997788,  475091953 },
    { 2146547713, 2343679999,  731429284,  874518801,  933977652, 2038082698 },
    { 2146508801, 1005658111, 1986115866,  994764483, 1486111048,   77164992 },
    { 2146492417, 3153125375, 2074458334, 1607832505, 1814950582, 1064849124 },
    { 2146490369, 3383810047, 1163389142, 1860189331,  766301042, 1792895956 },
    { 2146459649, 1542479871,  113653858, 1774578485,  436467466,  509354151 },
    { 2146447361, 1995452415,  521816115,  984131366,  920695297, 1917290506 },
    { 2146441217, 2108692479,  106094619, 1700403904,   55841604,  574542256 },
    { 2146437121, 2142242815, 2143320076, 1575554072, 1350403963, 1873207947 },
    { 2146430977, 2129653759,   84969459,  244551713,  118889817,  571880191 },
    { 2146418689, 1877983231, 1167996867, 1775456464, 1211626453, 1434078655 },
    { 2146406401, 1324322815, 1313757074, 1622299552,   60879896, 1023260741 },
    { 2146404353, 1202685951, 1813342090, 1162222118,  193969494, 1214240996 },
    { 2146379777, 3383699455, 1842644774,  237716594, 1996303667, 1647718365 },
    { 2146363393, 1303308287, 1687447266, 1850889128,  545315431, 1827479741 },
    { 2146355201,   61786111,  269635263,  691559024,  756508884, 1699936240 },
    { 2146336769, 1072594943,  654341745, 1871443110,  107703592, 1164751303 },
    { 2146312193, 4226686975, 1106990599,  230828908, 2118815775,  547343662 },
    { 2146293761, 3652048895, 1401349558, 1527866384, 1939695340,  934813966 },
    { 2146283521,  653111295,  594294152, 1585987504,  113384110,  901617467 },
    { 2146203649,  128743423, 1230019607, 2070978911, 1602264262,  195465499 },
    { 2146154497,  732674047, 1428919080,   29335864, 1593288655, 2129713526 },
    { 2146142209, 2276165631, 1819536107,  649122195,  996268341,  667538093 },
    { 2146127873, 2263568383, 2015437475,  207440004, 1904659130, 2030659201 },
    { 2146099201, 1005248511,  907637264,  559331750,  152292400, 1381346740 },
    { 2146093057, 1135265791,  453939696, 1717051717,  781899671,  630273220 },
    { 2146091009, 4025139199, 1800630758, 1086157903, 1771609892, 1947078850 },
    { 2146078721, 4008349695, 2001965478, 1399918158,  329087331, 2118472151 },
    { 2146060289, 3416934399,  279720260, 1683079797, 1885781100,  720846962 },
    { 2146048001, 2645170175, 1358862595,  455982466, 1271329796, 1757914587 },
    { 2146041857, 2146041855, 1278996706,   70834413, 1910051359, 2005325121 },
    { 2146019329, 1101637631, 1427296360,  223814614,  804128830, 1360420507 },
    { 2145986561, 2846435327, 1292076979, 1571468773, 1576376806, 1922069675 },
    { 2145976321, 2145976319, 2074996602,  755073721,  414238476,  200778967 },
    { 2145964033, 3605581823,  689794868, 1452485437,  856502235,  416725139 },
    { 2145906689, 2129129471,  921247209,  676947204,  654865993, 1812356432 },
    { 2145875969, 3081205759, 1842525491, 1326145670,  309498173, 2087042424 },
    { 2145871873, 2779211775,  962993434, 1019421319, 1501089909,  653721111 },
    { 2145841153, 1592193023, 1869982816,  214096862, 1556972726,  503214451 },
    { 2145832961,  384225279,  384678957,  669316727,  783241415, 1108169518 },
    { 2145816577, 1860603903, 1173007304, 1845637035,  826920248,  854681726 },
    { 2145785857, 1571166207,  669709063, 1939498551, 1558887263,  633181476 },
    { 2145755137, 3689259007, 1290750531,  954377268,   91681545, 1222833471 },
    { 2145742849, 4008013823,  223279603,  943919281,  916877791, 1449746232 },
    { 2145728513, 1134901247, 1222351254, 2118240515, 1429489422,  863342952 },
    { 2145699841, 2745485311, 1723896025, 1632678465, 1030096814, 1093745233 },
    { 2145691649, 3517229055,  931453090,   54415538,  530452177, 1965948870 },
    { 2145687553, 1705285631, 1809739911, 1581677400, 1990115608,  440621047 },
    { 2145673217, 1541693439,  578267174, 1396659387, 1723941977, 1763556058 },
    { 2145630209, 2879633407,  328648448,   40361658, 1539467270, 1674729976 },
    { 2145595393, 1457729535,  255202829, 1400378563, 1431207189, 1703296854 },
    { 2145587201,  518197247, 2028299732, 1486218552,  644522534, 1270684848 },
    { 2145525761, 4225900543, 1358930970, 1145038363,  878769963, 1208930401 },
    { 2145495041, 3248596991, 1641759544,  431141042, 1250759371,  401371792 },
    { 2145466369,   60897279,    4913761, 1346487656, 1003126503, 1472826275 },
    { 2145445889, 2913003519, 1950341575,  209604178, 2010474299,  190633762 },
    { 2145390593, 2128613375, 2111959069, 1977319511,  253671817,  711951677 },
    { 2145372161, 1939851263, 1176002444,  230466302, 1564380182,  318701388 },
    { 2145361921, 1541382143,  879247163, 1458754908,  789794840, 1032907577 },
    { 2145359873, 1436522495, 1349830443,  160850239,  842688712,  977726147 },
    { 2145355777, 1201637375,  246501130, 1714048525, 1460503641,  167731422 },
    { 2145343489,  295655423, 2034128553,   85533909,   89392725, 1282860004 },
    { 2145325057, 2665418751, 1621650965, 1422485923,  288923379,  911614733 },
    { 2145318913, 1872689151,  659138019,  507124624, 1410089651,  131619480 },
    { 2145312769, 1004462079, 2144542130,  601028071,  309708965, 1694238751 },
    { 2145300481, 3336482815, 1732525390, 1940872306, 2008521418,  313780675 },
    { 2145282049, 4120799231, 1238750391, 1797682851,  557030104, 1782843353 },
    { 2145232897,   27109375, 1795543839, 1037744642, 1557646622,  900304126 },
    { 2145218561, 4007489535, 1315715750, 1070968735,  736559602, 1443800839 },
    { 2145187841, 1335687167,   13023648, 1309044639, 1866831222,  399747323 },
    { 2145181697, 3151814655, 1518459244, 1993483355,  691838010,  615546001 },
    { 2145175553,  597477375, 1181348151,  703506449, 1514472518,  488565539 },
    { 2145079297, 2262519807, 1805182441, 1948507193,  198785189,  638515383 },
    { 2145021953, 2396680191, 1021023200,  896525833,  286005075, 1441021596 },
    { 2145015809, 2174375935, 2117792680, 1601002661,  347118679, 1157904101 },
    { 2145003521, 1503275007,  929358646, 1668692954,   37145528,  641759047 },
    { 2144960513, 1071218687, 2014663077,  813829821,  819596313,   63874550 },
    { 2144944129, 4023992319, 1528910090, 1405891381, 2038603849, 1893894911 },
    { 2144935937, 1004085247, 1020776636, 1264145057,  131908564, 1538042171 },
    { 2144894977, 1071153151,  117657395, 1658068046, 1863791040,  315971662 },
    { 2144888833, 3583535103, 1035349752,  631245709,  221833619, 2112295623 },
    { 2144880641, 3952625663, 2014869161, 1728523150, 1503761981, 2007376047 },
    { 2144864257, 4288153599, 1298675209,  544582669, 1272986021, 1915075671 },
    { 2144827393, 3080157183, 1123663006,  160045786,  473495242,  813254440 },
    { 2144806913, 1234642943,  731069394, 2014053847, 1766552348,  857353667 },
    { 2144796673, 2144796671, 1796197228,   54648661,  347997993, 2024676365 },
    { 2144778241, 1536604159,  685152946, 1271425633,  321887990, 1348054165 },
    { 2144759809,  248934399,  154114551, 1526637592, 1903326258, 1432928978 },
    { 2144757761, 1972791295, 1931452899,  132970580, 1653105390, 1502698593 },
    { 2144729089, 3751147519,  319799485,  856415206, 2139235838, 1528560673 },
    { 2144727041, 1054207999,  456984744,  648538322, 1211291222, 1040592824 },
    { 2144696321, 2543155199,  117528426,  396088388, 1351318511, 1705928562 },
    { 2144667649,  798296063, 1911610943,  338234827, 1761076141, 1009985854 },
    { 2144573441, 2509477887, 1537057360,  570563298,  647497611, 1089716523 },
    { 2144555009, 2261995519, 1259090311, 1645617705,   28737134,  311642518 },
    { 2144550913, 4023599103,  852574554,  787018986, 2112202798, 1495324375 },
    { 2144536577, 1335035903, 1561905341, 2144070617, 1829236274, 1925884510 },
    { 2144524289, 1771231231,  418502709, 1096979205, 1715236225,    4942642 },
    { 2144512001, 1905436671,  486401965,  371227774,  621999585,  248381878 },
    { 2144468993, 2144468991, 1685175757, 1750820831, 1117048683,  375676619 },
    { 2144458753,  428988415,  481506649,  208627545, 1669824636,  994022373 },
    { 2144421889, 3683731455,  111545270,  490157982,  598291463, 1506819637 },
    { 2144409601, 1301354495, 1696205610, 1773221211, 1190821653,  703296234 },
    { 2144370689, 1070628863,  410368360, 1852155417, 1241424587, 1916372058 },
    { 2144348161, 2039490559, 2058332258,  380925864, 1763931741, 1080707148 },
    { 2144335873, 2140141567,  189861841, 1779816687, 1155526432, 1839197694 },
    { 2144329729, 2077220863,  782112649,  526684710, 1471877186,  752775607 },
    { 2144327681, 2039470079, 1046835057, 1247119374, 1480573420, 1180445680 },
    { 2144309249, 1322225663,  655091351, 1601388861,  546007835,  774279999 },
    { 2144296961,  466575359,  478811653, 1358954307,  277575578, 1153736907 },
    { 2144290817, 4220471295,  845002172, 1883197481,   20750133,  894854412 },
    { 2144243713, 1859031039,  134828934,   37546773, 2020974628, 1786100430 },
    { 2144237569,  663648255,  981840700,  819447626,  828884995, 1801721724 },
    { 2144161793, 1187860479, 1312055195,  492584100,  284208050,  991575551 },
    { 2144155649, 3280812031, 1909512015, 1038118142,  557855457,  351830619 },
    { 2144137217,  516747263, 1231150697, 1145329724, 1222551687, 1031682140 },
    { 2144120833, 2261561343, 1725803932,   85962159, 1987475484, 1541754604 },
    { 2144071681, 4274778111, 1126468398,  956241311, 2057260329, 1928592240 },
    { 2144065537,  965466111, 1878788832, 1053853819,  587985232,  409128944 },
    { 2144028673,  998983679, 2034483463,   85221004,  692082439, 2038010847 },
    { 2144010241, 2144010239,  842246168,  579253174, 1365083779,  893394979 },
    { 2143952897, 4224327679,  754017578,  344456872,  574149142,  951344542 },
    { 2143940609, 3200905215, 1412359304,  691093159, 1240091757,  209561083 },
    { 2143918081, 1971951615, 1479162717, 1879554798, 1607927459, 1573571606 },
    { 2143899649, 3335081983, 1640239719, 1873544500,  512920036,  980684517 },
    { 2143891457,  382283775, 1157894649, 1152913815, 2082762113,  174332902 },
    { 2143885313, 3448313855,   77697446, 1272010615,  639087423,  788921708 },
    { 2143854593,  466132991, 1365712904,  234096830, 1624926716,  267754392 },
    { 2143836161, 3783809023,  200636173,  802456521,  972626486, 1579347589 },
    { 2143762433, 1669806079, 1374323479,  122119316,  523389252,  528105857 },
    { 2143756289, 3150389247,  226179777, 2014672070,  977903451,  205998472 },
    { 2143713281, 2810607615,  674480231,  499335673, 1923111979,  170087335 },
    { 2143690753, 4224065535, 1119041321,  293184621,  548955895, 1709245285 },
    { 2143670273, 3066417151,  966374918, 1855603277, 1939385627, 1369708529 },
    { 2143666177, 1875230719, 1768658380, 1592043954,  626312185, 1973259130 },
    { 2143645697, 4005916671, 1369531559, 1496045094,  868812782,  743685730 },
    { 2143641601, 2613403647,  836342892,  137205166, 1106494107, 1904307099 },
    { 2143635457, 2609203199, 1360942100,  611274460, 1430230424,  634419595 },
    { 2143621121, 3737456639,  190915397,  456284400, 1315071924, 1321642891 },
    { 2143598593,  998553599,  155040255, 1748188596, 1338143543, 1507236419 },
    { 2143567873, 1875132415, 1411420224,  961363405,  100809682,    4006593 },
    { 2143561729,  964962303, 1285824486, 1745824462,   52145752, 1898334618 },
    { 2143553537, 1065617407, 1589845870,  642609604,  876094006, 1160521531 },
    { 2143541249, 3112425471,  912656057,  832462820, 1196335625,   50513987 },
    { 2143531009, 3871584255,  917220898,  733999433, 1060086084,  957280110 },
    { 2143522817, 3468922879, 1098374569, 2134640637, 1812047677,  957540519 },
    { 2143506433, 2260946943,  933735606,  453429574, 1461625836, 1505133897 },
    { 2143488001, 1333987327, 1985268644, 2074073649, 1479394204, 1064535019 },
    { 2143469569, 4022517759, 1477872272, 1513292205, 1862896587, 1004190392 },
    { 2143426561,  495065087,  186028039, 1375811092,  173677829, 2089274222 },
    { 2143383553, 1858170879,  887211384, 2134877926, 1608809321, 1661543915 },
    { 2143377409, 2978043903, 1281348890, 1288031453,  483115862, 1970346133 },
    { 2143363073, 1002512383, 1950991422, 1122143235, 1166724603, 1788468869 },
    { 2143260673, 1321177087, 2069683714, 1805244102, 1261092720,  903254409 },
    { 2143246337,  293558271, 1176536351, 1950051640,  309589975, 1529083832 },
    { 2143209473,   58640383, 1560740565,  218139536, 1255708568, 1698136215 },
    { 2143203329, 3334385663, 1971538547, 1999593400, 1859827267, 1956345089 },
    { 2143160321, 2675836927,  477597631,  884313283, 2113130436, 1457071330 },
    { 2143129601, 2394787839,  546440653, 1295503643, 2080414454, 1206105984 },
    { 2143123457,  394098687,  612601193, 1693130333,   43008062,   16697358 },
    { 2143100929, 1002250239,  591926265, 1101885974,  315537419, 1388418046 },
    { 2143092737, 2143092735, 1205498739, 1071117401,  276869279, 1816776329 },
    { 2143082497, 2306660351, 1658985163, 2126748415, 1783080325, 1909268843 },
    { 2143062017, 2004649983,  806738297, 1026831688, 2035800522,  754902198 },
    { 2143051777, 1539071999, 1644097744, 1553535853, 2052185358, 1958510946 },
    { 2143025153, 1065089023,   48408341, 1525464941, 1852830390,  755368639 },
    { 2143006721, 3871059967, 1620020706, 2138083553,   30951415, 1336294009 },
    { 2142996481, 2273019903,  576994614,    1383533, 1219848252, 1992320100 },
    { 2142976001, 2742761471, 1018092510, 1458681506,  608641646,  190719147 },
    { 2142965761,  515575807,  359250737, 1354388786, 2131235811, 1323949132 },
    { 2142916609,  649744383, 1208571887, 1878268755, 1560639011, 1431405645 },
    { 2142892033, 3199856639,  340166218,  771047236, 1294387139, 1350670764 },
    { 2142885889, 2574899199, 1416994273,  869163275, 1050539694,  503308105 },
    { 2142871553, 3686375423,  823272682, 1330177723, 1618603945,  680882765 },
    { 2142861313, 3615062015,  185662521,   59302870, 1086768468,  733960061 },
    { 2142830593, 2142830591, 1184916005, 1079082138,  801265712, 1392890675 },
    { 2142803969, 2776143871, 1898723413,  612877597,  748398044,  719565838 },
    { 2142785537, 1723355135, 1938177810,  901717203, 1921085502, 1027865724 },
    { 2142779393, 4084742143, 1843695270,  956271994, 1027905184,  437886242 },
    { 2142724097,  465002495, 1786272468, 2057509300,  596569659,  833374098 },
    { 2142707713, 3149340671, 1726077360,  110521970,  490838647,  570919333 },
    { 2142658561, 3686162431, 1631852094,  261726828,  931917077, 2005364883 },
    { 2142638081, 3199602687, 1965839564,  408833423, 1753224304, 1152041797 },
    { 2142564353,  515174399, 1080848266, 1517077457, 1548531958,  823650319 },
    { 2142533633, 2272557055,  392959315,  729816849,  921579743,  129344001 },
    { 2142529537,  359950335,   17286407, 1033141274, 1935370361,  921394177 },
    { 2142527489, 1538547711, 2022542562,  591503450,  522147359, 1308604835 },
    { 2142502913, 2142502911,  862145305, 1943481144,  733213664,  364106514 },
    { 2142498817, 4273205247, 1497774797,  362230737, 2058280749, 1402886894 },
    { 2142416897, 1186115583, 1820910794,  869347984, 1125890573,  823863638 },
    { 2142363649, 4222738431, 1712603348,  839133619,  770847044,  892019817 },
    { 2142351361, 2796662783,  639467496,  472998882,  259948593, 1009074045 },
    { 2142330881, 2612092927,  119930462,  898272391, 1611927337, 1395844887 },
    { 2142314497, 1001463807,  417987874,  952188691, 1472816610, 1525176551 },
    { 2142289921, 4021338111,  626441030, 1087932551, 1833827076, 1287261065 },
    { 2142283777,  292595711, 1437184719, 1990366532,  718034518, 2141169066 },
    { 2142277633,  783323135,  409102935, 1109091844, 1748524698, 1404314290 },
    { 2142263297, 1634752511, 1332648256, 1458675808, 1235027887,  862728790 },
    { 2142208001, 1068466175, 1397470467, 1098539573, 1097351447, 1965727963 },
    { 2142164993,  695130111, 1066940847,    3394841,  337813155, 2063673696 },
    { 2142097409, 3064844287,  297225318,  190118328,  120193342, 1425544062 },
    { 2142087169,   23963647, 1242139544,  508378060, 2119898775, 1644552134 },
    { 2142078977, 1735231487,   34593522,  662801663, 1837465297, 1388457155 },
    { 2142074881,  393050111, 1775241888,  546076620,  753976398, 1286409850 },
    { 2142044161, 2142044159, 1993353265,   20421055, 1749390716,  453736187 },
    { 2142025729, 3144464383, 1054015161,  216592874,  174350842, 2000851460 },
    { 2142011393, 1068269567, 1022043540,  154322400, 1364900586, 1216790673 },
    { 2141974529, 4272680959,  878244511,  450223676,  840019780,  936239114 },
    { 2141943809, 4151015423,  181002276, 1766661673,  824377997,  898611110 },
    { 2141933569, 2259374079,  921001808,  138101311, 1597307312, 1683735850 },
    { 2141931521,  996886527, 2026958630,  786548950,  491009818, 1487647832 },
    { 2141902849, 3916093439, 1774507217, 1503936548, 2011562721,  803375820 },
    { 2141890561, 4050298879, 1242184656, 1606622264,  973689178, 1298783383 },
    { 2141857793, 1500129279,   47495456, 1818547837, 1933124842, 1327760978 },
    { 2141833217, 3546925055,  534546202,  500926182, 2118308644, 1496583315 },
    { 2141820929, 1969854463,  457737750,  690473287, 1631943651,  664359263 },
    { 2141786113, 1588137983, 1837204275, 2031397019, 1967667817,  905298889 },
    { 2141771777, 1231607807, 1585138177,   54300848,  314627109,  927112984 },
    { 2141759489, 2439555071, 1154859258, 1383763879, 1971680935, 2108097075 },
    { 2141749249, 1068007423, 2080935967,  859296785, 1197038946, 1880678306 },
    { 2141685761, 3345451007,  517526213, 1550564945, 1632439809,  954282998 },
    { 2141673473, 2439469055,   21649850, 2046161117,  552392242,  103443123 },
    { 2141669377, 2070366207,  126251361, 1742664644, 1482481206,  605966977 },
    { 2141655041, 2661748735,  484235305, 1528710429,  354771509,  593774164 },
    { 2141587457,  526780415,  574888543,  955760611,  687141330, 1030240293 },
    { 2141583361, 3748001791, 1371847173, 1144908715,  184363050, 1463331359 },
    { 2141575169, 1499846655, 1229054288, 1538452901,  324225902, 1425521960 },
    { 2141546497, 1164273663, 1768171221,  430711736, 1956344257,  358993721 },
    { 2141515777,  514125823, 1883057193, 1188334395,  254771003,  712002260 },
    { 2141495297,  463773695, 1894308447, 2130610251,   69814245, 2121489732 },
    { 2141483009, 3466883071,  950896971, 1258381554,  825951706,  195111043 },
    { 2141458433, 4272164863,  566843170,   64378978, 1469333580, 1466451638 },
    { 2141360129, 4003631103,  510897768, 2054940459, 1603364306, 1896684552 },
    { 2141325313, 1600260095,  309414728,  783698702,  845623609, 2118606683 },
    { 2141317121, 3714181119,   41910923, 1219136678, 1953984968, 1546372147 },
    { 2141286401, 1856073727, 1171249093,  986447182, 1530161498, 1359644991 },
    { 2141267969,  694233087, 1211133465,  844862374, 1144145329,  372321440 },
    { 2141255681, 2405496831, 1328934139,  735916721, 1296250995, 1612100237 },
    { 2141243393, 3814770687,  520479708,  525351865, 2026115355,  538775863 },
    { 2141214721, 1633703935,  504183101,  663335303,  715380266,   34424233 },
    { 2141212673, 1721782271,  603205901, 1433302473, 1227056696, 1431443425 },
    { 2141202433, 2036344831, 1604585501, 1229299775,  752118923, 1881364338 },
    { 2141175809, 1872740351, 1733516714, 1807146636,  363795364, 1986179172 },
    { 2141165569, 1432328191, 1490189496, 1320489732, 1641816108,  578038958 },
    { 2141073409,  916336639,  873759781, 1556749288,  651084845, 1015729028 },
    { 2141052929, 4221427711,  979186233, 1762104735,  715530680,  622504930 },
    { 2141040641,  647868415,  949895441, 2025808022,  160106133,  561883724 },
    { 2141028353, 1067286527, 2135838697,  916257035, 1402241650,  750070220 },
    { 2141011969, 4020060159,  611765852, 1170281544, 1552266705,  329393240 },
    { 2140999681, 3734835199,  351284530,  998193986, 2031434746, 1932350134 },
    { 2140997633, 2942109695, 1853355265, 1185563841,  237281087,  440781243 },
    { 2140993537, 1331492863,  676775069,  495308340, 1540448795,  750732506 },
    { 2140942337, 4137431039, 1645148093, 2102068815, 2126166725, 1570735656 },
    { 2140925953, 4271632383,  759158315,  871789395,  712612398, 1673104634 },
    { 2140917761, 4137406463, 1126409570,  487401697,  790501062, 2003679138 },
    { 2140887041, 3512424447,  356555373,  692136311, 1873117117, 2056578551 },
    { 2140837889, 1163565055,  367306155,  549695576, 1539499132, 1848189620 },
    { 2140788737, 2572802047,  558045408, 1566269988, 1578573646, 1949949243 },
    { 2140766209, 1067024383, 1525495467,  488941581, 1332090451, 1459824799 },
    { 2140764161, 3612964863,  453729911, 1063914887,  792300614, 2072819909 },
    { 2140696577, 1318612991, 1154564043, 1249648119, 1281812338, 1631278485 },
    { 2140684289, 1872248831, 2118938259,  262551938, 1786968202,   55549365 },
    { 2140653569, 4082616319, 1285628803,   80889460,  220865202, 1452802925 },
    { 0, 0, 0, 0, 0, 0 }
};
