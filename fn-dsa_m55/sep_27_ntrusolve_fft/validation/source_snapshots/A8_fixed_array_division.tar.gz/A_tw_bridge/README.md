# A8 — hybrid with exact Q32 input and reciprocal boundaries

This folder name records the original TW + DS-bridge experiment. The CURRENT
NTRU intermediate function has been restored byte-for-byte from the frozen
ntt_opt source, because every measured intermediate size lost after including
its surrounding work. Its called `poly_big_to_fixed` is now implemented by
`fndsa_fixed_input_mve`: four-coefficient limb selection/sign extension/shifts
with exactly the original Q32 output, masked loads and short stores for n=1/2.
There is no new FP conversion at this boundary. Only solve_NTRU_depth0 uses double preparation, the local
DS MVE FFT bridge, native FP64 division and checked integer rounding.
Division zero/range predicates use fixed-count inline assembly; the A4/A5
timing issue and A6 finite operand tests are documented in validation/ct_results.md.

A8 additionally batches `vect_inv_mul2e_fft`'s original Q32 divisions at
public logn>=3 through the locally written `fndsa_fxr_div4`. VLD2/VST2
deinterleave/interleave the existing fxr words; the four quotients retain
the original bit recurrence, rounding, signs and lane-local carries.
The array representation is unchanged, and the global scalar divider and
candidate-check invnorm are not replaced. logn=1/2 retains the scalar path.

No new optimization of candidate orthonorm/invnorm, NTT, CRT, Bezout, signing
or verification. No secret-dependent precision fallback, no SLOTHY. Everything
is implemented in this source tree, not selected from another tree by linker
or build backend flags. The generated instrumentation lives under validation.

A0 original bridge, A1 small fixed, A2 fused point multiply, and A3 direct
native FP64 control are archived under ../validation/source_snapshots. Public
support routines from those experiments remain here for reproducibility;
unused functions are NOT credited as executed optimizations. This is still
an experimental candidate, not a newly deployed production reference.

See ../result.md for actual measurements and validation limitations.
The independent fixed-input oracle, small-size guard tests, timing and
current-source KAT gates are in ../validation/fixed_input_results.md.
The new reciprocal's raw-word, paired performance and full-keygen evidence
is in ../validation/fixed_division_results.md. Only gates matching the
current source hashes in current_validation.json apply to this version.
