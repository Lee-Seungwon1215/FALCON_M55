# B4 — continuous two-FP32 NTRU workspace

For logn>=4 the NTRU approximation arrays remain two FP32 components per real
or imaginary value. Small public sizes keep the original fixed path.

This is a hybrid: the FFT uses the local MVE assembly, while point products,
norms and divisions decode one coefficient into integer registers, apply the
original Q32 arithmetic rule and encode the output once. There is no complete
Q32 polynomial conversion between each operation and no secret fallback.
The input/output normalization is still significant and this candidate loses
to ntt_opt in whole key generation. It is NOT selected as the production ref.

Source is independent, no cross-candidate crypto linking or backend flags.
Original orthonorm, NTT, CRT, Bezout, signing and verification are untouched.
See ../result.md, ../research/experiment_log.md and the archived manifests.
