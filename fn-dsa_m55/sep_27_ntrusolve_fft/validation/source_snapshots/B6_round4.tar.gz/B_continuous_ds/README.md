# B6 — continuous two-FP32 NTRU workspace

For logn>=4 the NTRU approximation arrays remain two FP32 components per real
or imaginary value. Small public sizes keep the original fixed path.

This is a hybrid: the FFT uses the local MVE assembly, while point products,
norms and divisions decode one coefficient into integer registers, apply the
original Q32 arithmetic rule and encode the output once. There is no complete
Q32 polynomial conversion between each operation and no secret fallback.
The input/output normalization is still significant and this candidate loses
to ntt_opt in whole key generation. It is NOT selected as the production ref.

B5 adds `fndsa_ds_encode4()` in this directory's own `kgen_fft_cm55.s`:
four-lane exact translation of the former scalar input expansion, retaining
the original limb scan/secret-scale masks in `fndsa_ds_from_big()`.
B6 adds `fndsa_ds_round4()` and calls it from `fndsa_ds_to_k()` for logn>=3:
original TwoSum ordering, finite/range masks, negative low-component tie
correction, true 64-bit sum/overflow checks. Its scratch is 64 private bytes,
not an extra polynomial buffer. Smaller public sizes retain the scalar path.
These changes do not replace the FFT arithmetic or silently change Q32 rules.

Source is independent, no cross-candidate crypto linking or backend flags.
Original orthonorm, NTT, CRT, Bezout, signing and verification are untouched.
See ../result.md, ../research/experiment_log.md and the archived manifests.
