# B8 — continuous two-FP32 NTRU workspace

For logn>=4 the NTRU approximation arrays remain two FP32 components per real
or imaginary value. Small public sizes keep the original fixed path.

This is a hybrid: the FFT uses the local MVE assembly, while point products,
norms and divisions decode one coefficient into integer registers, apply the
original Q32 arithmetic rule and encode the output once. There is no complete
Q32 polynomial conversion between each operation and no secret fallback.
The input/output normalization is still significant and this candidate loses
to ntt_opt in whole key generation. It is NOT selected as the production ref.

B5 adds `fndsa_ds_encode4()` in this directory's own `kgen_fft_cm55.s`:
four-lane exact translation of the former scalar input expansion, retaining
the original limb scan/secret-scale masks in `fndsa_ds_from_big()`.
B6 adds `fndsa_ds_round4()` and calls it from `fndsa_ds_to_k()` for logn>=3:
original TwoSum ordering, finite/range masks, negative low-component tie
correction, true 64-bit sum/overflow checks. Its scratch is 64 private bytes,
not an extra polynomial buffer. Smaller public sizes retain the scalar path.
These changes do not replace the FFT arithmetic or silently change Q32 rules.

B7 adds `fndsa_ds_decode4()` and a four-complex-coefficient tile in
`fndsa_ds_mul()`. The original three-product integer Q32 multiplication is
retained, while four-lane decoding/encoding amortizes its FP32 boundaries.
The decoder preserves small/subnormal inputs when scaling by 2^32 through
integer exponent handling plus exact uint23-to-FP conversion. It must not
use an ordinary MVE multiply on a subnormal input: that lost the value in a
dedicated board test even with scalar FPSCR.FZ clear. No secret fallback is
introduced. The private point tile is 128 bytes, not a polynomial array.

B8 uses the same four-lane representation edges in `fndsa_ds_inverse()`
and `fndsa_ds_div_real()` (64/96-byte private tiles). Squares, norms and
`inner_fxr_div()` remain the original Q32 arithmetic, not native FP division.
Both division input aliasing and untouched array slots are checked separately.

Source is independent, no cross-candidate crypto linking or backend flags.
Original orthonorm, NTT, CRT, Bezout, signing and verification are untouched.
See ../result.md, ../research/experiment_log.md and the archived manifests.
