#ifndef SIGN_FFT_PROBES_H
#define SIGN_FFT_PROBES_H
#include "sign_inner.h"
void profile_fpoly_FFT(unsigned logn, fpr *f);
void profile_fpoly_iFFT(unsigned logn, fpr *f);
void profile_fpoly_LDL_fft(unsigned logn, const fpr *g00, fpr *g01, fpr *g11);
void profile_fpoly_split_fft(unsigned logn, fpr *f0, fpr *f1, const fpr *f);
void profile_fpoly_merge_fft(unsigned logn, fpr *f, const fpr *f0, const fpr *f1);
#endif
