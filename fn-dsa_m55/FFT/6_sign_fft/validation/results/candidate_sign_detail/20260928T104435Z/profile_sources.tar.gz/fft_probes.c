/* Test-only call scopes. Production ASM is not modified. */
#include "profile.h"
#include "fft_probes.h"
__attribute__((noinline)) void profile_fpoly_FFT(unsigned logn, fpr *f)
{
    FNDSA_SCOPE(CAT_SG_FFT);
    fpoly_FFT(logn, f);
}
__attribute__((noinline)) void profile_fpoly_iFFT(unsigned logn, fpr *f)
{
    FNDSA_SCOPE(CAT_SG_IFFT);
    fpoly_iFFT(logn, f);
}
__attribute__((noinline)) void profile_fpoly_LDL_fft(unsigned logn, const fpr *g00, fpr *g01, fpr *g11)
{
    FNDSA_SCOPE(CAT_SG_LDL);
    fpoly_LDL_fft(logn, g00, g01, g11);
}
__attribute__((noinline)) void profile_fpoly_split_fft(unsigned logn, fpr *f0, fpr *f1, const fpr *f)
{
    FNDSA_SCOPE(CAT_SG_SPLIT);
    fpoly_split_fft(logn, f0, f1, f);
}
__attribute__((noinline)) void profile_fpoly_merge_fft(unsigned logn, fpr *f, const fpr *f0, const fpr *f1)
{
    FNDSA_SCOPE(CAT_SG_MERGE);
    fpoly_merge_fft(logn, f, f0, f1);
}
