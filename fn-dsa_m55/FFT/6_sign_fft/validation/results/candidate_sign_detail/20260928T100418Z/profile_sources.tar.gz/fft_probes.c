/* Test-only call scopes. Production ASM is not modified. */
#include "profile.h"
#include "fft_probes.h"
__attribute__((noinline)) void profile_fpoly_FFT(unsigned logn, fpr *f)
{
    FNDSA_SCOPE(CAT_SG_FFT);
    fpoly_FFT(logn, f);
}
__attribute__((noinline)) void profile_fpoly_iFFT(unsigned logn, fpr *f)
{
    FNDSA_SCOPE(CAT_SG_IFFT);
    fpoly_iFFT(logn, f);
}
