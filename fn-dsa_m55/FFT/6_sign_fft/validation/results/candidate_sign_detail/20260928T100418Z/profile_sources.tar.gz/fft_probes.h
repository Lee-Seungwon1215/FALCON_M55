#ifndef SIGN_FFT_PROBES_H
#define SIGN_FFT_PROBES_H
#include "sign_inner.h"
void profile_fpoly_FFT(unsigned logn, fpr *f);
void profile_fpoly_iFFT(unsigned logn, fpr *f);
#endif
