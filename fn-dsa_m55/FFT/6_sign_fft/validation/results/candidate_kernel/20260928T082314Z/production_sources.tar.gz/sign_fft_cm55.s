/* Signing binary64 FFT/iFFT, Cortex-M55. No FP32/Q32 conversions.
 * A real scalar occupies one D register. The first n/2 array slots are
 * real parts, the second n/2 imaginary parts. All products are rounded
 * before their sum/difference; do not replace these operations by VFMA.
 * Public ABI: r0=logn (1..10), r1=in-place fpr array. No helper calls.
 */
 .syntax unified
 .thumb
 .arch armv8.1-m.main
 .fpu fpv5-d16

 /* Forward: (x,y) -> (x+y*s,x-y*s). d0,d1 contain s. */
 .macro FORWARD
 vldr d2,[r2]
 vldr d3,[r3]
 vldr d4,[r4]
 vldr d5,[r5]
 vmul.f64 d6,d4,d0
 vmls.f64 d6,d5,d1
 vmul.f64 d4,d4,d1
 vmla.f64 d4,d5,d0
 vadd.f64 d5,d2,d6
 vsub.f64 d2,d2,d6
 vstr d5,[r2]
 vstr d2,[r4]
 vadd.f64 d6,d3,d4
 vsub.f64 d3,d3,d4
 vstr d6,[r3]
 vstr d3,[r5]
 .endm

 /* Inverse: (x,y) -> (x+y,(x-y)*conj(s)). d1 already negated. */
 .macro INVERSE
 vldr d2,[r2]
 vldr d3,[r3]
 vldr d4,[r4]
 vldr d5,[r5]
 vsub.f64 d6,d2,d4
 vsub.f64 d7,d3,d5
 vadd.f64 d2,d2,d4
 vadd.f64 d3,d3,d5
 vstr d2,[r2]
 vstr d3,[r3]
 vmul.f64 d2,d6,d0
 vmls.f64 d2,d7,d1
 vmul.f64 d6,d6,d1
 vmla.f64 d6,d7,d0
 vstr d2,[r4]
 vstr d6,[r5]
 .endm

 /* Two independent butterflies. d8-d13 are saved once per function,
  * never spilled in the hot loop. Same twiddle, adjacent coefficients. */
 .macro FORWARD2
 vldr d4,[r4]
 vldr d5,[r5]
 vldr d10,[r4,#8]
 vldr d11,[r5,#8]
 vmul.f64 d6,d4,d0
 vmul.f64 d12,d10,d0
 vmls.f64 d6,d5,d1
 vmls.f64 d12,d11,d1
 vmul.f64 d4,d4,d1
 vmul.f64 d10,d10,d1
 vldr d2,[r2]
 vldr d8,[r2,#8]
 vmla.f64 d4,d5,d0
 vmla.f64 d10,d11,d0
 vadd.f64 d5,d2,d6
 vadd.f64 d11,d8,d12
 vsub.f64 d2,d2,d6
 vsub.f64 d8,d8,d12
 vldr d3,[r3]
 vldr d9,[r3,#8]
 vstr d5,[r2]
 vstr d11,[r2,#8]
 vstr d2,[r4]
 vstr d8,[r4,#8]
 vadd.f64 d6,d3,d4
 vadd.f64 d12,d9,d10
 vsub.f64 d3,d3,d4
 vsub.f64 d9,d9,d10
 vstr d6,[r3]
 vstr d12,[r3,#8]
 vstr d3,[r5]
 vstr d9,[r5,#8]
 .endm

 .macro INVERSE2
 vldr d2,[r2]
 vldr d3,[r3]
 vldr d4,[r4]
 vldr d5,[r5]
 vldr d8,[r2,#8]
 vldr d9,[r3,#8]
 vldr d10,[r4,#8]
 vldr d11,[r5,#8]
 vsub.f64 d6,d2,d4
 vsub.f64 d12,d8,d10
 vsub.f64 d7,d3,d5
 vsub.f64 d13,d9,d11
 vadd.f64 d2,d2,d4
 vadd.f64 d8,d8,d10
 vadd.f64 d3,d3,d5
 vadd.f64 d9,d9,d11
 vstr d2,[r2]
 vstr d8,[r2,#8]
 vstr d3,[r3]
 vstr d9,[r3,#8]
 vmul.f64 d2,d6,d0
 vmul.f64 d8,d12,d0
 vmls.f64 d2,d7,d1
 vmls.f64 d8,d13,d1
 vmul.f64 d6,d6,d1
 vmul.f64 d12,d12,d1
 vmla.f64 d6,d7,d0
 vmla.f64 d12,d13,d0
 vstr d2,[r4]
 vstr d8,[r4,#8]
 vstr d6,[r5]
 vstr d12,[r5,#8]
 .endm

 .section .text.fndsa_fpoly_FFT,"ax",%progbits
 .p2align 2
 .global fndsa_fpoly_FFT
 .type fndsa_fpoly_FFT,%function
 .thumb_func
fndsa_fpoly_FFT:
 cmp r0,#1
 bls .Lfft_return
 vpush {d8-d13}
 push {r4-r11,lr}
 sub sp,sp,#12
 str r1,[sp]
 mov r8,#4
 lsl r8,r8,r0                 /* imaginary offset: 8*(n/2) */
 lsr r7,r8,#1                /* butterfly distance in bytes */
 sub r9,r0,#1                /* layers remaining */
 mov r10,#1                  /* groups in current layer */
 ldr r6,=fndsa_sign_gm+32
.Lfft_stage:
 cmp r7,#8
 beq .Lfft_last
 ldr r2,[sp]
 add r3,r2,r8
 mov r11,r10
.Lfft_group:
 add r4,r2,r7
 add r5,r3,r7
 vldr d0,[r6]
 vldr d1,[r6,#8]
 add r6,r6,#16
 lsr lr,r7,#4
 dls lr,lr
.Lfft_pair:
 FORWARD2
 add r2,r2,#16
 add r3,r3,#16
 add r4,r4,#16
 add r5,r5,#16
 le lr,.Lfft_pair
 add r2,r2,r7
 add r3,r3,r7
 subs r11,r11,#1
 bne .Lfft_group
 add r6,r6,r10,lsl #4         /* next layer starts at twice m */
 lsr r7,r7,#1
 lsl r10,r10,#1
 subs r9,r9,#1
 bne .Lfft_stage
 b .Lfft_done
.Lfft_last:
 ldr r2,[sp]
 add r3,r2,r8
 add r4,r2,#8
 add r5,r3,#8
 mov lr,r10
 dls lr,lr
.Lfft_last_loop:
 vldr d0,[r6]
 vldr d1,[r6,#8]
 FORWARD
 add r6,r6,#16
 add r2,r2,#16
 add r3,r3,#16
 add r4,r4,#16
 add r5,r5,#16
 le lr,.Lfft_last_loop
.Lfft_done:
 add sp,sp,#12
 pop {r4-r11,lr}
 vpop {d8-d13}
.Lfft_return:
 bx lr
 .size fndsa_fpoly_FFT,.-fndsa_fpoly_FFT
 .ltorg

 .section .text.fndsa_fpoly_iFFT,"ax",%progbits
 .p2align 2
 .global fndsa_fpoly_iFFT
 .type fndsa_fpoly_iFFT,%function
 .thumb_func
fndsa_fpoly_iFFT:
 cmp r0,#1
 bls .Lifft_return
 vpush {d8-d13}
 push {r4-r11,lr}
 sub sp,sp,#12
 str r1,[sp]
 str r0,[sp,#4]
 mov r8,#4
 lsl r8,r8,r0
 mov r7,#8
 sub r9,r0,#1
 lsr r10,r8,#4
 /* First layer has one butterfly per twiddle: no nested singleton loop. */
 ldr r6,=fndsa_sign_gm
 add r6,r6,r10,lsl #5
 mov r2,r1
 add r3,r2,r8
 add r4,r2,#8
 add r5,r3,#8
 mov lr,r10
 dls lr,lr
.Lifft_first_loop:
 vldr d0,[r6]
 vldr d1,[r6,#8]
 vneg.f64 d1,d1
 INVERSE
 add r6,r6,#16
 add r2,r2,#16
 add r3,r3,#16
 add r4,r4,#16
 add r5,r5,#16
 le lr,.Lifft_first_loop
 mov r7,#16
 lsr r10,r10,#1
 subs r9,r9,#1
 beq .Lifft_scaling
.Lifft_stage:
 ldr r6,=fndsa_sign_gm
 add r6,r6,r10,lsl #5
 ldr r2,[sp]
 add r3,r2,r8
 mov r11,r10
.Lifft_group:
 add r4,r2,r7
 add r5,r3,r7
 vldr d0,[r6]
 vldr d1,[r6,#8]
 vneg.f64 d1,d1
 add r6,r6,#16
 lsr lr,r7,#4
 dls lr,lr
.Lifft_pair:
 INVERSE2
 add r2,r2,#16
 add r3,r3,#16
 add r4,r4,#16
 add r5,r5,#16
 le lr,.Lifft_pair
 add r2,r2,r7
 add r3,r3,r7
 subs r11,r11,#1
 bne .Lifft_group
 lsl r7,r7,#1
 lsr r10,r10,#1
 subs r9,r9,#1
 bne .Lifft_stage

.Lifft_scaling:
 /* Exact fpr_div2e: subtract e from the exponent unless sign flips.
  * Only the high word changes; low significand bits need no load/store.
  * In particular both signed zeros retain their original bit patterns.
  */
 ldr r0,[sp,#4]
 sub r4,r0,#1
 lsl r4,r4,#20
 lsr lr,r8,#2
 ldr r1,[sp]
 add r1,r1,#4
 dls lr,lr
.Lifft_scale:
 ldr r2,[r1]
 sub r3,r2,r4
 eor r2,r2,r3
 asr r2,r2,#31
 and r2,r2,r4
 add r3,r3,r2
 str r3,[r1],#8
 le lr,.Lifft_scale
 add sp,sp,#12
 pop {r4-r11,lr}
 vpop {d8-d13}
.Lifft_return:
 bx lr
 .size fndsa_fpoly_iFFT,.-fndsa_fpoly_iFFT
 .ltorg
 .section .note.GNU-stack,"",%progbits
