/* M55 native binary64 LDL. Public logn=1..10.
 * Four separately rounded products, then sum and subtract; no fused FMA.
 * r0=logn, r1=g00, r2=g01, r3=g11. No helper calls or secret branches. */
 .syntax unified
 .thumb
 .arch armv8.1-m.main
 .fpu fpv5-d16
 .text
 .p2align 2
 .global fndsa_fpoly_LDL_fft
 .type fndsa_fpoly_LDL_fft,%function
 .thumb_func
fndsa_fpoly_LDL_fft:
 push {r4,lr}
 sub r0,r0,#1
 mov r4,#1
 lsl r4,r4,r0
 add r12,r2,r4,lsl #3
 vmov.f64 d7,#1.0
 cmp r4,#1
 beq .Lsingle
 vpush {d8-d13}
 lsr r4,r4,#1
 dls lr,r4
.Lloop:
 vldr d0,[r1]
 vldr d1,[r2]
 vldr d2,[r12]
 vldr d3,[r3]
 vldr d8,[r1,#8]
 vldr d9,[r2,#8]
 vldr d10,[r12,#8]
 vldr d11,[r3,#8]
 vdiv.f64 d0,d7,d0
 vmul.f64 d4,d1,d0
 vmul.f64 d5,d2,d0
 vmul.f64 d1,d4,d1
 vmul.f64 d2,d5,d2
 vadd.f64 d1,d1,d2
 vsub.f64 d3,d3,d1
 vneg.f64 d5,d5
 vstr d3,[r3]
 vstr d4,[r2]
 vstr d5,[r12]
 vdiv.f64 d8,d7,d8
 vmul.f64 d12,d9,d8
 vmul.f64 d13,d10,d8
 vmul.f64 d9,d12,d9
 vmul.f64 d10,d13,d10
 vadd.f64 d9,d9,d10
 vsub.f64 d11,d11,d9
 vneg.f64 d13,d13
 vstr d11,[r3,#8]
 vstr d12,[r2,#8]
 vstr d13,[r12,#8]
 add r1,r1,#16
 add r2,r2,#16
 add r3,r3,#16
 add r12,r12,#16
 le lr,.Lloop
 vpop {d8-d13}
 pop {r4,pc}
.Lsingle:
 vldr d0,[r1]
 vldr d1,[r2]
 vldr d2,[r12]
 vldr d3,[r3]
 vdiv.f64 d0,d7,d0
 vmul.f64 d4,d1,d0
 vmul.f64 d5,d2,d0
 vmul.f64 d1,d4,d1
 vmul.f64 d2,d5,d2
 vadd.f64 d1,d1,d2
 vsub.f64 d3,d3,d1
 vneg.f64 d5,d5
 vstr d3,[r3]
 vstr d4,[r2]
 vstr d5,[r12]
 pop {r4,pc}
 .size fndsa_fpoly_LDL_fft,.-fndsa_fpoly_LDL_fft
 .section .note.GNU-stack,"",%progbits
