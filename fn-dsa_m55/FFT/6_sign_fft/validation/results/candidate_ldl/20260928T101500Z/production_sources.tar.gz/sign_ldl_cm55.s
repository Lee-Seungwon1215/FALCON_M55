/* M55 native binary64 LDL. Public logn=1..10.
 * Four separately rounded products, then sum and subtract; no fused FMA.
 * r0=logn, r1=g00, r2=g01, r3=g11. No helper calls or secret branches. */
 .syntax unified
 .thumb
 .arch armv8.1-m.main
 .fpu fpv5-d16
 .text
 .p2align 2
 .global fndsa_fpoly_LDL_fft
 .type fndsa_fpoly_LDL_fft,%function
 .thumb_func
fndsa_fpoly_LDL_fft:
 push {r4,lr}
 sub r0,r0,#1
 mov r4,#1
 lsl r4,r4,r0
 add r12,r2,r4,lsl #3
 vmov.f64 d7,#1.0
 vldr d0,[r1]
 vldr d1,[r2]
 vldr d2,[r12]
 vldr d3,[r3]
 subs r4,r4,#1
 beq .Ltail
 dls lr,r4
.Lloop:
 vdiv.f64 d0,d7,d0
 vmul.f64 d4,d1,d0
 vmul.f64 d5,d2,d0
 vmul.f64 d1,d4,d1
 vmul.f64 d2,d5,d2
 vldr d0,[r1,#8]
 vadd.f64 d6,d1,d2
 vldr d1,[r2,#8]
 vldr d2,[r12,#8]
 vsub.f64 d3,d3,d6
 vneg.f64 d5,d5
 vstr d3,[r3]
 vstr d4,[r2]
 vstr d5,[r12]
 vldr d3,[r3,#8]
 add r1,r1,#8
 add r2,r2,#8
 add r3,r3,#8
 add r12,r12,#8
 le lr,.Lloop
.Ltail:
 vdiv.f64 d0,d7,d0
 vmul.f64 d4,d1,d0
 vmul.f64 d5,d2,d0
 vmul.f64 d1,d4,d1
 vmul.f64 d2,d5,d2
 vadd.f64 d1,d1,d2
 vsub.f64 d3,d3,d1
 vneg.f64 d5,d5
 vstr d3,[r3]
 vstr d4,[r2]
 vstr d5,[r12]
 pop {r4,pc}
 .size fndsa_fpoly_LDL_fft,.-fndsa_fpoly_LDL_fft
 .section .note.GNU-stack,"",%progbits
