# 6_sign_fft — 서명 FFT/iFFT의 native FP64 전환

기준 소스: [Final_code/Before_slothy](../../../Final_code/Before_slothy).
기존 공통 q-NTT, RNS NTT K4C, 키생성 FFT A17을 유지하고 **서명용
`fpoly_FFT()`·`fpoly_iFFT()` 두 함수만** 하드웨어 FP64 계산으로 전환한다.
SLOTHY는 적용하지 않았다. 원본 Final_code, M55_ref, ntt_opt는 수정하지 않았다.

## 구현

생산 소스의 변경 파일은 **sign_fpoly.c 하나**다.

- 배열과 API는 기존 `fpr (= uint64_t)`를 유지한다. 이 값은 Q32 정수가 아니라 IEEE-754 binary64 비트다.
- 실수부와 허수부는 각각 double 하나로 계산한다. 추가 변환 배열이나 hi/lo 분할 표현은 없다.
- 파일 내부 `fft_load_f64()`·`fft_store_f64()`의 inline ASM `VLDR`·`VSTR`로
  8바이트 비트를 직접 이동한다. 숫자 형변환, libc memcpy 호출, double 포인터 별칭을 사용하지 않는다.
- FFT/iFFT의 반복 구조와 복소수 곱셈·합차는 C double 연산이다.
  기존 레이어·4회 실수 곱셈·회전상수 GM의 비트·반올림 순서를 유지한다.
- iFFT 마지막 정규화는 기존 `fpr_div2e()`의 지수 비트 처리를 유지한다.
- FP64는 스칼라 연산이다. MVE FP64 SIMD 또는 전체 FFT의 수작성 .s 구현은 아니다.
- 공용 fpr 산술, LDL, split/merge, Gaussian sampler, NTT, 키생성 FFT는 변경하지 않는다.
  `sign_fpr_cm4.s`는 다른 함수들이 계속 사용하므로 제거하지 않는다.

## 빌드

```sh
make CROSS_COMPILE=/path/to/arm-none-eabi-
```

기존 Makefile과 설정 헤더를 그대로 사용한다. 이 폴더의 소스만 컴파일하며,
다른 후보를 링크하거나 빌드 옵션으로 구현을 선택하지 않는다.

- GNU Arm GCC 15.2.1.
- `-mcpu=cortex-m55 -mthumb -mfpu=fpv5-d16 -mfloat-abi=hard`.
- `-O3 -ffp-contract=off -fno-fast-math -fno-strict-aliasing`.
- IEEE-754 round-to-nearest/ties-to-even 상태를 전제로 한다.
- 유효 FN-DSA 입력 범위의 정상값·부호 있는 0을 대상으로 한다.
  원본 fpr 계약 밖의 NaN/Inf/subnormal 처리까지 동등하다는 뜻은 아니다.

## 검증과 측정

[결과·제한사항](result.md), [검증 도구](validation/README.md).

`validation/`은 배포 라이브러리에 들어가지 않는다.
커널 시험에서만 원본 두 함수를 별도 이름의 oracle로 함께 컴파일한다.
전체 서명 비교는 같은 시험 프로그램을 원본/후보에 각각 빌드한 별도 펌웨어로 수행한다.
이 테스트용 비교군 선택은 생산 코드의 구현 선택 기능이 아니다.

복사되어 있던 README/result는
[백업](validation/copied_before_slothy_docs.tar.gz)에 보존했다.
`stage_profile_result.md`·`ntru_fft_profile_result.md`는 복사본의 과거 기록이며
이번 서명 FFT 결과가 아니다. 원본 [LICENSE](LICENSE)를 유지한다.
