# 서명 FFT/iFFT native FP64 — 구현 및 M55 측정 결과

측정일: 2026-09-28. 구현 경로: `fn-dsa_m55/FFT/6_sign_fft`.
비교 기준은 **Final_code/Before_slothy**이며 M55_ref의 전체 서명과 새로 비교한 기록은 아니다.
과거 프로파일링의 계측 포함 사이클과도 섞지 않았다.

## 결론

- **서명 FFT/iFFT 두 함수의 하드웨어 FP64 전환을 구현·측정했다.**
- 커널은 원본 대비 약 **3.12–3.17배**, 전체 서명은 **1.211배 / 1.223배** 빨라졌다.
- 최종 코드의 시험에서 원본 출력 비트 불일치 0, 서명 KAT 90/90(2회),
  키생성 KAT 300/300 + 추가 300/300, API 검사 통과.
- 상수시간은 정적 검토와 3,200회 입력군 시간 스크리닝 범위다. 형식 증명이나 TVLA 완료는 아니다.
- 중간 구현의 재현 가능한 ECC Fault가 있었고 로그를 보존했다.
  최종 구현의 이번 검사에서는 재현되지 않았지만 **칩/플랫폼 근본 원인을 해결했다고 주장하지 않는다.**
- SLOTHY, LDL, split/merge, sampler 추가 최적화는 하지 않았다. 원본 Final_code도 교체하지 않았다.

## 구현 범위

37개 루트 C/H/S 파일을 기준 소스와 비교한 결과 **sign_fpoly.c 한 파일만 변경**됐다.
나머지 36개 파일과 기존 Makefile은 유지한다.

1. FFT/iFFT의 활성 M55 경로 내부 연산을 `double` 곱셈·합차로 변경.
2. `fpr`는 원래 binary64 비트를 저장하는 uint64_t이므로 숫자 형변환을 하지 않는다.
   파일 내부 두 작은 helper에서 `VLDR`/`VSTR` inline ASM으로 직접 읽고 쓴다.
   실수부·허수부 각각 double 하나이며 별도 배열/hi-lo 표현이 없다.
3. 기존 GM 상수 비트, 레이어 순서, 4회 곱셈 복소곱, 배열 배치, 함수명/API 유지.
4. iFFT 최종 크기 보정은 기존 `fpr_div2e()`의 zero-aware 지수 비트 처리를 유지.
5. FP contraction/fast-math를 끈 상태로 빌드. 생성된 두 함수에 FP64 명령은 있고
   FMA(`VFMA/VFMS` 계열), numeric conversion, memcpy/FP 에뮬레이션 helper 호출은 없다.
   컴파일러가 사용한 `VMLA/VNMLS` 등은 단일 반올림의 fused FMA와 구분한다.
6. 공용 fpr 산술 및 sign_fpr_cm4.s는 그대로다. 이번 구현은 FP64 스칼라이며
   MVE FP64 SIMD나 전체 함수의 수작성 .s 구현이 아니다.

소스 SHA-256: `1163cc2d942a1ada742fd3cbb1abee2af43ac17019c66e0af445b96bba12aa0d`.

## 커널 결과

단위 cycle/call, 100회 **upper median**. 각 구현 warm-up 3회.
원본 두 함수와 후보를 동일 ELF에서, 동일 버퍼·입력으로 번갈아 실행했다.
배열 준비·정합성 비교·printf는 제외하고 함수 호출·입출력·iFFT 정규화는 포함한다.

| 함수 | n | 원본 에뮬레이션 | native FP64 | 속도 배율 | 사이클 감소 |
|---|---:|---:|---:|---:|---:|
| `fpoly_FFT()` | 512 | 602,844 | 190,422 | **3.166배** | 68.41% |
| `fpoly_iFFT()` | 512 | 626,025 | 200,911 | **3.116배** | 67.91% |
| `fpoly_FFT()` | 1024 | 1,353,535 | 427,501 | **3.166배** | 68.42% |
| `fpoly_iFFT()` | 1024 | 1,403,141 | 448,995 | **3.125배** | 68.00% |

이 값은 해당 변환 **1회**의 결과이며 서명 중 5회 FFT·2회 iFFT 누적값이 아니다.
시험용 원본은 Before_slothy의 상수표와 두 함수 원문에서 추출하고 이름만 oracle로 바꿨다.
원본과 후보의 코드 주소는 다르므로 같은 절대 주소를 고정한 실험이라고 부르지 않는다.

## 전체 서명 결과

단위 **평균 cycle/sign**. 각 크기·구현별 100회 시험을 두 번 실행, 총 200회.
warm-up 3회. 모든 재시도·키 준비·인코딩을 포함한 seeded signing API를 계측한다.
키생성·외부 검증·출력 해시는 계측 밖이다.

| n | Before_slothy | 6_sign_fft | 속도 배율 | 사이클 감소 |
|---|---:|---:|---:|---:|
| 512 | 18,017,473.51 | 14,873,579.46 | **1.211배** | **17.45%** |
| 1024 | 38,739,603.73 | 31,682,009.64 | **1.223배** | **18.22%** |

같은 메시지, 같은 10개 키 준비, 마지막 키에 같은 100개 signing seed를 사용했다.
512 fingerprint `9895079d`, 1024 `a020dd02`가 원본/후보/이전 sign_control과 일치한다.
별도의 SHA 기반 서명 KAT도 아래와 같이 확인했다.

원본 두 번의 total은 동일했다. 후보 512 total도 동일했고,
1024 두 번째 total은 100회 합계에서 2 cycles 차이였다.
서명 펌웨어의 배치 정책은 같지만 모든 함수의 절대 주소를 고정한 것은 아니다.
이번 결과는 **서명 FFT 변경의 증분 효과**다. 키생성·검증 전체 성능은 이번에 재측정하지 않았다.

## 정확성·KAT·검증

| 검사 | 최종 결과 |
|---|---|
| FFT/iFFT 출력 비교 | logn=1..10 × 128입력 × 3경로 = 3,840 비교; 2회 모두 원본과 비트 불일치 0 |
| 버퍼 guard | 오류 0 |
| FFT→iFFT 왕복 | 작은 정수 입력에서 최대 절대 오차 3.410605131648e-13 |
| 기존 키생성 KAT | 300/300 일치 및 NTRU 방정식 검사 통과 |
| 추가 키생성 KAT | 300/300 일치 |
| 서명 KAT | 90/90, 동일 시험 2회 모두 통과; 정상 수락·변조 거부 |
| API 검사 | 정상 64건, 잘못된 입력 3,902건 거부; failures=0, guards=0 |
| 전체 서명 성능 시험 | 두 번 모두 512/1024 각 100개 서명 검증·fingerprint 통과 |
| 하드웨어 | 채택된 최종 실행 모두 CFSR/HFSR/AFSR=0, TCM/ECC 검사 통과 |

왕복 오차와 원본 대비 오차는 다르다. FFT/iFFT 왕복 자체에는 원본에도 부동소수점
반올림 오차가 있다. **원본과 후보 간의 출력 차이는 시험한 모든 경우 0**이다.
이 결과만으로 모든 가능한 입력의 비트 동등성이나 오차 상한을 증명한 것은 아니다.
원본 계약에서 제외한 NaN/Inf/subnormal은 지원 동등성 범위 밖이다.

## 상수시간 관련 검사

생성 기계어에서 두 함수의 분기·주소는 공개 logn·레이어·루프 인덱스로 결정된다.
데이터에 따른 비교/분기/테이블 인덱스는 추가하지 않았다.
FP64 나눗셈/제곱근은 이번 두 함수에 없으며 helper 호출·수치 형변환도 없다.
실제 기계어는 [FFT](validation/fndsa_fpoly_FFT.dis), [iFFT](validation/fndsa_fpoly_iFFT.dis)에 저장했다.

512/1024, 정/역변환 각각 8입력군 × 100회 = 3,200회.
0, 부호 있는 0, impulse, 교대 부호, 작은 정수, 지수·가수 분포,
상쇄 근접값, 더 넓은 정상 지수 범위를 시험했다.

| n | 방향 | 전체 입력군 min–max | 입력군 평균 최대 차이 |
|---|---|---:|---:|
| 512 | FFT | 190,424–190,425 | 0.01 cycles |
| 512 | iFFT | 200,913–200,914 | 0.01 cycles |
| 1024 | FFT | 427,503–427,504 | 0.01 cycles |
| 1024 | iFFT | 448,997–448,998 | 0.01 cycles |

계측 호출부 차이로 CT 표의 절대 시간은 커널 성능 표보다 약 2 cycles 크다.
관측된 1-cycle 범위/0.01-cycle 평균 차이를 비밀 의존 시간의 증명이나 반증으로 확대하지 않는다.
**전체 서명·장치에 대한 상수시간 형식 증명, 전력/EM 검사는 수행하지 않았다.**

## 초기 구현과 Fault 이력

1. 표준 memcpy로 비트를 이동한 첫 구현은 freestanding 빌드에서 실제 libc 호출이 남았다.
   정확도/KAT는 통과했지만 512 FFT 615,534 / iFFT 623,445 cycles로 이득이 거의 없었다.
   [초기 결과](validation/results/candidate_kernel/20260928T071930Z/raw.log).
2. explicit builtin memcpy로 호출을 없애면 512 FFT 228,595 / iFFT 236,011 cycles.
   [중간 결과](validation/results/candidate_kernel/20260928T072124Z/raw.log).
   다만 정수 레지스터/스택을 거치는 비효율적인 비트 이동이 남아 있었다.
3. 이 중간 바이너리의 서명 KAT가 80건 일치 후 1024 구간에서 3회 Fault로 중단됐다.
   `CFSR=0x100`, `HFSR=0x2`, `AFSR=0x10000000`, 진단 시 PC `0x1001217c`.
   AFSR[28] FECC는 명령 fetch의 수정 불가능 ECC 오류다.
   [ST PM0273](https://www.st.com/resource/en/programming_manual/pm0273-stm32-cortexm55-mcus-programming-manual-stmicroelectronics.pdf).
   [첫 Fault](validation/results/candidate_sigkat/20260928T072252Z/raw.log),
   [재현](validation/results/candidate_sigkat/20260928T072447Z/raw.log),
   [적재 일치·확장 진단](validation/results/candidate_sigkat/20260928T072548Z/raw.log).
4. 진단 후 디버그 연결 실패도 1회 있었고 지정한 M55의 하드웨어 reset 후 연결을 복구했다.
   ECC를 끄거나 캐시·클럭·KAT 입력을 바꾸지 않았다.
5. 최종 VLDR/VSTR helper는 불필요한 정수/스택 이동을 제거한다.
   이번 최종 검사와 두 번의 전체 서명 KAT에서는 Fault가 재현되지 않았다.
   **코드 변경으로 바이너리 배치/접근 패턴도 달라졌으므로,
   이전 ECC Fault의 근본 원인이 규명·수정됐다는 결론은 내리지 않는다.**

실패·이전 버전의 측정은 최종 성능/검증 집계에서 제외하고 로그를 보존했다.
두 중간 소스는 `validation/initial_memcpy.patch`, `validation/builtin_memcpy.patch`로
원본 대비 차이를 보존했다.

## 빌드·보드 조건과 메모리

- NUCLEO-N657X0-Q / STM32N657, ST-Link `003C00223335510735383531`.
- 기존 pinned mlkem-native 기반 플랫폼, Zephyr 4.4.1.
- CPU/SYSCLK/HCLK 800/400/200 MHz.
- ITCM 코드, DTCM 상수·데이터·스택, 각각 256 KiB. cache OFF, ECC ON.
- GNU Arm GCC 15.2.1. `-mcpu=cortex-m55 -mthumb -mfpu=fpv5-d16 -mfloat-abi=hard`.
- `-O3 -ffp-contract=off -fno-fast-math -fno-strict-aliasing`.
- 커널·전체 서명 계측 중 IRQ OFF. KAT/API는 기존 IRQ 상태를 유지.
- 라이브러리는 기존 Makefile로 이 경로 소스만 빌드. 보드 테스트의 baseline/oracle는
  검증용이며 생산 구현 선택 옵션/외부 후보 링크가 아니다.

| 서명 성능 펌웨어 예약량 | Before_slothy | 6_sign_fft |
|---|---:|---:|
| ITCM (링커 표시 FLASH) | 124,532 B | 124,128 B |
| DTCM (링커 표시 RAM) | 245,496 B | 245,496 B |

두 함수의 코드 크기 합은 932 B → 528 B, 404 B 감소.
DTCM 예약량에는 테스트 버퍼와 예약 스택이 포함된다. 동적 stack high-water 측정값은 아니다.
별도 서명 KAT 펌웨어도 ITCM 126,524 B / DTCM 251,496 B로 256 KiB 범위 안이다.

## 로그·재현

[실행 방법](validation/README.md), [기계 집계](validation/summary.json).
각 실행 디렉터리에 raw.log, manifest.json, benchmark.elf, compile_commands.json,
disassembly.txt가 있고 최종 실행에는 production_sources.tar.gz도 있다.

- baseline_sign: [20260928T072154Z](validation/results/baseline_sign/20260928T072154Z/raw.log), [20260928T073654Z](validation/results/baseline_sign/20260928T073654Z/raw.log)
- candidate_api: [20260928T073540Z](validation/results/candidate_api/20260928T073540Z/raw.log)
- candidate_extra: [20260928T073352Z](validation/results/candidate_extra/20260928T073352Z/raw.log)
- candidate_kat: [20260928T073234Z](validation/results/candidate_kat/20260928T073234Z/raw.log)
- candidate_kernel: [20260928T073020Z](validation/results/candidate_kernel/20260928T073020Z/raw.log), [20260928T074105Z](validation/results/candidate_kernel/20260928T074105Z/raw.log)
- candidate_sigkat: [20260928T072949Z](validation/results/candidate_sigkat/20260928T072949Z/raw.log), [20260928T073635Z](validation/results/candidate_sigkat/20260928T073635Z/raw.log)
- candidate_sign: [20260928T073149Z](validation/results/candidate_sign/20260928T073149Z/raw.log), [20260928T073737Z](validation/results/candidate_sign/20260928T073737Z/raw.log)

복사되어 있던 과거 README/result는
[백업](validation/copied_before_slothy_docs.tar.gz)에 보존했다.
