#include "probe.h"
#include <cmsis_core.h>
#include <stdio.h>
enum { N_CAT = 27 };
static const char *names[N_CAT] = {"kg_ntru_rest","kg_ortho_rest","kg_fft_fixed","kg_ifft_fixed","kg_fft_ntru","kg_ifft_ntru","kg_fft_fp64","kg_ifft_fp64","kg_invnorm","kg_mul","kg_recip","kg_div","kg_fft_misc","kg_input","sg_fft","sg_ifft","sg_ldl","sg_split","sg_merge","sg_split_selfadj","sg_mul","sg_add","sg_sub","sg_gram","sg_basis","sg_deepest","sg_sampler"};
typedef struct { uint64_t excl, incl; uint32_t calls; } stat;
static stat stats[2][3][N_CAT];
static uint64_t totals[2][3];
static uint32_t runs[2][3];
static struct { uint32_t start, child, cat; } frames[32];
static unsigned active, depth, di, operation, errors;
void probe_start(unsigned logn, unsigned op) {
    if (active || depth || logn<9 || logn>10 || op>2) errors++;
    di=logn-9; operation=op; active=1;
}
void probe_stop(uint64_t elapsed) {
    if (!active || depth || elapsed > 0xffffffffu) errors++;
    totals[di][operation]+=elapsed; runs[di][operation]++; active=0;
}
unsigned probe_enter(unsigned cat) {
    if (!active) return 0;
    if (depth>=32 || cat>=N_CAT) { errors++; return 0; }
    frames[depth].cat=cat; frames[depth].child=0;
    frames[depth].start=DWT->CYCCNT; depth++; return 1;
}
void probe_leave(unsigned *enabled) {
    uint32_t end=DWT->CYCCNT;
    if (!*enabled) return;
    if (!depth) { errors++; return; }
    depth--;
    uint32_t elapsed=end-frames[depth].start;
    if (frames[depth].child>elapsed) { errors++; return; }
    stat *s=&stats[di][operation][frames[depth].cat];
    s->excl+=elapsed-frames[depth].child; s->incl+=elapsed; s->calls++;
    if (depth) frames[depth-1].child+=elapsed;
}
int probe_report(void) {
    const char *ops[]={"keygen","sign","verify"};
    for (unsigned d=0;d<2;d++) for (unsigned o=0;o<3;o++) {
        uint64_t sum=0;
        for (unsigned c=0;c<N_CAT;c++) {
            stat *s=&stats[d][o][c];sum+=s->excl;
            if (s->calls) printf("MC_PROFILE op=%s degree=%u category=%s calls=%u exclusive=%llu inclusive=%llu\n",
                ops[o],512u<<d,names[c],s->calls,(unsigned long long)s->excl,(unsigned long long)s->incl);
        }
        if(sum>totals[d][o] || runs[d][o]!=10) errors++;
        printf("MC_PROFILE_TOTAL op=%s degree=%u calls=%u cycles=%llu classified=%llu remainder=%llu\n",
            ops[o],512u<<d,runs[d][o],(unsigned long long)totals[d][o],(unsigned long long)sum,
            (unsigned long long)(totals[d][o]-sum));
    }
    printf("MC_PROFILE_DONE errors=%u depth=%u\n",errors,depth);
    return errors || depth;
}
