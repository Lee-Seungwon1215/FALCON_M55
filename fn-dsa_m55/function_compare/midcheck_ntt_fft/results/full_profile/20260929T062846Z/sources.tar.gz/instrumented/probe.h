#ifndef MIDCHECK_PROBE_H
#define MIDCHECK_PROBE_H
#include <stdint.h>
void probe_start(unsigned logn, unsigned op);
void probe_stop(uint64_t elapsed);
int probe_report(void);
unsigned probe_enter(unsigned cat);
void probe_leave(unsigned *active);
#define MC_SCOPE(cat) unsigned mid_scope __attribute__((cleanup(probe_leave))) = probe_enter(cat)
#endif
