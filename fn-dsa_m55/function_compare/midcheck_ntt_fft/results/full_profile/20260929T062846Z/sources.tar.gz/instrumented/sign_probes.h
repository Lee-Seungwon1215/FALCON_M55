#include "sign_inner.h"
void probe_fpoly_FFT(unsigned logn, fpr *f);
void probe_fpoly_iFFT(unsigned logn, fpr *f);
void probe_fpoly_LDL_fft(unsigned logn, const fpr *g00, fpr *g01, fpr *g11);
void probe_fpoly_split_fft(unsigned logn, fpr *f0, fpr *f1, const fpr *f);
void probe_fpoly_merge_fft(unsigned logn, fpr *f, const fpr *f0, const fpr *f1);
