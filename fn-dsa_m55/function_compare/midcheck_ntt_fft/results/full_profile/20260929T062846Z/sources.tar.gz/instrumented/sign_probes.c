#include "probe.h"
#include "sign_probes.h"
__attribute__((noinline)) void probe_fpoly_FFT(unsigned logn, fpr *f) { MC_SCOPE(14); fpoly_FFT(logn, f); }
__attribute__((noinline)) void probe_fpoly_iFFT(unsigned logn, fpr *f) { MC_SCOPE(15); fpoly_iFFT(logn, f); }
__attribute__((noinline)) void probe_fpoly_LDL_fft(unsigned logn, const fpr *g00, fpr *g01, fpr *g11) { MC_SCOPE(16); fpoly_LDL_fft(logn, g00, g01, g11); }
__attribute__((noinline)) void probe_fpoly_split_fft(unsigned logn, fpr *f0, fpr *f1, const fpr *f) { MC_SCOPE(17); fpoly_split_fft(logn, f0, f1, f); }
__attribute__((noinline)) void probe_fpoly_merge_fft(unsigned logn, fpr *f, const fpr *f0, const fpr *f1) { MC_SCOPE(18); fpoly_merge_fft(logn, f, f0, f1); }
