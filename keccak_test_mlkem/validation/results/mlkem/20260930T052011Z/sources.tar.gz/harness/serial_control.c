/* Test-only control: identical x4 PRNG, four original CM4 permutations.
 * The original ABI stores its last four 64-bit lanes in even/odd format. */
#include "sha3x4.h"
extern void fndsa_sha3_process_block(uint64_t *, unsigned);
static uint64_t split(uint64_t x) {
 uint64_t y=0; for(unsigned i=0;i<32;i++) {
  y|=((x>>(2*i))&1)<<i; y|=((x>>(2*i+1))&1)<<(32+i);
 } return y;
}
static uint64_t merge(uint64_t x) {
 uint64_t y=0; for(unsigned i=0;i<32;i++) {
  y|=((x>>i)&1)<<(2*i); y|=((x>>(32+i))&1)<<(2*i+1);
 } return y;
}
void fndsa_keccakx4_permute(uint32_t a[2][25][4]) {
 uint64_t state[25];
 for(unsigned s=0;s<4;s++) {
  for(unsigned j=0;j<25;j++) { uint64_t v=a[0][j][s]|((uint64_t)a[1][j][s]<<32); state[j]=j<21?v:split(v); }
  fndsa_sha3_process_block(state,17);
  for(unsigned j=0;j<25;j++) { uint64_t v=j<21?state[j]:merge(state[j]); a[0][j][s]=(uint32_t)v; a[1][j][s]=(uint32_t)(v>>32); }
 }
}
